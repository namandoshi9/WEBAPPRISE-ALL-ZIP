# # Set up your access token, app ID, and app secret
# ACCESS_TOKEN = 'EAAPBBfYwfZBEBO9klWSsK4yGNtfmvcd5ukZCiOYTOYeIA9bZB1SslJjwHwxbXSFlwWqO3YaJaiJe94aZCIydIWBIl12ZAo1dRvPtrYXk2bxYhMXT3AqWhSdb5TbXpUnZBHBBxmyNdSygyp4RDbIupzBjJ1Xl1Qa8qHUIDeTFuMiHCeRuVpS0OAmIhkONQNark8'
# AD_ACCOUNT_ID = 'act_265286608472987'  # Example: 'act_1234567890'
# APP_ID = '1056656279502817'
# APP_SECRET = '2262d17143d0195c0384c347f63f6434'



#===== Update budget data and ad status using ad name ==========

# import requests

# def fetch_adsets(access_token, campaign_id):
#     url = f"https://graph.facebook.com/v12.0/{campaign_id}/adsets"
#     params = {
#         'access_token': access_token,
#         'fields': 'id,name,daily_budget',
#     }
    
#     response = requests.get(url, params=params)
    
#     if response.status_code == 200:
#         return response.json().get('data', [])
#     else:
#         print(f"Error fetching ad sets: {response.status_code} - {response.text}")
#         return None

# def fetch_ads(access_token, adset_id):
#     url = f"https://graph.facebook.com/v12.0/{adset_id}/ads"
#     params = {
#         'access_token': access_token,
#         'fields': 'id,name,status',
#     }
    
#     response = requests.get(url, params=params)
    
#     if response.status_code == 200:
#         return response.json().get('data', [])
#     else:
#         print(f"Error fetching ads: {response.status_code} - {response.text}")
#         return None

# def update_budget(access_token, adset_id, new_budget):
#     url = f"https://graph.facebook.com/v12.0/{adset_id}"
#     params = {
#         'access_token': access_token,
#         'daily_budget': new_budget,  # The budget should be in cents
#     }
    
#     response = requests.post(url, params=params)
    
#     if response.status_code == 200:
#         print(f"Successfully updated budget for Ad Set ID: {adset_id} to {new_budget / 100:.2f}")
#     else:
#         print(f"Error updating budget: {response.status_code} - {response.text}")

# def update_ad_status(access_token, ad_id, new_status):
#     url = f"https://graph.facebook.com/v12.0/{ad_id}"
#     params = {
#         'access_token': access_token,
#         'status': new_status
#     }

#     response = requests.post(url, params=params)

#     if response.status_code == 200:
#         print(f"Successfully updated status for Ad ID: {ad_id} to {new_status}")
#     else:
#         print(f"Error updating status: {response.status_code} - {response.text}")

# if __name__ == "__main__":
#     ACCESS_TOKEN = 'EAAPBBfYwfZBEBOwgPYWLTUdXgJ1AZA2zH5rbqWP4TrakzMHv82DCcHxKcbhMaFvBXVIoXITd6FamGPO3yUQLMd9SyGWX7n3gv3ZBVvZCVThqc9imqdl7EUQOZCS97R9LDZAU21awiNdYTREZCMKJrWDizCCaN9945mdrzPxzx4MTPe1UDZCzBdsZAmdZBNIKHVZALJy'  # Your long-lived access token
#     CAMPAIGN_ID = '120218886469620456'  # Your Facebook Campaign ID

#     # Fetch ad sets
#     adset_data = fetch_adsets(ACCESS_TOKEN, CAMPAIGN_ID)

#     # Check if any ad sets were found
#     if adset_data:
#         # Ask user for ad name
#         user_ad_name = input("Enter the Ad Name: ")

#         ad_found = False  # Flag to track if the ad is found

#         # Fetch ads for each ad set and look for the ad with the given name
#         for adset in adset_data:
#             adset_id = adset['id']
#             ads = fetch_ads(ACCESS_TOKEN, adset_id)

#             if ads:
#                 # Find the ad with the specified name
#                 for ad in ads:
#                     if ad['name'] == user_ad_name:
#                         # Display current ad information
#                         print(f"Ad ID: {ad['id']}")
#                         print(f"Current Status: {ad['status']}")

#                         # Safely convert daily_budget from string to integer before performing any operations
#                         try:
#                             daily_budget_cents = int(adset['daily_budget'])
#                             print(f"Current Daily Budget: ${daily_budget_cents / 100:.2f}")
#                         except ValueError:
#                             print(f"Unable to convert daily_budget for Ad Set ID: {adset_id}")

#                         # Ask user for new budget and status
#                         user_budget = input("Enter the new budget : ")
#                         user_status = input("Enter the new status (ACTIVE, PAUSED, ARCHIVED, DELETED): ").upper()

#                         # Convert user budget to cents
#                         new_budget_cents = int(float(user_budget) * 100)

#                         # Update the budget for the ad set containing this ad
#                         update_budget(ACCESS_TOKEN, adset_id, new_budget_cents)

#                         # Update the status of the ad
#                         update_ad_status(ACCESS_TOKEN, ad['id'], user_status)

#                         ad_found = True
#                         break
#             if ad_found:
#                 break  # Exit the loop once the ad is found and updated

#         if not ad_found:
#             print(f"No ad found with name: {user_ad_name}")
#     else:
#         print("No ad sets found for the specified campaign.")


#====== fetch adname and budget data only============

# import requests

# def fetch_adsets(access_token, campaign_id):
#     url = f"https://graph.facebook.com/v12.0/{campaign_id}/adsets"
#     params = {
#         'access_token': access_token,
#         'fields': 'id,name,daily_budget',
#     }
    
#     response = requests.get(url, params=params)
    
#     if response.status_code == 200:
#         adsets = response.json().get('data', [])
#         print(adsets)  # Print the full response
#         return adsets
#     else:
#         print(f"Error fetching ad sets: {response.status_code} - {response.text}")
#         return None


# def fetch_ads(access_token, adset_id):
#     url = f"https://graph.facebook.com/v12.0/{adset_id}/ads"
#     params = {
#         'access_token': access_token,
#         'fields': 'id,name,status',
#     }
    
#     response = requests.get(url, params=params)
    
#     if response.status_code == 200:
#         return response.json().get('data', [])
#     else:
#         print(f"Error fetching ads: {response.status_code} - {response.text}")
#         return None

# if __name__ == "__main__":
#     # Set your access token and campaign ID
#     ACCESS_TOKEN = 'EAAPBBfYwfZBEBOwgPYWLTUdXgJ1AZA2zH5rbqWP4TrakzMHv82DCcHxKcbhMaFvBXVIoXITd6FamGPO3yUQLMd9SyGWX7n3gv3ZBVvZCVThqc9imqdl7EUQOZCS97R9LDZAU21awiNdYTREZCMKJrWDizCCaN9945mdrzPxzx4MTPe1UDZCzBdsZAmdZBNIKHVZALJy'  # Your long-lived access token
#     CAMPAIGN_ID = '120218886469620456'  # Your Facebook Campaign ID

#     # Fetch ad sets
#     adset_data = fetch_adsets(ACCESS_TOKEN, CAMPAIGN_ID)

#    # Check if any ad sets were found
#     if adset_data:
#         for adset in adset_data:
#             adset_name = adset['name']
#             daily_budget_str = adset.get('daily_budget', '0')  # Default to '0' if not available
            
#             # Safely convert daily_budget from string to integer and handle potential ValueError
#             try:
#                 daily_budget = int(daily_budget_str)
#                 budget_in_dollars = daily_budget / 100.0  # Convert cents to dollars
#                 print(f"Ad Set Name: {adset_name}, Daily Budget: ${budget_in_dollars:.2f}")
#             except ValueError:
#                 print(f"Ad Set Name: {adset_name}, Daily Budget: Not available or invalid")
#     else:
#         print("No ad sets found for the specified campaign.")




# #====== fetch data data only============

# import requests

# def fetch_campaigns(access_token):
#     url = "https://graph.facebook.com/v12.0/act_265286608472987/campaigns"
#     params = {
#         'access_token': access_token,
#         'fields': 'id,name,status,objective,daily_budget,lifetime_budget,start_time,end_time,created_time,updated_time',
#     }
    
#     response = requests.get(url, params=params)
    
#     if response.status_code == 200:
#         return response.json().get('data', [])
#     else:
#         print(f"Error fetching campaigns: {response.status_code} - {response.text}")
#         return None

# if __name__ == "__main__":
#     ACCESS_TOKEN = 'EAAPBBfYwfZBEBOwgPYWLTUdXgJ1AZA2zH5rbqWP4TrakzMHv82DCcHxKcbhMaFvBXVIoXITd6FamGPO3yUQLMd9SyGWX7n3gv3ZBVvZCVThqc9imqdl7EUQOZCS97R9LDZAU21awiNdYTREZCMKJrWDizCCaN9945mdrzPxzx4MTPe1UDZCzBdsZAmdZBNIKHVZALJy'  # Replace with your long-lived access token

#     # Fetch campaigns
#     campaigns = fetch_campaigns(ACCESS_TOKEN)

#     # Fetch insights for each campaign
#     if campaigns:
#         for campaign in campaigns:
#             campaign_id = campaign['id']
#             campaign_name = campaign['name']
#             campaign_status = campaign['status']
#             campaign_objective = campaign.get('objective', 'N/A')  # Default to 'N/A' if not available
#             daily_budget = campaign.get('daily_budget', 0) / 100.0  # Convert to dollars
#             lifetime_budget = campaign.get('lifetime_budget', 0) / 100.0  # Convert to dollars
#             start_time = campaign.get('start_time', 'N/A')
#             end_time = campaign.get('end_time', 'N/A')
#             created_time = campaign.get('created_time', 'N/A')
#             updated_time = campaign.get('updated_time', 'N/A')

#             print(f"""
#             Campaign Name: {campaign_name}
#             ID: {campaign_id}
#             Status: {campaign_status}
#             Objective: {campaign_objective}
#             Daily Budget: ${daily_budget:.2f}
#             Lifetime Budget: ${lifetime_budget:.2f}
#             Start Time: {start_time}
#             End Time: {end_time}
#             Created Time: {created_time}
#             Updated Time: {updated_time}
#             """)
#     else:
#         print("No campaigns found.")




#======= fetch camping and adsets  data only============
# import requests

# def fetch_campaigns(access_token):
#     url = "https://graph.facebook.com/v12.0/act_265286608472987/campaigns"
#     params = {
#         'access_token': access_token,
#         'fields': 'id,name,status,objective,daily_budget,lifetime_budget,start_time,end_time,created_time,updated_time',
#     }
    
#     response = requests.get(url, params=params)
    
#     if response.status_code == 200:
#         return response.json().get('data', [])
#     else:
#         print(f"Error fetching campaigns: {response.status_code} - {response.text}")
#         return None

# def fetch_adsets(access_token, campaign_id):
#     url = f"https://graph.facebook.com/v12.0/{campaign_id}/adsets"
#     params = {
#         'access_token': access_token,
#         'fields': 'id,name,status,daily_budget,start_time,end_time',
#     }
    
#     response = requests.get(url, params=params)
    
#     if response.status_code == 200:
#         return response.json().get('data', [])
#     else:
#         print(f"Error fetching ad sets: {response.status_code} - {response.text}")
#         return None


# if __name__ == "__main__":
#     ACCESS_TOKEN = 'EAAPBBfYwfZBEBOwgPYWLTUdXgJ1AZA2zH5rbqWP4TrakzMHv82DCcHxKcbhMaFvBXVIoXITd6FamGPO3yUQLMd9SyGWX7n3gv3ZBVvZCVThqc9imqdl7EUQOZCS97R9LDZAU21awiNdYTREZCMKJrWDizCCaN9945mdrzPxzx4MTPe1UDZCzBdsZAmdZBNIKHVZALJy'  # Replace with your long-lived access token

#     # Fetch campaigns
#     campaigns = fetch_campaigns(ACCESS_TOKEN)

#     # Fetch ad sets for each campaign
#     if campaigns:
#         for campaign in campaigns:
#             campaign_id = campaign['id']
#             campaign_name = campaign['name']
#             print(f"Campaign Name: {campaign_name}, ID: {campaign_id}")

#             # Fetch ad sets for the current campaign
#             adsets = fetch_adsets(ACCESS_TOKEN, campaign_id)
#             if adsets:
#                 for adset in adsets:
#                     adset_id = adset['id']
#                     adset_name = adset['name']
#                     adset_status = adset['status']
#                     daily_budget = adset.get('daily_budget', '0')  # Default to '0' if not available

#                     print(f"  Ad Set Name: {adset_name}, ID: {adset_id}, Status: {adset_status}, Daily Budget: {daily_budget}")

#                     # Optionally fetch insights for the current ad set
            
#             else:
#                 print(f"No ad sets found for campaign {campaign_name}.")
#     else:
#         print("No campaigns found.")



#================fetching camping adsets and ads data==============

# import requests

# def fetch_campaigns(access_token):
#     url = "https://graph.facebook.com/v12.0/act_265286608472987/campaigns"
#     params = {
#         'access_token': access_token,
#         'fields': 'id,name,status,objective,daily_budget,lifetime_budget,start_time,end_time,created_time,updated_time',
#     }
    
#     response = requests.get(url, params=params)
    
#     if response.status_code == 200:
#         return response.json().get('data', [])
#     else:
#         print(f"Error fetching campaigns: {response.status_code} - {response.text}")
#         return None

# def fetch_adsets(access_token, campaign_id):
#     url = f"https://graph.facebook.com/v12.0/{campaign_id}/adsets"
#     params = {
#         'access_token': access_token,
#         'fields': 'id,name,status,daily_budget,start_time,end_time',
#     }
    
#     response = requests.get(url, params=params)
    
#     if response.status_code == 200:
#         return response.json().get('data', [])
#     else:
#         print(f"Error fetching ad sets: {response.status_code} - {response.text}")
#         return None

# def fetch_ads(access_token, adset_id):
#     url = f"https://graph.facebook.com/v12.0/{adset_id}/ads"
#     params = {
#         'access_token': access_token,
#         'fields': 'id,name,status,creative',
#     }
    
#     response = requests.get(url, params=params)
    
#     if response.status_code == 200:
#         return response.json().get('data', [])
#     else:
#         print(f"Error fetching ads: {response.status_code} - {response.text}")
#         return None

# if __name__ == "__main__":
#     ACCESS_TOKEN = 'EAAPBBfYwfZBEBOwgPYWLTUdXgJ1AZA2zH5rbqWP4TrakzMHv82DCcHxKcbhMaFvBXVIoXITd6FamGPO3yUQLMd9SyGWX7n3gv3ZBVvZCVThqc9imqdl7EUQOZCS97R9LDZAU21awiNdYTREZCMKJrWDizCCaN9945mdrzPxzx4MTPe1UDZCzBdsZAmdZBNIKHVZALJy'  # Replace with your long-lived access token

#     # Fetch campaigns
#     campaigns = fetch_campaigns(ACCESS_TOKEN)

#     # Fetch ad sets for each campaign
#     if campaigns:
#         for campaign in campaigns:
#             campaign_id = campaign['id']
#             campaign_name = campaign['name']
#             print(f"Campaign Name: {campaign_name}, ID: {campaign_id}")

#             # Fetch ad sets for the current campaign
#             adsets = fetch_adsets(ACCESS_TOKEN, campaign_id)
#             if adsets:
#                 for adset in adsets:
#                     adset_id = adset['id']
#                     adset_name = adset['name']
#                     adset_status = adset['status']
#                     daily_budget = adset.get('daily_budget', '0')  # Default to '0' if not available

#                     print(f"  Ad Set Name: {adset_name}, ID: {adset_id}, Status: {adset_status}, Daily Budget: {daily_budget}")

#                     # Fetch ads for the current ad set
#                     ads = fetch_ads(ACCESS_TOKEN, adset_id)
#                     if ads:
#                         for ad in ads:
#                             ad_id = ad['id']
#                             ad_name = ad['name']
#                             ad_status = ad['status']
#                             creative = ad.get('creative', {}).get('id', 'No creative info')  # Get creative ID if available

#                             print(f"    Ad Name: {ad_name}, ID: {ad_id}, Status: {ad_status}, Creative ID: {creative}")
#                     else:
#                         print(f"    No ads found for ad set {adset_name}.")
#             else:
#                 print(f"No ad sets found for campaign {campaign_name}.")
#     else:
#         print("No campaigns found.")



#================fetching camping adsets ad and ads insights data==============



# from facebook_business.api import FacebookAdsApi
# from facebook_business.adobjects.adaccount import AdAccount
# from facebook_business.adobjects.campaign import Campaign
# from facebook_business.adobjects.adset import AdSet

# # Credentials
# ACCESS_TOKEN = 'EAAPBBfYwfZBEBO9klWSsK4yGNtfmvcd5ukZCiOYTOYeIA9bZB1SslJjwHwxbXSFlwWqO3YaJaiJe94aZCIydIWBIl12ZAo1dRvPtrYXk2bxYhMXT3AqWhSdb5TbXpUnZBHBBxmyNdSygyp4RDbIupzBjJ1Xl1Qa8qHUIDeTFuMiHCeRuVpS0OAmIhkONQNark8'
# AD_ACCOUNT_ID = 'act_265286608472987'
# APP_ID = '1056656279502817'
# APP_SECRET = '2262d17143d0195c0384c347f63f6434'

# # Initialize the Facebook Ads API
# FacebookAdsApi.init(access_token=ACCESS_TOKEN, app_id=APP_ID, app_secret=APP_SECRET)

# # Create an AdAccount object
# ad_account = AdAccount(AD_ACCOUNT_ID)

# # Define the fields you want to retrieve for the campaigns
# campaign_fields = ['id', 'name', 'status']

# # Fetch campaign data
# campaigns = ad_account.get_campaigns(fields=campaign_fields)

# # Loop through each campaign to get its ad sets
# for campaign in campaigns:
#     print(f"Campaign ID: {campaign['id']}")
#     print(f"Campaign Name: {campaign['name']}")
#     print(f"Campaign Status: {campaign['status']}")
#     print("Fetching associated Ad Sets...")

#     # Fetch ad sets for the campaign
#     adsets = campaign.get_ad_sets(fields=['id', 'name', 'status', 'daily_budget'])

#     # Print ad set details
#     # Print ad set details
#     for adset in adsets:
#         print(f"  Ad Set ID: {adset['id']}")
#         print(f"  Ad Set Name: {adset['name']}")
#         print(f"  Ad Set Status: {adset['status']}")
        
#         # Convert daily_budget from cents to dollars
#         daily_budget_str = adset['daily_budget']
        
#         # Convert daily_budget to an integer (if it's a string)
#         try:
#             daily_budget_cents = int(daily_budget_str)
#         except ValueError:
#             print("Invalid daily_budget value:", daily_budget_str)
#             daily_budget_cents = 0  # or handle it as needed

#         daily_budget_dollars = daily_budget_cents / 100.0
#         print(f"  Ad Set Daily Budget: ${daily_budget_dollars:.2f}")  # Format to 2 decimal places
#         print("  " + "-" * 40)

#     print("=" * 50)


#========= complet data fetch and print============

from facebook_business.api import FacebookAdsApi
from facebook_business.adobjects.adaccount import AdAccount
from facebook_business.adobjects.campaign import Campaign
from facebook_business.adobjects.adset import AdSet
from facebook_business.adobjects.ad import Ad

# Credentials
ACCESS_TOKEN = 'EAAPBBfYwfZBEBO9klWSsK4yGNtfmvcd5ukZCiOYTOYeIA9bZB1SslJjwHwxbXSFlwWqO3YaJaiJe94aZCIydIWBIl12ZAo1dRvPtrYXk2bxYhMXT3AqWhSdb5TbXpUnZBHBBxmyNdSygyp4RDbIupzBjJ1Xl1Qa8qHUIDeTFuMiHCeRuVpS0OAmIhkONQNark8'
AD_ACCOUNT_ID = 'act_265286608472987'
APP_ID = '1056656279502817'
APP_SECRET = '2262d17143d0195c0384c347f63f6434'

# Initialize the Facebook Ads API
FacebookAdsApi.init(access_token=ACCESS_TOKEN, app_id=APP_ID, app_secret=APP_SECRET)

# Create an AdAccount object
ad_account = AdAccount(AD_ACCOUNT_ID)

# Define the fields you want to retrieve for the campaigns
campaign_fields = ['id', 'name', 'status']

# Fetch campaign data
campaigns = ad_account.get_campaigns(fields=campaign_fields)

# Loop through each campaign to get its ad sets
for campaign in campaigns:
    print(f"Campaign ID: {campaign['id']}")
    print(f"Campaign Name: {campaign['name']}")
    print(f"Campaign Status: {campaign['status']}")
    print("Fetching associated Ad Sets...")

    # Fetch ad sets for the campaign
    adsets = campaign.get_ad_sets(fields=['id', 'name', 'status', 'daily_budget'])

    # Print ad set details
    for adset in adsets:
        print(f"  Ad Set ID: {adset['id']}")
        print(f"  Ad Set Name: {adset['name']}")
        print(f"  Ad Set Status: {adset['status']}")
        
        # Convert daily_budget from cents to dollars
        daily_budget_str = adset['daily_budget']
        
        # Convert daily_budget to an integer (if it's a string)
        try:
            daily_budget_cents = int(daily_budget_str)
        except ValueError:
            print("Invalid daily_budget value:", daily_budget_str)
            daily_budget_cents = 0  # or handle it as needed

        daily_budget_dollars = daily_budget_cents / 100.0
        print(f"  Ad Set Daily Budget: ${daily_budget_dollars:.2f}")  # Format to 2 decimal places
        print("  " + "-" * 40)

        # Fetch ads for the ad set
        ads = adset.get_ads(fields=['id', 'name', 'status', 'creative'])

        # Print ad details
        for ad in ads:
            print(f"    Ad ID: {ad['id']}")
            print(f"    Ad Name: {ad['name']}")
            print(f"    Ad Status: {ad['status']}")
            print(f"    Ad Creative ID: {ad['creative']['id']}")
            # Optionally, you can print more details from the creative
            if 'creative' in ad and 'object_story_spec' in ad['creative']:
                print(f"    Ad Creative Object Story Spec: {ad['creative']['object_story_spec']}")
            print("    " + "-" * 30)

            # Fetch insights for the ad
            insights = ad.get_insights(fields=[
                'impressions', 'clicks', 'spend', 'reach', 'actions', 'cost_per_action_type',
            ])

            # Print insights details
            for insight in insights:
                print(f"      Ad Insights:")
                print(f"      Impressions: {insight.get('impressions', 0)}")
                print(f"      Clicks: {insight.get('clicks', 0)}")
                print(f"      Spend: ${insight.get('spend', 0)}")
                print(f"      Reach: {insight.get('reach', 0)}")
                
                # Fetch link_click data
                link_clicks = 0
                cost_per_result = 0
                for action in insight.get('actions', []):
                    if action['action_type'] == 'link_click':
                        link_clicks = action.get('value', 0)

                print(f"      Link Clicks: {link_clicks}")

                # Fetch Cost Per Link Click
                cost_per_action = insight.get('cost_per_action_type', [])
                for cost in cost_per_action:
                    if cost['action_type'] == 'link_click':
                        cost_per_result = cost.get('value', 0)
                        # Convert cost_per_result to float if it's a string
                        try:
                            cost_per_result = float(cost_per_result)
                        except ValueError:
                            cost_per_result = 0.0  # Default to 0.0 in case of invalid conversion

                print(f"      Cost Per Link Click: ${cost_per_result:.2f}")  # Format as float
                print("      " + "-" * 30)



#====== update daily budget data(ad id base)=======================

# import requests
# from facebook_business.api import FacebookAdsApi
# from facebook_business.adobjects.adaccount import AdAccount
# from facebook_business.adobjects.adset import AdSet

# # Credentials
# ACCESS_TOKEN = 'EAAPBBfYwfZBEBO9klWSsK4yGNtfmvcd5ukZCiOYTOYeIA9bZB1SslJjwHwxbXSFlwWqO3YaJaiJe94aZCIydIWBIl12ZAo1dRvPtrYXk2bxYhMXT3AqWhSdb5TbXpUnZBHBBxmyNdSygyp4RDbIupzBjJ1Xl1Qa8qHUIDeTFuMiHCeRuVpS0OAmIhkONQNark8'
# AD_ACCOUNT_ID = 'act_265286608472987'  # Example: 'act_1234567890'
# APP_ID = '1056656279502817'
# APP_SECRET = '2262d17143d0195c0384c347f63f6434'

# # Function to update the daily budget of an ad set
# def update_budget(access_token, adset_id, new_budget):
#     url = f"https://graph.facebook.com/v12.0/{adset_id}"
#     params = {
#         'access_token': access_token,
#         'daily_budget': new_budget,  # The budget should be in cents
#     }
    
#     response = requests.post(url, params=params)
    
#     if response.status_code == 200:
#         print(f"Successfully updated budget for Ad Set ID: {adset_id} to ${new_budget / 100:.2f}")
#     else:
#         print(f"Error updating budget: {response.status_code} - {response.text}")

# def get_current_budget(adset_id):
#     url = f"https://graph.facebook.com/v12.0/{adset_id}"
#     params = {
#         'access_token': ACCESS_TOKEN,
#         'fields': 'id,name,status,daily_budget'
#     }
    
#     response = requests.get(url, params=params)
    
#     if response.status_code == 200:
#         adset_data = response.json()
        
#         # Convert daily_budget to an integer (if it's a string)
#         daily_budget_str = adset_data.get('daily_budget', '0')
#         try:
#             daily_budget_cents = int(daily_budget_str)  # Convert to integer
#         except ValueError:
#             print("Invalid daily_budget value:", daily_budget_str)
#             daily_budget_cents = 0  # Default to 0 if invalid
        
#         current_budget = daily_budget_cents / 100.0  # Convert from cents to dollars
#         print(f"Ad Set ID: {adset_data['id']}")
#         print(f"Ad Set Name: {adset_data['name']}")
#         print(f"Ad Set Status: {adset_data['status']}")
#         print(f"Current Daily Budget: ${current_budget:.2f}")

#         # Prompt user for a new budget
#         new_budget = float(input("Enter the new daily budget amount in dollars: ")) * 100  # Convert to cents
#         update_budget(ACCESS_TOKEN, adset_id, int(new_budget))  # Update the budget
#     else:
#         print(f"Error fetching ad set details: {response.status_code} - {response.text}")

# # Main program
# if __name__ == "__main__":
#     adset_id = input("Enter the Ad Set ID: ")
#     get_current_budget(adset_id)



#======================================= 


