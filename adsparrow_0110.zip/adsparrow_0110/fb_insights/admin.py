# fb_insights/admin.py

from django.contrib import admin
from .models import CronJobLog,CustomUser,AdAccount, Campaign, AdSet, Ad, GoogleAnalyticsAccount, TrafficSourceMedium
from django.contrib.auth.admin import UserAdmin

class CustomUserAdmin(UserAdmin):
    model = CustomUser
    list_display = ['username', 'email', 'is_staff', 'is_active', 'is_premium']
    list_filter = ['is_staff', 'is_active', 'is_premium']

    def total_users(self):
        return CustomUser.objects.count()
    
    total_users.short_description = 'Total Users'

admin.site.register(CustomUser, CustomUserAdmin)

@admin.register(AdAccount)
class AdAccountAdmin(admin.ModelAdmin):
    list_display = ('id','ad_account_id', 'account_name', 'account_status', 'app_id', 'app_secret_key', 'is_visible', 'is_active', 'created_at', 'updated_at')
    list_filter = ('is_visible', 'is_active')
    search_fields = ('ad_account_id', 'account_name', 'app_id')

@admin.register(Campaign)
class CampaignAdmin(admin.ModelAdmin):
    list_display = ('campaign_id', 'name', 'ad_account_id', 'created_at', 'updated_at')
    list_filter = ('ad_account',)
    search_fields = ('campaign_id', 'name')

@admin.register(AdSet)
class AdSetAdmin(admin.ModelAdmin):
    list_display = ('adset_id', 'name', 'campaign', 'created_at', 'updated_at')
    list_filter = ('campaign',)
    search_fields = ('adset_id', 'name')

@admin.register(Ad)
class AdAdmin(admin.ModelAdmin):
    list_display = ('id','ad_id', 'name', 'adset', 'cost_per_result','clicks', 'spend', 'reach', 'results', 'ad_delivery', 'ad_set_budget', 'start_date', 'end_date', 'created_at', 'updated_at')
    list_filter = ('adset',)
    search_fields = ('ad_id', 'name', 'adset__name')
    date_hierarchy = 'start_date'



@admin.register(GoogleAnalyticsAccount)
class GoogleAnalyticsAccountAdmin(admin.ModelAdmin):
    list_display = ('property_id', 'json_key','account_status', 'created_at', 'updated_at')
    search_fields = ('property_id',)
    list_filter = ('created_at',)
    ordering = ('-created_at',)


@admin.register(TrafficSourceMedium)
class TrafficSourceMediumAdmin(admin.ModelAdmin):
    list_display = ('account', 'source', 'medium', 'sessions', 'active_users', 'total_revenue', 'start_date', 'end_date', 'created_at','updated_at')
    list_filter = ('account', 'source', 'medium', 'start_date', 'end_date','updated_at')  # Filter by date range
    search_fields = ('source', 'medium', 'account__property_id')
    date_hierarchy = 'start_date'  # Add date navigation by report start date
    ordering = ('-created_at',)


@admin.register(CronJobLog)
class CronJobLogAdmin(admin.ModelAdmin):
    list_display = ('user', 'ad_account', 'ga_ad_account','status', 'message', 'created_at','updated_at')  # Display these fields in the list view
    list_filter = ('status',)  # Allow filtering by status
    search_fields = ('user__username', 'ad_account__account_name', 'message')  # Allow searching by username, account name, and message
    ordering = ('-created_at',)  # Order by creation date, descending