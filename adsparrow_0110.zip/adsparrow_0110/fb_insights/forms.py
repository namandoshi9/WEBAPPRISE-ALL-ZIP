# fb_insights/forms.py

from django import forms
from .models import GoogleAnalyticsAccount,CustomUser


class UserRegistrationForm(forms.ModelForm):
    class Meta:
        model = CustomUser
        fields = ['name', 'email', 'password']
        widgets = {
            'password': forms.PasswordInput(),
        }

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data['password'])  # Hash the password
        user.username = self.cleaned_data['email'] 
        if commit:
            user.save()
        return user

class UserUpdateForm(forms.ModelForm):
    class Meta:
        model = CustomUser
        fields = ['name', 'password']
        widgets = {
            'password': forms.PasswordInput(),
        }

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data['password'])  # Hash the password
        if commit:
            user.save()
        return user


# class LoginForm(forms.Form):
#     email = forms.EmailField(widget=forms.EmailInput(attrs={'placeholder': 'User Name'}))
#     password = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder': 'Password'}))


class LoginForm(forms.Form):
    email = forms.EmailField(widget=forms.EmailInput(attrs={'placeholder': 'Email'}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder': 'Password'}))

    # You can customize validation if needed
    def clean(self):
        cleaned_data = super().clean()
        email = cleaned_data.get('email')
        password = cleaned_data.get('password')

        if not email or not password:
            raise forms.ValidationError("Email and Password are required.")
        
        # Return the cleaned data
        return cleaned_data


class FacebookCredentialsForm(forms.Form):
    access_token = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Access Token'}),
        error_messages={'required': 'Access Token is required.'}
    )
    ad_account_id = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter AD Account ID'}),
        error_messages={'required': 'AD Account ID is required.'}
    )
    app_secret = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter App Secret'}),
        error_messages={'required': 'App Secret is required.'}
    )
    app_id = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter App ID'}),
        error_messages={'required': 'App ID is required.'}
    )
    account_name = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Account Name'}),
        required=False  # This field is optional, so no custom required error message is needed.
    )



class GoogleAnalyticsAccountForm(forms.ModelForm):
    class Meta:
        model = GoogleAnalyticsAccount
        fields = ['property_id', 'ad_name','json_key']
        widgets = {
            'property_id': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Property ID'}),
            'ad_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Ad Name'}),
            'json_key': forms.FileInput(attrs={'class': 'form-control'}),
        }

    def __init__(self, *args, **kwargs):
        super(GoogleAnalyticsAccountForm, self).__init__(*args, **kwargs)
        # Set custom error messages
        self.fields['property_id'].error_messages = {
            'required': 'Property ID is required. Please enter a Property ID.',
        }
        self.fields['ad_name'].error_messages = {
            'required': 'Ad Name is required. Please enter an Ad Name.',
        }
        self.fields['json_key'].error_messages = {
            'required': 'File upload is required. Please select a file.',
        }




