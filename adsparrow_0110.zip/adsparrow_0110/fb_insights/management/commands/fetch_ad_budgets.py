# # # your_app/management/commands/fetch_ad_budgets.py

# # from django.core.management.base import BaseCommand
# # from facebook_business.api import FacebookAdsApi
# # from facebook_business.adobjects.adaccount import AdAccount
# # from fb_insights.models import AdAccount as AdAccountModel  # Adjust import as necessary

# # class Command(BaseCommand):
# #     help = 'Fetch current ad set daily budgets from Facebook Ad Manager'

# #     def handle(self, *args, **kwargs):
# #         # Fetch all active ad accounts
# #         ad_accounts = AdAccountModel.objects.filter(is_active=True)

# #         for account in ad_accounts:
# #             try:
# #                 # Initialize the Facebook API
# #                 FacebookAdsApi.init(account.app_id, account.app_secret_key, account.access_token)

# #                 # Fetch ad sets for the account
# #                 account_id = 'act_' + account.ad_account_id
# #                 ad_account = AdAccount(account_id)
# #                 ad_sets = ad_account.get_ad_sets(fields=['id', 'name', 'daily_budget'])

# #                 for ad_set in ad_sets:
# #                     ad_name = ad_set.get('name')
# #                     daily_budget_cents_str = ad_set.get('daily_budget', '0')  # Budget as a string
# #                     daily_budget_cents = int(daily_budget_cents_str)  # Convert to integer
# #                     daily_budget_dollars = daily_budget_cents / 100  # Convert to dollars

# #                     print(f'Ad Set: {ad_name}, Daily Budget: {daily_budget_dollars:.2f}')  # Format to 2 decimal places
                    
# #             except Exception as e:
# #                 self.stderr.write(f'Error fetching data for account {account.ad_account_id}: {str(e)}')





# # your_app/management/commands/fetch_ad_budgets.py

# # from django.core.management.base import BaseCommand
# # from facebook_business.api import FacebookAdsApi
# # from facebook_business.adobjects.adaccount import AdAccount
# # from fb_insights.models import AdAccount as AdAccountModel, Ad  # Adjust import as necessary
# # from datetime import datetime

# # class Command(BaseCommand):
# #     help = 'Fetch current ad set daily budgets from Facebook Ad Manager'

# #     def handle(self, *args, **kwargs):
# #         # Fetch all active ad accounts
# #         ad_accounts = AdAccountModel.objects.filter(is_active=True)

# #         # Get today's date
# #         today_date = datetime.now().date()

# #         for account in ad_accounts:
# #             try:
# #                 # Initialize the Facebook API
# #                 FacebookAdsApi.init(account.app_id, account.app_secret_key, account.access_token)

# #                 # Fetch ad sets for the account
# #                 account_id = 'act_' + account.ad_account_id
# #                 ad_account = AdAccount(account_id)
# #                 ad_sets = ad_account.get_ad_sets(fields=['id', 'name', 'daily_budget'])

# #                 for ad_set in ad_sets:
# #                     ad_name = ad_set.get('name')
# #                     daily_budget_cents_str = ad_set.get('daily_budget', '0')  # Budget as a string
# #                     daily_budget_cents = int(daily_budget_cents_str)  # Convert to integer
# #                     daily_budget_dollars = daily_budget_cents / 100  # Convert to dollars

# #                     # Print the fetched budget
# #                     print(f'Ad Set: {ad_name}, Daily Budget: {daily_budget_dollars:.2f}')  # Format to 2 decimal places

# #                     # Update the corresponding Ad model instance by ad name and today's date
# #                     try:
# #                         # Find the Ad instance where the name matches and the date is today
# #                         ad_instance = Ad.objects.get(name=ad_name, start_date=today_date, end_date=today_date)
# #                         ad_instance.ad_set_budget = daily_budget_dollars  # Update the budget
# #                         ad_instance.save()  # Save the changes
# #                         self.stdout.write(f'Updated budget for {ad_name} to {daily_budget_dollars:.2f}.')
# #                     except Ad.DoesNotExist:
# #                         self.stderr.write(f'No matching ad found for {ad_name} with start_date {today_date} and end_date {today_date}.')

# #             except Exception as e:
# #                 self.stderr.write(f'Error fetching data for account {account.ad_account_id}: {str(e)}')





# # your_app/management/commands/fetch_ad_budgets.py
# # your_app/management/commands/fetch_ad_budgets.py

# from django.core.management.base import BaseCommand
# from facebook_business.api import FacebookAdsApi
# from facebook_business.adobjects.adaccount import AdAccount
# from fb_insights.models import AdAccount as AdAccountModel, Ad, CronJobLog, CustomUser  # Adjust import as necessary
# from datetime import datetime

# class Command(BaseCommand):
#     help = 'Fetch current ad set daily budgets from Facebook Ad Manager'

#     def handle(self, *args, **kwargs):
#         # Fetch all active ad accounts
#         ad_accounts = AdAccountModel.objects.filter(is_active=True)
        
#         # Get today's date
#         today_date = datetime.now().date()

#         for account in ad_accounts:
#             user = account.user  # Assuming the relationship exists, fetch the associated user
#             log_status = 'success'  # Initialize log status
#             total_updates = 0
#             total_skips = 0

#             try:
#                 # Initialize the Facebook API
#                 FacebookAdsApi.init(account.app_id, account.app_secret_key, account.access_token)

#                 # Fetch ad sets for the account
#                 account_id = 'act_' + account.ad_account_id
#                 ad_account = AdAccount(account_id)
#                 ad_sets = ad_account.get_ad_sets(fields=['id', 'name', 'daily_budget'])

#                 for ad_set in ad_sets:
#                     ad_name = ad_set.get('name')
#                     daily_budget_cents_str = ad_set.get('daily_budget', '0')  # Budget as a string
#                     daily_budget_cents = int(daily_budget_cents_str)  # Convert to integer
#                     daily_budget_dollars = daily_budget_cents / 100  # Convert to dollars

#                     # Update the corresponding Ad model instance by ad name and today's date
#                     try:
#                         # Find the Ad instance where the name matches and the date is today
#                         ad_instance = Ad.objects.get(name=ad_name, start_date=today_date, end_date=today_date)
#                         ad_instance.ad_set_budget = daily_budget_dollars  # Update the budget
#                         ad_instance.save()  # Save the changes
#                         total_updates += 1  # Increment successful updates
#                     except Ad.DoesNotExist:
#                         total_skips += 1  # Increment skips for missing ads

#             except Exception as e:
#                 log_status = 'failed'
#                 log_message = f'Error fetching data for account {account.ad_account_id}: {str(e)}'
#                 total_skips += len(ad_sets)  # Consider all ad sets as skipped if an error occurs
#             else:
#                 log_message = f'Success: {total_updates} budget updates; Skipped: {total_skips} ads.'

#             # Log the results in the CronJobLog table
#             log_entry = CronJobLog.objects.create(
#                 user=user,
#                 ad_account=account,  # Associate the last account processed
#                 status=log_status,
#                 message=log_message.strip()  # Remove any trailing whitespace
#             )
#             log_entry.save()  # Save the log entry
#             self.stdout.write(f'Cron job log created: {log_entry}')


#----- working code---

# from django.core.management.base import BaseCommand
# from facebook_business.api import FacebookAdsApi
# from facebook_business.adobjects.adaccount import AdAccount
# from fb_insights.models import AdAccount as AdAccountModel, Ad, CronJobLog  # Adjust import as necessary
# from datetime import datetime

# import time
# from facebook_business.exceptions import FacebookRequestError

# class Command(BaseCommand):
#     help = 'Fetch current ad set daily budgets from Facebook Ad Manager for all users and accounts'

#     def handle(self, *args, **kwargs):
#         # Get today's date
#         today_date = datetime.now().date()

#         # Fetch all active users and their corresponding ad accounts
#         all_users = AdAccountModel.objects.filter(is_active=True).values('user_id').distinct()

#         for user in all_users:
#             user_id = user['user_id']  # Extract user_id from the queryset
#             user_ad_accounts = AdAccountModel.objects.filter(user_id=user_id, is_active=True)

#             if not user_ad_accounts.exists():
#                 self.stdout.write(f'No active ad accounts found for user ID {user_id}.')
#                 continue  # Skip to the next user if no accounts are found

#             self.stdout.write(f'Processing user ID {user_id} with {user_ad_accounts.count()} active ad accounts...')

#             # Iterate through each ad account for the user
#             for account in user_ad_accounts:
#                 log_status = 'success'  # Initialize log status
#                 total_updates = 0
#                 total_skips = 0

#                 try:
#                     # Initialize the Facebook API
#                     FacebookAdsApi.init(account.app_id, account.app_secret_key, account.access_token)

#                     # Fetch ad sets for the account
#                     account_id = 'act_' + account.ad_account_id
#                     ad_account = AdAccount(account_id)

#                     # Retry logic for handling rate limit
#                     retries = 3  # Maximum retry attempts
#                     for attempt in range(retries):
#                         try:
#                             ad_sets = ad_account.get_ad_sets(fields=['id', 'name', 'daily_budget', 'status'])
#                             break  # Exit the retry loop if successful
#                         except FacebookRequestError as e:
#                             if 'User request limit reached' in str(e):
#                                 if attempt < retries - 1:
#                                     self.stderr.write(f"Rate limit exceeded. Retrying in 30 seconds... Attempt {attempt + 1}/{retries}")
#                                     time.sleep(30)  # Wait 30 seconds before retrying
#                                     continue
#                                 else:
#                                     log_status = 'failed'
#                                     log_message = f'Rate limit exceeded after {retries} attempts for account {account.ad_account_id}.'
#                                     break
#                             else:
#                                 raise  # Raise other exceptions
#                     else:
#                         continue  # Skip to the next ad account if max retries reached

#                     for ad_set in ad_sets:
#                         ad_name = ad_set.get('name')
#                         daily_budget_cents_str = ad_set.get('daily_budget', '0')  # Budget as a string
#                         daily_budget_cents = int(daily_budget_cents_str)  # Convert to integer
#                         daily_budget_dollars = daily_budget_cents / 100  # Convert to dollars
#                         ad_status = ad_set.get('status')  # Fetch the status of the ad set

#                         # Update database and log
#                         try:
#                             # Find the Ad instance where the name matches and the date is today
#                             ad_instance = Ad.objects.get(name=ad_name, start_date=today_date, end_date=today_date)
#                             ad_instance.ad_set_budget = daily_budget_dollars  # Update the budget
#                             ad_instance.status = ad_status  # Update the status
#                             ad_instance.save()  # Save the changes
#                             total_updates += 1  # Increment successful updates
#                             self.stdout.write(f'Updated {ad_name}: Budget={daily_budget_dollars:.2f}, Status={ad_status}')
#                         except Ad.DoesNotExist:
#                             total_skips += 1  # Increment skips for missing ads
#                             self.stderr.write(f'Skipped {ad_name}: No matching Ad instance found. Status={ad_status}')


#                 except Exception as e:
#                     log_status = 'failed'
#                     log_message = f'Error fetching data for account {account.ad_account_id}: {str(e)}'
#                     total_skips += 1
#                 else:
#                     log_message = f'Success: {total_updates} budget updates; Skipped: {total_skips} ads.'

#                 # Log the results in the CronJobLog table
#                 log_entry = CronJobLog.objects.create(
#                     user=account.user,
#                     ad_account=account,
#                     status=log_status,
#                     message=log_message.strip()
#                 )
#                 log_entry.save()
#                 self.stdout.write(f'Processed account {account.ad_account_id}: {log_message}')

#---------------------------------------------------------------------


# from django.core.management.base import BaseCommand
# from fb_insights.models import AdAccount, Ad, CronJobLog
# from facebook_business.api import FacebookAdsApi
# from facebook_business.adobjects.adsinsights import AdsInsights
# from django.utils import timezone
# from facebook_business.adobjects.adaccount import AdAccount as FBAdAccount

# class Command(BaseCommand):
#     help = 'Fetches the spend data for a specific ad account or all accounts'

#     def add_arguments(self, parser):
#         parser.add_argument('--ad_account_id', type=str, help='The ID of the ad account to fetch insights for')
#         parser.add_argument('--user_id', type=int, help='The ID of the user to fetch insights for', default=None)

#     def handle(self, *args, **options):
#         ad_account_id = options['ad_account_id']
#         user_id = options['user_id']

#         # Get today's date
#         today = timezone.now().date()

#         # Filter AdAccounts based on user and status
#         if user_id:
#             ad_accounts = AdAccount.objects.filter(user_id=user_id, is_active=True)
#         elif ad_account_id:
#             ad_accounts = AdAccount.objects.filter(ad_account_id=ad_account_id, is_active=True)
#         else:
#             ad_accounts = AdAccount.objects.filter(is_active=True)

#         for ad_account in ad_accounts:
#             # Initialize CronJobLog entry
#             cron_log = CronJobLog.objects.create(
#                 user=ad_account.user,
#                 ad_account=ad_account,
#                 status='pending',
#                 message='Cron job started'
#             )

#             try:
#                 # Initialize the Facebook Ads API
#                 FacebookAdsApi.init(ad_account.app_id, ad_account.app_secret_key, ad_account.access_token)
#                 fb_ad_account = FBAdAccount(f'act_{ad_account.ad_account_id}')

#                 # Include the 'name' field to get the ad name along with the spend data
#                 insights_fields = [AdsInsights.Field.spend, AdsInsights.Field.ad_name]

#                 # Set parameters for today
#                 params = {
#                     'time_range': {'since': today.strftime('%Y-%m-%d'), 'until': today.strftime('%Y-%m-%d')},
#                     'level': 'ad',
#                     'time_increment': 1,
#                 }

#                 insights = fb_ad_account.get_insights(fields=insights_fields, params=params)

#                 updated_count = 0
#                 skipped_count = 0

#                 for insight in insights:
#                     spend = float(insight.get('spend', '0'))
#                     ad_name = insight.get('ad_name', 'No Ad Name')

#                     try:
#                         # Update existing Ad record
#                         ad = Ad.objects.get(
#                             name=ad_name,
#                             ad_account=ad_account,
#                             start_date=today,
#                             end_date=today
#                         )
#                         ad.spend = spend
#                         ad.save()
#                         updated_count += 1
#                     except Ad.DoesNotExist:
#                         # Log skipped Ads
#                         skipped_count += 1

#                 # Update cron log status and message
#                 cron_log.status = 'success'
#                 cron_log.message = f"Updated {updated_count} Ads, skipped {skipped_count} Ads"
#                 cron_log.save()
#                 self.stdout.write(self.style.SUCCESS(f"Updated {updated_count} Ads Amount Spends, skipped {skipped_count} Ads for Ad Account: {ad_account.ad_account_id}"))

#             except Exception as e:
#                 # Handle errors and update cron log
#                 cron_log.status = 'failed'
#                 cron_log.message = f"Error: {str(e)}"
#                 cron_log.save()
#                 self.stdout.write(self.style.ERROR(f"Error fetching insights for Ad Account {ad_account.ad_account_id}: {str(e)}"))


#-------------------- final save amount spend --------------------

#------ final save amount spend and status --------------------
from django.core.management.base import BaseCommand
from fb_insights.models import AdAccount, Ad, CronJobLog
from facebook_business.api import FacebookAdsApi
from facebook_business.adobjects.adsinsights import AdsInsights
from facebook_business.adobjects.ad import Ad as FBAd
from django.utils import timezone

# class Command(BaseCommand):
#     help = 'Fetches the spend data and status for a specific ad account or all accounts'

#     def add_arguments(self, parser):
#         parser.add_argument('--ad_account_id', type=str, help='The ID of the ad account to fetch insights for')
#         parser.add_argument('--user_id', type=int, help='The ID of the user to fetch insights for', default=None)

#     def handle(self, *args, **options):
#         ad_account_id = options['ad_account_id']
#         user_id = options['user_id']

#         today = timezone.now().date()

#         if user_id:
#             ad_accounts = AdAccount.objects.filter(user_id=user_id, is_active=True)
#         elif ad_account_id:
#             ad_accounts = AdAccount.objects.filter(ad_account_id=ad_account_id, is_active=True)
#         else:
#             ad_accounts = AdAccount.objects.filter(is_active=True)

#         for ad_account in ad_accounts:
#             cron_log = CronJobLog.objects.create(
#                 user=ad_account.user,
#                 ad_account=ad_account,
#                 status='pending',
#                 message='Cron job started'
#             )

#             try:
#                 FacebookAdsApi.init(ad_account.app_id, ad_account.app_secret_key, ad_account.access_token)
#                 updated_count = 0
#                 skipped_count = 0

#                 fb_ad_account = FBAd(f'act_{ad_account.ad_account_id}')
#                 params = {
#                     'time_range': {'since': today.strftime('%Y-%m-%d'), 'until': today.strftime('%Y-%m-%d')},
#                     'level': 'ad',
#                     'time_increment': 1,
#                 }

#                 # Fetch insights data
#                 insights_fields = [AdsInsights.Field.spend, AdsInsights.Field.ad_name,  AdsInsights.Field.ad_id]
#                 insights = fb_ad_account.get_insights(fields=insights_fields, params=params)

#                 for insight in insights:
#                     print("Insight Data:", insight)  # Print the raw insight data to the terminal
#                     ad_id = insight.get('ad_id')  # Safely get 'ad_id'
#                     if not ad_id:
#                         self.stdout.write(self.style.WARNING("Skipping insight due to missing 'ad_id'"))
#                         skipped_count += 1
#                         continue  # Skip to the next insight

#                     spend = float(insight.get('spend', '0'))
#                     ad_name = insight.get('ad_name', 'No Ad Name')

#                     try:
#                         # Fetch ad status
#                         fb_ad = FBAd(ad_id)
#                         ad_status_data = fb_ad.api_get(fields=['configured_status', 'effective_status'])
#                         configured_status = ad_status_data.get('configured_status', 'UNKNOWN')
#                         effective_status = ad_status_data.get('effective_status', 'UNKNOWN')

#                         print(f"Ad ID: {ad_id}, Configured Status: {configured_status}, Effective Status: {effective_status}")  # Print the status data

#                         # Update existing Ad record
#                         ad = Ad.objects.get(
#                             name=ad_name,
#                             ad_account=ad_account,
#                             start_date=today,
#                             end_date=today
#                         )
#                         ad.spend = spend
#                         ad.ad_delivery = effective_status  # Update the ad status
#                         ad.save()
#                         updated_count += 1
#                     except Ad.DoesNotExist:
#                         skipped_count += 1
#                     except Exception as e:
#                         self.stdout.write(self.style.ERROR(f"Error fetching status for Ad ID {ad_id}: {str(e)}"))

#                 cron_log.status = 'success'
#                 cron_log.message = f"Updated {updated_count} Ads, skipped {skipped_count} Ads"
#                 cron_log.save()

#                 self.stdout.write(self.style.SUCCESS(
#                     f"Updated {updated_count} Ads with spend and status, skipped {skipped_count} Ads for Ad Account: {ad_account.ad_account_id}"
#                 ))

#             except Exception as e:
#                 cron_log.status = 'failed'
#                 cron_log.message = f"Error: {str(e)}"
#                 cron_log.save()

#                 self.stdout.write(self.style.ERROR(f"Error fetching insights for Ad Account {ad_account.ad_account_id}: {str(e)}"))





from datetime import timedelta

class Command(BaseCommand):
    help = 'Fetches the spend data and status for a specific ad account or all accounts'

    def add_arguments(self, parser):
        parser.add_argument('--ad_account_id', type=str, help='The ID of the ad account to fetch insights for')
        parser.add_argument('--user_id', type=int, help='The ID of the user to fetch insights for', default=None)

    def handle(self, *args, **options):
        ad_account_id = options['ad_account_id']
        user_id = options['user_id']

        today = timezone.now().date()
        yesterday = today - timedelta(days=1)

        if user_id:
            ad_accounts = AdAccount.objects.filter(user_id=user_id, is_active=True)
        elif ad_account_id:
            ad_accounts = AdAccount.objects.filter(ad_account_id=ad_account_id, is_active=True)
        else:
            ad_accounts = AdAccount.objects.filter(is_active=True)

        for ad_account in ad_accounts:
            cron_log = CronJobLog.objects.create(
                user=ad_account.user,
                ad_account=ad_account,
                status='pending',
                message='Cron job started'
            )

            try:
                FacebookAdsApi.init(ad_account.app_id, ad_account.app_secret_key, ad_account.access_token)
                updated_count = 0
                skipped_count = 0

                fb_ad_account = FBAd(f'act_{ad_account.ad_account_id}')
                # Loop over today and yesterday to fetch data
                for date in [yesterday, today]:
                    params = {
                        'time_range': {'since': date.strftime('%Y-%m-%d'), 'until': date.strftime('%Y-%m-%d')},
                        'level': 'ad',
                        'time_increment': 1,
                    }

                    # Fetch insights data
                    insights_fields = [AdsInsights.Field.spend, AdsInsights.Field.ad_name,  AdsInsights.Field.ad_id]
                    insights = fb_ad_account.get_insights(fields=insights_fields, params=params)

                    for insight in insights:
                        print("Insight Data:", insight)  # Print the raw insight data to the terminal
                        ad_id = insight.get('ad_id')  # Safely get 'ad_id'
                        if not ad_id:
                            self.stdout.write(self.style.WARNING("Skipping insight due to missing 'ad_id'"))
                            skipped_count += 1
                            continue  # Skip to the next insight

                        spend = float(insight.get('spend', '0'))
                        ad_name = insight.get('ad_name', 'No Ad Name')

                        try:
                            # Fetch ad status
                            fb_ad = FBAd(ad_id)
                            ad_status_data = fb_ad.api_get(fields=['configured_status', 'effective_status'])
                            configured_status = ad_status_data.get('configured_status', 'UNKNOWN')
                            effective_status = ad_status_data.get('effective_status', 'UNKNOWN')

                            print(f"Ad ID: {ad_id}, Configured Status: {configured_status}, Effective Status: {effective_status}")  # Print the status data

                            # Update existing Ad record
                            ad = Ad.objects.get(
                                name=ad_name,
                                ad_account=ad_account,
                                start_date=date,
                                end_date=date
                            )
                            ad.spend = spend
                            ad.ad_delivery = effective_status  # Update the ad status
                            ad.save()
                            updated_count += 1
                        except Ad.DoesNotExist:
                            skipped_count += 1
                        except Exception as e:
                            self.stdout.write(self.style.ERROR(f"Error fetching status for Ad ID {ad_id}: {str(e)}"))

                cron_log.status = 'success'
                cron_log.message = f"Updated {updated_count} Ads, skipped {skipped_count} Ads"
                cron_log.save()

                self.stdout.write(self.style.SUCCESS(
                    f"Updated {updated_count} Ads with spend and status, skipped {skipped_count} Ads for Ad Account: {ad_account.ad_account_id}"
                ))

            except Exception as e:
                cron_log.status = 'failed'
                cron_log.message = f"Error: {str(e)}"
                cron_log.save()

                self.stdout.write(self.style.ERROR(f"Error fetching insights for Ad Account {ad_account.ad_account_id}: {str(e)}"))
