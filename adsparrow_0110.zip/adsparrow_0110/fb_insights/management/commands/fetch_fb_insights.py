from django.core.management.base import BaseCommand
from fb_insights.models import AdAccount, CronJobLog
from fb_insights.views import fetch_and_update_insights  # Import the function you already wrote
from facebook_business.api import FacebookAdsApi
from facebook_business.adobjects.adaccount import AdAccount as FBAdAccount
from facebook_business.exceptions import FacebookRequestError
from django.utils import timezone
import requests

class Command(BaseCommand):
    help = 'Fetch insights for each Facebook Ad Account every 2 hours'

    def handle(self, *args, **options):
        # Fetch all active ad accounts
        ad_accounts = AdAccount.objects.filter(is_active=True)
        
        if ad_accounts.exists():  # Check if any ad accounts exist
            for ad_account in ad_accounts:
                # Initialize Facebook Ads API with the credentials
                FacebookAdsApi.init(ad_account.app_id, ad_account.app_secret_key, ad_account.access_token)
                fb_ad_account = FBAdAccount(f'act_{ad_account.ad_account_id}')

                try:
                    # Fetch insights data for this account
                    fetch_and_update_insights(fb_ad_account, ad_account)

                    # Update the status if necessary (if you want to set it to 'success' after fetching)
                    ad_account.account_status = 'success'
                    ad_account.save()

                    # Log success
                    CronJobLog.objects.create(
                        user=ad_account.user,
                        ad_account=ad_account,
                        status='success',
                        message=f'Successfully fetched insights for {ad_account.account_name}.',
                    )
                    self.stdout.write(self.style.SUCCESS(f'Successfully fetched insights for {ad_account.account_name}.'))

                except FacebookRequestError as e:
                    if e.api_error_code() == 190 and e.api_error_subcode() == 463:  # Token expired
                        self.stdout.write(self.style.WARNING(f'Token expired for {ad_account.account_name}, attempting to refresh token...'))
                        new_token = self.refresh_access_token(ad_account)

                        if new_token:
                            ad_account.access_token = new_token
                            ad_account.save()

                            # Re-initialize Facebook API with the new token
                            FacebookAdsApi.init(ad_account.app_id, ad_account.app_secret_key, new_token)
                            
                            try:
                                fetch_and_update_insights(fb_ad_account, ad_account)
                                ad_account.account_status = 'success'
                                ad_account.save()
                                CronJobLog.objects.create(
                                    user=ad_account.user,
                                    ad_account=ad_account,
                                    status='success',
                                    message=f'Successfully fetched insights after refreshing token for {ad_account.account_name}.',
                                )
                                self.stdout.write(self.style.SUCCESS(f'Successfully fetched insights for {ad_account.account_name} after refreshing token.'))

                            except Exception as e:
                                ad_account.account_status = 'failed'
                                ad_account.save()
                                CronJobLog.objects.create(
                                    user=ad_account.user,
                                    ad_account=ad_account,
                                    status='failed',
                                    message=f'Failed after token refresh for {ad_account.account_name}: {e}',
                                )
                                self.stdout.write(self.style.ERROR(f'Failed to fetch insights for {ad_account.account_name} after token refresh: {e}'))

                        else:
                            ad_account.account_status = 'failed'
                            ad_account.save()
                            CronJobLog.objects.create(
                                user=ad_account.user,
                                ad_account=ad_account,
                                status='failed',
                                message=f'Failed to refresh token for {ad_account.account_name}.',
                            )
                            self.stdout.write(self.style.ERROR(f'Failed to refresh token for {ad_account.account_name}.'))

                    else:
                        ad_account.account_status = 'failed'
                        ad_account.save()

                        # Log failure with specific error
                        CronJobLog.objects.create(
                            user=ad_account.user,
                            ad_account=ad_account,
                            status='failed',
                            message=f'Failed to fetch insights for {ad_account.account_name}: {e}',
                        )
                        self.stdout.write(self.style.ERROR(f'Failed to fetch insights for {ad_account.account_name}: {e}'))

                except Exception as e:
                    ad_account.account_status = 'failed'
                    ad_account.save()

                    # Log general failure
                    CronJobLog.objects.create(
                        user=ad_account.user,
                        ad_account=ad_account,
                        status='failed',
                        message=f'An error occurred for {ad_account.account_name}: {e}',
                    )
                    self.stdout.write(self.style.ERROR(f'An error occurred for {ad_account.account_name}: {e}'))

            self.stdout.write(self.style.SUCCESS('Finished fetching insights for all accounts.'))
        else:
            # No ad accounts found
            self.stdout.write(self.style.WARNING('No active ad accounts found.'))

            # Log the absence of ad accounts
            CronJobLog.objects.create(
                user=None,  # If no ad accounts are processed, user could be set to None or an appropriate user
                ad_account=None,
                status='warning',
                message='No active ad accounts found.',
            )

    def refresh_access_token(self, ad_account):
        """
        Refresh the access token using the Facebook OAuth API.
        """
        token_exchange_url = 'https://graph.facebook.com/v20.0/oauth/access_token'
        params = {
            'grant_type': 'fb_exchange_token',
            'client_id': ad_account.app_id,
            'client_secret': ad_account.app_secret_key,
            'fb_exchange_token': ad_account.access_token,
        }
        
        try:
            response = requests.get(token_exchange_url, params=params)
            response_data = response.json()

            if 'access_token' in response_data:
                return response_data['access_token']
            else:
                self.stdout.write(self.style.ERROR(f"Failed to refresh token: {response_data.get('error', {}).get('message', 'Unknown error')}"))
                return None

        except requests.RequestException as e:
            self.stdout.write(self.style.ERROR(f"Error during token refresh: {e}"))
            return None
