# fb_insights/management/commands/fetch_ga_data.py

import traceback
from datetime import timedelta
from django.core.management.base import BaseCommand
from django.utils import timezone
from fb_insights.models import GoogleAnalyticsAccount, TrafficSourceMedium, CronJobLog
from google.analytics.data_v1beta import BetaAnalyticsDataClient, DateRange, Metric, Dimension, RunReportRequest
from google.oauth2 import service_account

class Command(BaseCommand):
    help = 'Fetch Google Analytics data for active accounts'

    def handle(self, *args, **kwargs):
        now = timezone.now()
        # Get all active Google Analytics accounts
        accounts = GoogleAnalyticsAccount.objects.filter(is_active=True)

        for account in accounts:
            json_key_path = account.json_key.path
            property_id = account.property_id
            today = timezone.now().date()

            # Create a log entry
            cron_log = CronJobLog(user=account.user, ga_ad_account=account)
            cron_log.status = 'pending'
            cron_log.save()

            try:
                # Fetch GA4 report for the last 3 days
                for i in range(3):
                    day = today - timedelta(days=i)
                    start_date = day.strftime('%Y-%m-%d')
                    end_date = day.strftime('%Y-%m-%d')

                    response = self.get_ga4_report(json_key_path, property_id, start_date, end_date)

                    for row in response.rows:
                        source = row.dimension_values[0].value
                        medium = row.dimension_values[1].value
                        sessions = int(row.metric_values[0].value)
                        active_users = int(row.metric_values[1].value)
                        total_revenue = float(row.metric_values[2].value)

                        # Update or create TrafficSourceMedium
                        TrafficSourceMedium.objects.update_or_create(
                            account=account,
                            source=source,
                            medium=medium,
                            start_date=start_date,
                            end_date=end_date,
                            defaults={
                                'sessions': sessions,
                                'active_users': active_users,
                                'total_revenue': total_revenue
                            }
                        )

                # Update log status
                cron_log.status = 'success'
                cron_log.message = 'Data synced successfully.'
                cron_log.save()

            except Exception as e:
                # Capture traceback for debugging
                error_message = str(e)
                traceback_info = traceback.format_exc()
                cron_log.status = 'failed'
                cron_log.message = f"{error_message}\nTraceback:\n{traceback_info}"
                cron_log.save()
                self.stderr.write(f"Error: {error_message}\nTraceback:\n{traceback_info}")

    def get_ga4_report(self, json_key_path, property_id, start_date, end_date):
        credentials = service_account.Credentials.from_service_account_file(json_key_path)
        client = BetaAnalyticsDataClient(credentials=credentials)

        request = RunReportRequest(
            property=f"properties/{property_id}",
            date_ranges=[DateRange(start_date=start_date, end_date=end_date)],
            metrics=[
                Metric(name="sessions"),
                Metric(name="activeUsers"),
                Metric(name="totalRevenue")
            ],
            dimensions=[
                Dimension(name="sessionSource"),
                Dimension(name="sessionMedium")
            ]
        )

        response = client.run_report(request=request)
        return response
