from django.core.management.base import BaseCommand
from datetime import timedelta
from django.utils import timezone
from fb_insights.models import CronJobLog
from fb_insights.management.commands. fetch_ad_budgets import Command as FetchInsightsCommand
from fb_insights.management.commands.fetch_ga_data import Command as FetchGADataCommand
from fb_insights.management.commands.fetch_fb_insights import Command as FetchAdDataCommand

class Command(BaseCommand):
    help = 'Retry failed tasks if they failed more than 1 hour ago'

    def handle(self, *args, **kwargs):
        # Get the current time
        current_time = timezone.now()
        one_hour_ago = current_time - timedelta(hours=1)

        # Find failed tasks that were logged more than 1 hour ago
        failed_logs = CronJobLog.objects.filter(status='failed', created_at__lt=one_hour_ago)

        if not failed_logs.exists():
            self.stdout.write(self.style.SUCCESS('No failed tasks to retry.'))
            return

        for log in failed_logs:
            # Check the type of task that failed and retry it
            if 'fetch insights' in log.message:
                self.retry_fetch_insights(log)
            elif 'fetch GA data' in log.message:
                self.retry_fetch_ga_data(log)
            elif 'fetch ad data' in log.message:
                self.retry_fetch_ad_data(log)
            else:
                self.stdout.write(self.style.WARNING(f'Unknown failed task for log {log.id}, skipping.'))

    def retry_fetch_insights(self, log):
        # Retry the 'fetch insights' task
        try:
            # Change status to 'retrying'
            log.status = 'retrying'
            log.save()

            # Run the task again
            command = FetchInsightsCommand()
            command.handle()

            # If successful, update the log status
            log.status = 'success'
            log.message = 'Successfully retried the fetch insights task.'
            log.save()

            self.stdout.write(self.style.SUCCESS(f'Retried fetch insights task for log {log.id} successfully.'))

        except Exception as e:
            log.status = 'failed'
            log.message = f'Failed to retry fetch insights task: {str(e)}'
            log.save()
            self.stdout.write(self.style.ERROR(f'Error retrying fetch insights task for log {log.id}: {str(e)}'))

    def retry_fetch_ga_data(self, log):
        # Retry the 'fetch GA data' task
        try:
            # Change status to 'retrying'
            log.status = 'retrying'
            log.save()

            # Run the task again
            command = FetchGADataCommand()
            command.handle()

            # If successful, update the log status
            log.status = 'success'
            log.message = 'Successfully retried the fetch GA data task.'
            log.save()

            self.stdout.write(self.style.SUCCESS(f'Retried fetch GA data task for log {log.id} successfully.'))

        except Exception as e:
            log.status = 'failed'
            log.message = f'Failed to retry fetch GA data task: {str(e)}'
            log.save()
            self.stdout.write(self.style.ERROR(f'Error retrying fetch GA data task for log {log.id}: {str(e)}'))

    def retry_fetch_ad_data(self, log):
        # Retry the 'fetch ad data' task
        try:
            # Change status to 'retrying'
            log.status = 'retrying'
            log.save()

            # Run the task again
            command = FetchAdDataCommand()
            command.handle()

            # If successful, update the log status
            log.status = 'success'
            log.message = 'Successfully retried the fetch ad data task.'
            log.save()

            self.stdout.write(self.style.SUCCESS(f'Retried fetch ad data task for log {log.id} successfully.'))

        except Exception as e:
            log.status = 'failed'
            log.message = f'Failed to retry fetch ad data task: {str(e)}'
            log.save()
            self.stdout.write(self.style.ERROR(f'Error retrying fetch ad data task for log {log.id}: {str(e)}'))
