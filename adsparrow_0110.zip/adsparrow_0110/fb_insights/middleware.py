# your_app/middleware.py

import datetime

class CaptureRefererMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)

        # Capture the referer URL and store in session
        referer = request.META.get('HTTP_REFERER')

        if referer:
            request.session['last_referer'] = {
                'url': referer,
                'timestamp': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
        return response
