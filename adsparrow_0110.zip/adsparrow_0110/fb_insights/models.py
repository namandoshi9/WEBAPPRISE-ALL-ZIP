# fb_insights/models.py

from django.db import models
from django.contrib.auth.models import AbstractUser


class CustomUser(AbstractUser):
    # Add any additional fields if needed
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=True)
    is_premium = models.BooleanField(default=False)
    name = models.CharField(max_length=200)

class AdAccount(models.Model):
    STATUS_CHOICES = [
        ('review_pending', 'Review Pending'),
        ('success', 'Success'),
        ('failed', 'Failed'),
    ]

    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='ad_accounts', blank=True, null=True)
    ad_account_id = models.CharField(max_length=50)
    account_name = models.CharField(max_length=100, blank=True, null=True)
    access_token = models.CharField(max_length=255)
    app_id = models.CharField(max_length=50)
    app_secret_key = models.CharField(max_length=255)
    is_visible = models.BooleanField(default=True)
    is_active = models.BooleanField(default=True)
    account_status = models.CharField(max_length=15, choices=STATUS_CHOICES, default='review_pending')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.ad_account_id

class Campaign(models.Model):
    campaign_id = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    ad_account = models.ForeignKey(AdAccount, on_delete=models.CASCADE, related_name='campaigns')  # Added ForeignKey
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

class AdSet(models.Model):
    adset_id = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    campaign = models.ForeignKey(Campaign, on_delete=models.CASCADE, related_name='adsets')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

class Ad(models.Model):
    D_STATUS_CHOICES = [
        ('ACTIVE', 'ACTIVE'),
        ('PAUSED', 'PAUSED'),
    ]
    ad_id = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    adset = models.ForeignKey(AdSet, on_delete=models.CASCADE, related_name='ads')
    impressions = models.IntegerField()
    clicks = models.IntegerField()
    spend = models.FloatField()
    reach = models.IntegerField()
    cpc = models.FloatField()
    cost_per_ad_click = models.FloatField()
    ad_delivery = models.CharField(max_length=50,choices=D_STATUS_CHOICES, default='ACTIVE')
    results = models.FloatField(default=0)  # New field for the results
    cost_per_result = models.FloatField(default=0) 
    ad_set_budget = models.FloatField()  # Ensure this is a FloatField to store dollars
    start_date = models.DateField()
    end_date = models.DateField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    ad_account = models.ForeignKey(AdAccount, on_delete=models.CASCADE, related_name='ads')  # Reference to AdAccount

    def __str__(self):
        return self.name



class GoogleAnalyticsAccount(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='ga_accounts',blank=True, null=True)  # New field
    property_id = models.CharField(max_length=255)
    ad_name = models.CharField(max_length=255,default='Google Analytics')
    json_key = models.FileField(upload_to='google_keys/')
    is_visible = models.BooleanField(default=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    ACCOUNT_STATUS_CHOICES = [
        ('success', 'Success'),
        ('failed', 'Failed'),
        ('review_pending', 'Review Pending'),
    ]
    account_status = models.CharField(max_length=20, choices=ACCOUNT_STATUS_CHOICES, default='review_pending')

    def __str__(self):
        return self.property_id



class TrafficSourceMedium(models.Model):
    account = models.ForeignKey(GoogleAnalyticsAccount, on_delete=models.CASCADE)
    fb_ad_account = models.ForeignKey(AdAccount, on_delete=models.CASCADE,null=True, blank=True)
    source = models.CharField(max_length=255)
    medium = models.CharField(max_length=255)
    sessions = models.IntegerField()
    active_users = models.IntegerField()
    total_revenue = models.FloatField()
    start_date = models.DateField()  # New field for the start date
    end_date = models.DateField()    # New field for the end date
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.source} - {self.medium}"



class CronJobLog(models.Model):
    STATUS_CHOICES = [
        ('success', 'Success'),
        ('failed', 'Failed'),
        ('pending', 'Pending'),
    ]

    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='cron_logs', blank=True, null=True)
    ad_account = models.ForeignKey(AdAccount, on_delete=models.CASCADE, related_name='cron_logs', blank=True, null=True)
    ga_ad_account = models.ForeignKey(GoogleAnalyticsAccount, on_delete=models.CASCADE, related_name='cron_logs', blank=True, null=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    message = models.TextField(blank=True, null=True)  # To store error messages or status messages
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.user} - {self.ad_account} - {self.ga_ad_account} - {self.status} - {self.created_at}"