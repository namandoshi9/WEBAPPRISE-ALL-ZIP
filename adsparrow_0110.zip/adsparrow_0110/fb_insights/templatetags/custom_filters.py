from django import template

register = template.Library()

@register.filter
def sum(values):
    """Returns the sum of a list of numbers."""
    try:
        return sum(values)
        
    except TypeError:
        return 0


from django import template

register = template.Library()

@register.filter
def get(dictionary, key):
    """Custom filter to get a value from a dictionary by key."""
    return dictionary.get(key, 0)  # Return 0 if the key is not found


