from django.urls import path
from .views import toggle_premium_status,ad_report_last_7_days,update_trends_budget,update_trends_ad_status,trends_view,run_fetch_fb_data,run_fetch_ga_data,update_ad_budget,update_ad_status,update_ad_account_status,manage_user_view,login_view,logout_view,update_user_view,master_dashboard_view,fetch_fb_insights,admin_dashboard_view,google_analytics_view,toggle_visibility,toggle_active,analytics_view

urlpatterns = [
    
    
    path('manage_user/', manage_user_view, name='manage_user'),
    path('toggle-premium-status/', toggle_premium_status, name='toggle_premium_status'),
    path('update_user/<int:user_id>/', update_user_view, name='update_user'),
    path('', login_view, name='login'),
    path('logout/', logout_view, name='logout'),

    path('admin_dashboard', admin_dashboard_view, name='admin_dashboard'),
    path('master_dashboard', master_dashboard_view, name='master_dashboard'),


    #=============Facebook account====================
    path('fetch', fetch_fb_insights, name='fetch_fb_insights'),

    path('update-ad-account-status', update_ad_account_status, name='update_ad_account_status'),

    path('run-fetch-fb-data/', run_fetch_fb_data, name='run-fetch-fb-data'),

    
    

    #=============Google account====================
    path('google-analytics', google_analytics_view, name='google_analytics'),

    path('toggle_visibility', toggle_visibility, name='toggle_visibility'),
    path('toggle_active', toggle_active, name='toggle_active'),

    path('run-fetch-ga-data/', run_fetch_ga_data, name='run_fetch_ga_data'),

    
    #=============Analytics====================
    path('analytics', analytics_view, name='analytics'),
    # path('update_ad_status/<int:ad_id>/', update_ad_status, name='update_ad_status'),
    path('update-ad-status/<str:ad_id>/', update_ad_status, name='update_ad_status'),
    # path('update_ad_budget/<int:ad_id>/', update_ad_budget, name='update_ad_budget'),
    path('update_ad_budget/<int:ad_id>/', update_ad_budget, name='update_ad_budget'),


    #============= Trends view ====================
    path('trends', trends_view, name='trends'),
    path('update_trends_ad_status', update_trends_ad_status, name='update_trends_ad_status'),
    path('update-trends-budget/', update_trends_budget, name='update_trends_budget'),

    path('ad_report_last_7_days/<int:ad_id>/', ad_report_last_7_days, name='ad_report_last_7_days'),
    
]
