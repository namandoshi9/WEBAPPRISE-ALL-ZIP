# fb_insights/views.py

from django.shortcuts import render, redirect, get_object_or_404
from .forms import FacebookCredentialsForm, GoogleAnalyticsAccountForm,UserUpdateForm,UserRegistrationForm,LoginForm,FacebookCredentialsForm
from .models import AdAccount, Campaign, AdSet, Ad, GoogleAnalyticsAccount, TrafficSourceMedium,CustomUser,CronJobLog
from fb_insights.models import Ad, AdSet, Campaign, AdAccount
from facebook_business.api import FacebookAdsApi
from facebook_business.adobjects.adaccount import AdAccount as FBAdAccount
from facebook_business.adobjects.adsinsights import AdsInsights
from facebook_business.adobjects.ad import Ad as FacebookAd
from facebook_business.adobjects.adset import AdSet as FacebookAdSet
from facebook_business.adobjects.campaign import Campaign as FacebookCampaign
from datetime import datetime, timedelta
from facebook_business.exceptions import FacebookRequestError
from django.db import transaction, IntegrityError
from django.views.decorators.http import require_POST
from django.contrib import messages
from google.analytics.data_v1beta import BetaAnalyticsDataClient
from google.oauth2 import service_account
from google.analytics.data_v1beta.types import DateRange, Metric, Dimension, RunReportRequest
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.utils import timezone  # For handling date and time
from django.utils.dateparse import parse_date
from django.db.models import Sum, Q, OuterRef, Subquery
import json
import requests
import time
import os
import logging



#============Authetication============================



@login_required
def manage_user_view(request):
    if request.method == 'POST':
        if 'update' in request.POST:  # Check if the update form was submitted
            user_id = request.POST.get('user_id')
            user = get_object_or_404(CustomUser, id=user_id)
            form = UserUpdateForm(request.POST, instance=user)
            if form.is_valid():
                form.save()
                return redirect('manage_user')  # Redirect after update
            else:
                # Return the form with errors for the modal
                users = CustomUser.objects.all()
                return render(request, 'fb_insights/manage-user.html', {'form': form, 'users': users, 'show_update_modal': True, 'update_user_id': user_id})

        else:  # Create a new user
            form = UserRegistrationForm(request.POST)
            if form.is_valid():
                form.save()
                return redirect('manage_user')  # Redirect after successful save
            else:
                users = CustomUser.objects.all()
                return render(request, 'fb_insights/manage-user.html', {'form': form, 'users': users, 'show_modal': True})

    else:
        form = UserRegistrationForm()

    users = CustomUser.objects.filter(is_active=True, is_staff=True).exclude(is_superuser=True)
    return render(request, 'fb_insights/manage-user.html', {'form': form, 'users': users})


def update_user_view(request, user_id):
    user = get_object_or_404(CustomUser, id=user_id)
    
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST, instance=user)
        if form.is_valid():
            form.save()
            return redirect('manage_user')  # Redirect to user management page
    else:
        form = UserRegistrationForm(instance=user)
    
    return render(request, 'fb_insights/update_user.html', {'form': form, 'user': user})

from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from django.contrib.auth.decorators import login_required
import json

@login_required
def toggle_premium_status(request):
    if request.method == "POST":
        try:
            # Parse JSON body
            body = json.loads(request.body)
            user_id = body.get('user_id')

            # Get the user object
            user = get_object_or_404(CustomUser, id=user_id)
            user.is_premium = not user.is_premium
            user.save()

            return JsonResponse({'status': 'success', 'is_premium': user.is_premium})
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)}, status=400)
    return JsonResponse({'status': 'error', 'message': 'Invalid request'}, status=400)



def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        
        if form.is_valid():
            email = form.cleaned_data['email']
            password = form.cleaned_data['password']
            
            user = authenticate(request, username=email, password=password)
            
            if user is not None:
                if user.is_active:
                    login(request, user)
                    if user.is_superuser:
                        return redirect('master_dashboard')  # Redirect to master dashboard
                    elif user.is_staff:
                        return redirect('admin_dashboard')  # Redirect to admin dashboard
                    else:
                        messages.error(request, "Access denied.")
                else:
                    messages.error(request, "Your account is inactive.")
            else:
                messages.error(request, "Invalid email or password.")
        # If form is invalid, it will automatically display errors

    else:
        form = LoginForm()

    return render(request, 'fb_insights/login.html', {'form': form})


def logout_view(request):
    logout(request)  # Log the user out
    return redirect('login')  # Redirect to the login page



#=========================== dashboards =============================================


@login_required
def admin_dashboard_view(request):
    # Filter AdAccounts by the logged-in user
    ad_accounts = AdAccount.objects.filter(user=request.user).prefetch_related('cron_logs')
    total_ad_accounts = ad_accounts.count()  # Count only the user's ad accounts

    # Filter GoogleAnalyticsAccounts by the logged-in user
    google_accounts = GoogleAnalyticsAccount.objects.filter(user=request.user).prefetch_related('cron_logs')
    total_google_accounts = google_accounts.count()  # Count only the user's Google accounts

    return render(request, 'fb_insights/admin_dashboard.html', {
        'ad_accounts': ad_accounts,
        'total_ad_accounts': total_ad_accounts,
        'google_accounts': google_accounts,  # Pass google_accounts to the template
        'total_google_accounts': total_google_accounts
    })




@login_required
def master_dashboard_view(request):
    total_users = CustomUser.objects.filter(is_active=True, is_staff=True).exclude(is_superuser=True).count()
    total_ad_accounts = AdAccount.objects.count()
    total_google_accounts = GoogleAnalyticsAccount.objects.count()
    return render(request, 'fb_insights/master_dashboard.html',{'total_users':total_users,'total_ad_accounts':total_ad_accounts,'total_google_accounts':total_google_accounts})



# #==================== Facebook ad data=================================



def extend_fb_token(short_lived_token, app_id, app_secret):
    url = 'https://graph.facebook.com/v20.0/oauth/access_token'
    params = {
        'grant_type': 'fb_exchange_token',
        'client_id': app_id,
        'client_secret': app_secret,
        'fb_exchange_token': short_lived_token
    }

    response = requests.get(url, params=params)
    data = response.json()

    # Check for errors
    if 'error' in data:
        print(f"Error: {data['error']['message']}")
        return None

    # Return the long-lived token
    return data.get('access_token')

@login_required
def fetch_fb_insights(request):
    if request.method == 'POST':
        form = FacebookCredentialsForm(request.POST)
        if form.is_valid():
            short_lived_token = form.cleaned_data['access_token']
            app_secret = form.cleaned_data['app_secret']
            app_id = form.cleaned_data['app_id']
            ad_account_id = form.cleaned_data['ad_account_id']
            account_name = form.cleaned_data['account_name']

            # Extend the short-lived token
            extended_token = extend_fb_token(short_lived_token, app_id, app_secret)

            if not extended_token:
                messages.error(request, 'Failed to extend the access token.')
                return redirect('fetch_fb_insights')

            # Save or update the AdAccount record with the extended token
            ad_account, created = AdAccount.objects.update_or_create(
                ad_account_id=ad_account_id,
                user=request.user,
                defaults={
                    'access_token': extended_token,
                    'app_id': app_id,
                    'app_secret_key': app_secret,
                    'account_name': account_name,
                    'account_status': 'review_pending',
                }
            )

            # Initialize Facebook Ads API with provided credentials
            FacebookAdsApi.init(app_id, app_secret, extended_token)
            fb_ad_account = FBAdAccount(f'act_{ad_account_id}')

            # Attempt to fetch insights data
            try:
                fetch_and_update_insights(fb_ad_account, ad_account)
                ad_account.account_status = 'success'
                messages.success(request, 'Insights fetched successfully!')
                ad_account.save()
            except FacebookRequestError as e:
                if e.api_error_code() == 80004:
                    # Handle rate limit error
                    ad_account.account_status = 'rate_limited'
                    messages.error(request, 'Rate limit reached. Please wait and try again later.')
                else:
                    ad_account.account_status = 'failed'
                    messages.error(request, 'Invalid token or API request error. Status set to Failed.')
                ad_account.save()
            except Exception as e:
                ad_account.account_status = 'failed'
                messages.error(request, f'An error occurred while fetching insights: {e}')
                ad_account.save()

            return redirect('fetch_fb_insights')
    else:
        form = FacebookCredentialsForm()

    ad_accounts = AdAccount.objects.filter(user=request.user).order_by('-id')
    campaigns = Campaign.objects.filter(ad_account__user=request.user)
    adsets = AdSet.objects.filter(campaign__ad_account__user=request.user)
    ads = Ad.objects.filter(adset__campaign__ad_account__user=request.user).order_by('-id')

    return render(request, 'fb_insights/manage-ad-account.html', {
        'form': form,
        'ad_accounts': ad_accounts,
        'campaigns': campaigns,
        'adsets': adsets,
        'ads': ads,
    })



def fetch_and_update_insights(fb_ad_account, ad_account):
    end_date = timezone.now().date()  # 09-11-2024
    start_date = end_date - timedelta(days=3)  # 06-11-2024

    insights_fields = [
        AdsInsights.Field.ad_id,
        AdsInsights.Field.ad_name,
        AdsInsights.Field.adset_id,
        AdsInsights.Field.adset_name,
        AdsInsights.Field.impressions,
        AdsInsights.Field.clicks,
        AdsInsights.Field.spend,
        AdsInsights.Field.reach,
        AdsInsights.Field.cpc,
        AdsInsights.Field.cost_per_ad_click,
        AdsInsights.Field.date_start,
        AdsInsights.Field.date_stop,
        AdsInsights.Field.actions,
        AdsInsights.Field.cost_per_action_type,
    ]

    for day_offset in range(4):  # Iterate over 4 days: 06-11-2024 to 09-11-2024
        current_start_date = start_date + timedelta(days=day_offset)
        current_start_date_str = current_start_date.strftime('%Y-%m-%d')
        current_end_date_str = current_start_date_str  # Fetch data for one day at a time

        params = {
            'time_range': {'since': current_start_date_str, 'until': current_end_date_str},
            'level': 'ad',
            'time_increment': 1,
        }

        try:
            insights = fb_ad_account.get_insights(fields=insights_fields, params=params)

            for insight in insights:
                ad_id = insight.get('ad_id', '')
                ad_name = insight.get('ad_name', '')
                adset_id = insight.get('adset_id', '')
                impressions = int(insight.get('impressions', '0'))
                clicks = int(insight.get('clicks', '0'))
                spend = float(insight.get('spend', '0'))
                reach = int(insight.get('reach', '0'))
                cpc = float(insight.get('cpc', '0'))
                cost_per_ad_click = float(insight.get('cost_per_ad_click', '0'))
                date_start = insight.get('date_start', '')
                date_stop = insight.get('date_stop', '')

                actions = insight.get('actions', [])
                results = 0
                for action in actions:
                    if action.get('action_type') == 'link_click':
                        results = float(action.get('value', 0))
                        break

                cost_per_action_type = insight.get('cost_per_action_type', [])
                cost_per_result = 0
                for action_cost in cost_per_action_type:
                    if action_cost.get('action_type') == 'link_click':
                        cost_per_result = float(action_cost.get('value', 0))
                        break

                adset = FacebookAdSet(adset_id).api_get(fields=[FacebookAdSet.Field.name, FacebookAdSet.Field.campaign_id, FacebookAdSet.Field.daily_budget])
                adset_name = adset.get(FacebookAdSet.Field.name, '')
                campaign_id = adset.get(FacebookAdSet.Field.campaign_id, '')
                ad_set_budget_cents = adset.get(FacebookAdSet.Field.daily_budget, '0')
                ad_set_budget_dollars = float(ad_set_budget_cents) / 100.0

                campaign = FacebookCampaign(campaign_id).api_get(fields=[FacebookCampaign.Field.name])
                campaign_name = campaign.get(FacebookCampaign.Field.name, '')

                campaign_instance, _ = Campaign.objects.get_or_create(
                    campaign_id=campaign_id,
                    defaults={'name': campaign_name, 'ad_account': ad_account}
                )

                adset_instance, _ = AdSet.objects.get_or_create(
                    adset_id=adset_id,
                    defaults={'name': adset_name, 'campaign': campaign_instance}
                )

                ad = FacebookAd(ad_id).api_get(fields=[FacebookAd.Field.status])
                ad_delivery = ad.get(FacebookAd.Field.status, 'N/A')

                existing_ad = Ad.objects.filter(
                    ad_id=ad_id,
                    start_date=date_start,
                    end_date=date_stop
                ).first()

                if existing_ad:
                    existing_ad.impressions = impressions
                    existing_ad.clicks = clicks
                    existing_ad.spend = spend
                    existing_ad.reach = reach
                    existing_ad.cpc = cpc
                    existing_ad.cost_per_ad_click = cost_per_ad_click
                    existing_ad.ad_delivery = ad_delivery
                    existing_ad.ad_set_budget = ad_set_budget_dollars
                    existing_ad.results = results
                    existing_ad.cost_per_result = cost_per_result
                    existing_ad.save()
                else:
                    Ad.objects.create(
                        ad_id=ad_id,
                        name=ad_name,
                        adset=adset_instance,
                        impressions=impressions,
                        clicks=clicks,
                        spend=spend,
                        reach=reach,
                        cpc=cpc,
                        cost_per_ad_click=cost_per_ad_click,
                        ad_delivery=ad_delivery,
                        ad_set_budget=ad_set_budget_dollars,
                        results=results,
                        cost_per_result=cost_per_result,
                        start_date=current_start_date,
                        end_date=current_start_date,
                        ad_account=ad_account
                    )
        except FacebookRequestError as e:
            print(f"Error fetching insights: {e}")
            raise e

@csrf_exempt
def update_ad_account_status(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        ad_account_id = data.get('id')
        status_type = data.get('type')
        new_value = data.get('value')

        try:
            ad_account = AdAccount.objects.get(id=ad_account_id)
            if status_type == 'visibility':
                ad_account.is_visible = new_value
            elif status_type == 'status':
                ad_account.is_active = new_value
            ad_account.save()
            return JsonResponse({'success': True})
        except AdAccount.DoesNotExist:
            return JsonResponse({'success': False, 'error': 'Account not found'})

    return JsonResponse({'success': False, 'error': 'Invalid request'})




@csrf_exempt
def run_fetch_ga_data(request):
    if request.method == 'POST':
        account_id = request.POST.get('account_id')

        try:
            google_account = GoogleAnalyticsAccount.objects.get(id=account_id, user=request.user)

            # Create a new log entry for the job
            log_entry = CronJobLog.objects.create(
                user=request.user,
                ga_ad_account=google_account,
                status='pending',
                message='Started fetching Google Analytics data for yesterday.',
                created_at=timezone.now(),
                updated_at=timezone.now()
            )

            google_account.account_status = 'review_pending'
            google_account.save()

            # Get yesterday's date
            yesterday = datetime.now() - timedelta(days=1)
            start_date = yesterday.strftime('%Y-%m-%d')
            end_date = start_date  # Same day for start and end date to get only yesterday's data

            try:
                # Fetch GA4 report for yesterday
                json_key_path = google_account.json_key.path
                property_id = google_account.property_id
                response = get_ga4_report(json_key_path, property_id, start_date, end_date)

                # Process the fetched data
                for row in response.rows:
                    source = row.dimension_values[0].value
                    medium = row.dimension_values[1].value
                    sessions = int(row.metric_values[0].value)
                    active_users = int(row.metric_values[1].value)
                    total_revenue = float(row.metric_values[2].value)

                    # Save or update the traffic source data
                    traffic_source, created = TrafficSourceMedium.objects.get_or_create(
                        account=google_account,
                        source=source,
                        medium=medium,
                        start_date=start_date,
                        end_date=end_date,
                        defaults={
                            'sessions': sessions,
                            'active_users': active_users,
                            'total_revenue': total_revenue
                        }
                    )

                    if not created:
                        traffic_source.sessions = sessions
                        traffic_source.active_users = active_users
                        traffic_source.total_revenue = total_revenue
                        traffic_source.save()

                google_account.account_status = 'success'
                google_account.save()

                # Update log status to success and log message
                log_entry.status = 'success'
                log_entry.message = 'Google Analytics data fetched successfully and traffic data synced for yesterday.'
                log_entry.updated_at = timezone.now()
                log_entry.save()

                return JsonResponse({'status': 'success', 'updated_status': 'success'})

            except Exception as e:
                google_account.account_status = 'failed'
                google_account.save()

                # Update log status to failed with the error message
                log_entry.status = 'failed'
                log_entry.message = f'Failed to retrieve GA4 data for yesterday: {str(e)}'
                log_entry.updated_at = timezone.now()
                log_entry.save()

                return JsonResponse({'status': 'failed', 'message': f'Failed to retrieve GA4 data for yesterday: {str(e)}'})

        except GoogleAnalyticsAccount.DoesNotExist:
            # If the account is not found
            return JsonResponse({'status': 'failed', 'message': 'Account not found'})

    return JsonResponse({'status': 'failed', 'message': 'Invalid request'})


@login_required
def run_fetch_fb_data(request):
    if request.method == 'POST':
        account_id = request.POST.get('account_id')

        try:
            # Fetch the AdAccount for the logged-in user
            ad_account = AdAccount.objects.get(id=account_id, user=request.user)
            short_lived_token = ad_account.access_token
            app_secret = ad_account.app_secret_key
            app_id = ad_account.app_id
            ad_account_id = ad_account.ad_account_id
            account_name = ad_account.account_name

            # Log entry for this sync task, initially marked as pending
            log = CronJobLog.objects.create(
                user=request.user,
                ad_account=ad_account,
                status='pending',
                message=f'Starting sync for Facebook Ad Account: {account_name} ({ad_account_id})'
            )

            # Extend the short-lived token
            extended_token = extend_fb_token(short_lived_token, app_id, app_secret)

            if not extended_token:
                log.status = 'failed'
                log.message = 'Failed to extend the access token.'
                log.save()
                return JsonResponse({'status': 'failed', 'message': 'Failed to extend the access token.'})

            # Initialize Facebook Ads API with the extended token
            FacebookAdsApi.init(app_id, app_secret, extended_token)
            fb_ad_account = FBAdAccount(f'act_{ad_account_id}')
            
            # Attempt to fetch insights data
            fetch_and_update_insights(fb_ad_account, ad_account)

            # Update account status to 'success'
            ad_account.account_status = 'success'
            ad_account.save()

            # Log success status
            log.status = 'success'
            log.message = f'Successfully fetched insights for Ad Account: {account_name} ({ad_account_id})'
            log.save()

            return JsonResponse({'status': 'success', 'updated_status': 'success'})

        except FacebookRequestError as e:
            if e.api_error_code() == 80004:
                # Handle rate limit error
                ad_account.account_status = 'rate_limited'
                ad_account.save()

                # Log rate-limited status
                log.status = 'failed'
                log.message = 'Rate limit reached. Please try again later.'
                log.save()

                return JsonResponse({'status': 'failed', 'updated_status': 'rate_limited', 'message': 'Rate limit reached. Please try again later.'})

            else:
                # Handle generic API request error
                ad_account.account_status = 'failed'
                ad_account.save()

                # Log failed status
                log.status = 'failed'
                log.message = f'Facebook API request error: {e}'
                log.save()

                return JsonResponse({'status': 'failed', 'updated_status': 'failed', 'message': 'Facebook API request error.'})

        except Exception as e:
            # Handle other exceptions
            ad_account.account_status = 'failed'
            ad_account.save()

            # Log generic failure
            log.status = 'failed'
            log.message = f'An error occurred: {str(e)}'
            log.save()

            return JsonResponse({'status': 'failed', 'updated_status': 'failed', 'message': f'An error occurred: {e}'})




#===============================GOOGLE ANALYTICS DATA======================================================


def get_ga4_report(json_key_path, property_id, start_date, end_date):
    # Authenticate using service account credentials
    credentials = service_account.Credentials.from_service_account_file(json_key_path)
    client = BetaAnalyticsDataClient(credentials=credentials)

    # Create a request to retrieve traffic data
    request = RunReportRequest(
        property=f"properties/{property_id}",
        date_ranges=[DateRange(start_date=start_date, end_date=end_date)],
        metrics=[
            Metric(name="sessions"),
            Metric(name="activeUsers"),
            Metric(name="totalRevenue")
        ],
        dimensions=[
            Dimension(name="sessionSource"),
            Dimension(name="sessionMedium")
        ]
    )

    # Run the report and return the response
    response = client.run_report(request=request)
    return response





@login_required
def google_analytics_view(request):
    if request.method == 'POST':
        form = GoogleAnalyticsAccountForm(request.POST, request.FILES)

        if form.is_valid():
            account_id = request.POST.get('account_id')
            google_account = None

            if account_id:  # If account_id exists, it's an update
                google_account = GoogleAnalyticsAccount.objects.get(id=account_id)
                google_account.property_id = form.cleaned_data['property_id']
                google_account.ad_name = form.cleaned_data['ad_name']
                if request.FILES.get('json_key'):
                    google_account.json_key = request.FILES['json_key']
                google_account.account_status = 'review_pending'
                google_account.save()
            else:  # Otherwise, create a new account
                google_account = form.save(commit=False)
                google_account.user = request.user
                google_account.account_status = 'review_pending'
                google_account.save()

            # Validate if the file is in JSON format
            if not google_account.json_key.name.endswith('.json'):
                google_account.account_status = 'failed'
                google_account.save()
                messages.error(request, 'The uploaded file is not in JSON format.')
                return redirect('google_analytics')

            json_key_path = google_account.json_key.path
            property_id = google_account.property_id
            today = datetime.now().date()

            # Fetch data for the last 3 full days and today
            for i in range(4):
                day = today - timedelta(days=i)
                start_date = day.strftime('%Y-%m-%d')
                end_date = day.strftime('%Y-%m-%d')

                try:
                    # Fetch GA4 report for each day
                    response = get_ga4_report(json_key_path, property_id, start_date, end_date)

                    for row in response.rows:
                        source = row.dimension_values[0].value
                        medium = row.dimension_values[1].value
                        sessions = int(row.metric_values[0].value)
                        active_users = int(row.metric_values[1].value)
                        total_revenue = float(row.metric_values[2].value)

                        # Check if data exists for the same source, medium, and date
                        traffic_source, created = TrafficSourceMedium.objects.get_or_create(
                            account=google_account,
                            source=source,
                            medium=medium,
                            start_date=start_date,
                            end_date=end_date,
                            defaults={
                                'sessions': sessions,
                                'active_users': active_users,
                                'total_revenue': total_revenue
                            }
                        )

                        if not created:
                            # If data already exists (same start_date and end_date), update it
                            traffic_source.sessions = sessions
                            traffic_source.active_users = active_users
                            traffic_source.total_revenue = total_revenue
                            traffic_source.save()

                    google_account.account_status = 'success'
                    google_account.save()
                    messages.success(request, 'Google Analytics account updated and traffic data synced successfully!')

                except Exception as e:
                    google_account.account_status = 'failed'
                    google_account.save()
                    messages.error(request, f'Failed to retrieve GA4 data: {str(e)}')

            return redirect('google_analytics')

        else:
            messages.error(request, 'There was an error with the form. Please try again.')

    else:
        form = GoogleAnalyticsAccountForm()

    accounts = GoogleAnalyticsAccount.objects.filter(user=request.user).order_by('-id')
    total_google_accounts = GoogleAnalyticsAccount.objects.filter(user=request.user).count()
    traffic_sources = TrafficSourceMedium.objects.filter(account__user=request.user)

    # Pass the account statuses to the template
    return render(request, 'fb_insights/manage-google-account.html', {
        'form': form,
        'accounts': accounts,
        'total_google_accounts': total_google_accounts,
        'traffic_sources': traffic_sources,
    })


@csrf_exempt
def toggle_visibility(request):
    if request.method == 'POST':
        account_id = request.POST.get('account_id')
        is_visible = request.POST.get('is_visible') == 'true'
        try:
            account = GoogleAnalyticsAccount.objects.get(id=account_id)
            account.is_visible = is_visible
            account.save()
            return JsonResponse({'status': 'success'})
        except GoogleAnalyticsAccount.DoesNotExist:
            return JsonResponse({'status': 'error', 'message': 'Account not found'})

@csrf_exempt
def toggle_active(request):
    if request.method == 'POST':
        account_id = request.POST.get('account_id')
        is_active = request.POST.get('is_active') == 'true'
        try:
            account = GoogleAnalyticsAccount.objects.get(id=account_id)
            account.is_active = is_active
            account.save()
            return JsonResponse({'status': 'success'})
        except GoogleAnalyticsAccount.DoesNotExist:
            return JsonResponse({'status': 'error', 'message': 'Account not found'})




#================Analytics Viewssss==================


# from collections import defaultdict



# @login_required
# def analytics_view(request):    
#     ad_accounts = AdAccount.objects.filter(user=request.user)
#     ads = Ad.objects.none()

#     # Get parameters from the request
#     selected_ad_account_id = request.GET.get('ad_account', 'ALL')
#     selected_status = request.GET.get('status', 'ALL')
#     start_date = request.GET.get('start_date')
#     end_date = request.GET.get('end_date')

#     # Reset filters if requested
#     if request.GET.get('reset'):
#         request.session.pop('selected_ad_account_id', None)
#         request.session.pop('selected_status', None)
#         request.session.pop('start_date', None)
#         request.session.pop('end_date', None)

#     yesterday = (datetime.now() - timedelta(days=1)).date()
#     if not start_date:
#         start_date = yesterday.strftime('%Y-%m-%d')
#     if not end_date:
#         end_date = yesterday.strftime('%Y-%m-%d')

#     request.session['selected_ad_account_id'] = selected_ad_account_id
#     request.session['selected_status'] = selected_status
#     request.session['start_date'] = start_date
#     request.session['end_date'] = end_date

#     if selected_ad_account_id == 'ALL':
#         ads = Ad.objects.filter(adset__campaign__ad_account__user=request.user)
#     else:
#         ads = Ad.objects.filter(adset__campaign__ad_account__ad_account_id=selected_ad_account_id)

#     if selected_status != "ALL":
#         ads = ads.filter(ad_delivery=selected_status)

#     start_date_parsed = parse_date(start_date)
#     end_date_parsed = parse_date(end_date)

#     if start_date_parsed and end_date_parsed:
#         ads = ads.filter(start_date__gte=start_date_parsed, end_date__lte=end_date_parsed)

#     # Check if there are no ads within the filtered range
#     if not ads.exists():
#         context = {
#             'ad_accounts': ad_accounts,
#             'ad_delivery_statuses': ['ALL'] + list(Ad.objects.values_list('ad_delivery', flat=True).distinct()),
#             'ads': [],
#             'selected_ad_account_id': selected_ad_account_id,
#             'selected_status': selected_status,
#             'start_date': start_date,
#             'end_date': end_date,
#             'ads_found': False,
#             'no_data_message': 'No data available for the selected date range.',
#         }
#         return render(request, 'fb_insights/analytics.html', context)

#     # Subquery to get the last added budget based on the latest end_date
#     latest_delivery_status_subquery = Ad.objects.filter(
#         adset=OuterRef('adset')
#     ).order_by('-end_date')

#     # Logic for latest budget value (always fetch the last added budget globally)
#     latest_budget_value = Subquery(
#         Ad.objects.filter(
#             adset=OuterRef('adset')
#         ).order_by('-end_date').values('ad_set_budget')[:1]
#     )

#     ads = ads.annotate(
#         latest_delivery_status=Subquery(
#             latest_delivery_status_subquery.values('ad_delivery')[:1]
#         ),
#         latest_budget_value=latest_budget_value,

#         latest_cost_per_result=Subquery(
#             latest_delivery_status_subquery.values('cost_per_result')[:1]
#         )
#     )


#     # Aggregated ads with necessary fields and calculations
#     aggregated_ads = ads.select_related('adset', 'adset__campaign', 'adset__campaign__ad_account').values(
#         'adset__campaign__name',
#         'adset__name',
#         'name',
#         'latest_delivery_status',
#         'latest_budget_value',
#         'latest_cost_per_result',
#         'ad_id',
#         'adset__campaign__ad_account__account_name'
#     ).annotate(
#         total_spend=Sum('spend'),
#         total_results=Sum('results')
#     )

#     # Traffic sources query
#     traffic_sources = TrafficSourceMedium.objects.filter(
#         account__user=request.user
#     )

#     if start_date and end_date:
#         traffic_sources = traffic_sources.filter(
#             Q(start_date__gte=start_date_parsed) & Q(end_date__lte=end_date_parsed)
#         )

#     revenue_sources = traffic_sources.values(
#         'medium',
#     ).annotate(
#         total_revenue=Sum('total_revenue')
#     )

#     revenue_by_medium = {ts['medium'].lower(): ts['total_revenue'] for ts in revenue_sources}
#     print("=====",revenue_by_medium)
#     for ad in aggregated_ads:
#         total_spend = ad['total_spend']
#         total_results = ad['total_results']
#         ad['total_with_gst'] = total_spend * 1.18 if total_spend else 0
#         ad['cpc'] = total_spend / total_results if total_results > 0 else 0
#         ad_set_name = ad['adset__name'].lower()
#         ad['total_revenue'] = revenue_by_medium.get(ad_set_name, 0)
#         ad['roi'] = ad['total_revenue'] / ad['total_with_gst'] if ad['total_with_gst'] > 0 else 0
#         ad['profit_and_loss'] = ad['total_revenue'] - ad['total_with_gst']

#     sorted_aggregated_ads = sorted(aggregated_ads, key=lambda ad: ad.get('total_revenue', 0), reverse=True)

#     ad_delivery_statuses = ['ALL'] + list(Ad.objects.values_list('ad_delivery', flat=True).distinct())

#     yesterday = (datetime.now() - timedelta(days=1)).date()
    
#     # Default date range
#     if not start_date:
#         start_date = yesterday.strftime('%Y-%m-%d')
#     if not end_date:
#         end_date = yesterday.strftime('%Y-%m-%d')

#     #======= last_7_days data=========
    
    
#     # Get yesterday's date and the last 7 days
#     yesterday = datetime.today() - timedelta(days=1)
#     last_7_days = [(yesterday - timedelta(days=6-i)).strftime('%d-%m-%y') for i in range(7)]


#     # Data structure to hold ad-wise spend, CPC, revenue, ROI, profit & loss, and cost per result
#     ad_spend_data = defaultdict(lambda: {
#         'name': '',
#         'daily_spends': {day: 0 for day in last_7_days},
#         'total_spend': 0,
#         'daily_cpc': {day: 0 for day in last_7_days},
#         'total_cpc': 0,
#         'daily_revenue': {day: 0 for day in last_7_days},
#         'total_revenue': 0,
#         'daily_roi': {day: 0 for day in last_7_days},
#         'total_roi': 0,
#         'daily_profit_loss': {day: 0 for day in last_7_days},
#         'total_profit_loss': 0,
#         'daily_cost_per_result': {day: 0 for day in last_7_days},  # Track daily cost per result
#         'total_cost_per_result': 0,  # Track total cost per result
#         'avg_cost_per_result': 0,  # New field to store the average cost per result
#     })

#     # Debug: Print last_7_days to verify the date range
#     # print(f"Last 7 days: {last_7_days}")

#     # Process ads
#     for ad in ads:
#         ad_name = ad.name
#         ad_spend_data[ad.ad_id]['name'] = ad_name

#         total_cost_per_result_for_ad = 0  # Variable to accumulate total cost per result over the 7 days

#         # Debug: Print ad details
#         # print(f"Processing ad: {ad_name} (Ad ID: {ad.ad_id})")

#         for day in last_7_days:
#             day_date = datetime.strptime(day, '%d-%m-%y').date()

#             # Calculate daily spend
#             daily_spend = Ad.objects.filter(
#                 ad_id=ad.ad_id,
#                 start_date__lte=day_date,
#                 end_date__gte=day_date
#             ).aggregate(total_spent=Sum('spend'))['total_spent'] or 0

#             # Debug: Print daily spend for the current ad
#             # print(f"Day: {day}, Daily Spend: {daily_spend}")

#             # Calculate daily CPC
#             daily_cpc = Ad.objects.filter(
#                 ad_id=ad.ad_id,
#                 start_date__lte=day_date,
#                 end_date__gte=day_date
#             ).aggregate(total_cpc=Sum('cost_per_result'))['total_cpc'] or 0

#             # Debug: Print daily CPC for the current ad
#             # print(f"Day: {day}, Daily CPC: {daily_cpc}")

#             # Using the cost per result directly from the Ad model
#             daily_cost_per_result = ad.cost_per_result

#             # Debug: Print daily cost per result
#             # print(f"Day: {day}, Daily Cost per Result: {daily_cost_per_result}")

#             # Update daily spend, daily CPC, and daily cost per result
#             ad_spend_data[ad.ad_id]['daily_spends'][day] += daily_spend
#             ad_spend_data[ad.ad_id]['daily_cpc'][day] = daily_cpc
#             ad_spend_data[ad.ad_id]['daily_cost_per_result'][day] = daily_cost_per_result

#             # Accumulate cost per result for averaging
#             total_cost_per_result_for_ad += daily_cost_per_result

#             # Update total spend, total CPC, and total cost per result
#             ad_spend_data[ad.ad_id]['total_spend'] += daily_spend
#             ad_spend_data[ad.ad_id]['total_cpc'] += daily_cpc
#             ad_spend_data[ad.ad_id]['total_cost_per_result'] += daily_cost_per_result

#             # Calculate daily revenue (assume it's based on ad set name)
#             ad_set_name = ad.adset.name.lower()
#             daily_revenue = revenue_by_medium.get(ad_set_name, 0)
#             ad_spend_data[ad.ad_id]['daily_revenue'][day] = daily_revenue

#             # Debug: Print daily revenue
#             # print(f"Day: {day}, Daily Revenue: {daily_revenue}")

#             # Update total revenue
#             ad_spend_data[ad.ad_id]['total_revenue'] += daily_revenue

#             # Calculate daily ROI (Revenue / Spend_with_GST)
#             total_spend_with_gst = daily_spend * 1.18
#             daily_roi = daily_revenue / total_spend_with_gst if total_spend_with_gst > 0 else 0
#             ad_spend_data[ad.ad_id]['daily_roi'][day] = daily_roi

#             # Debug: Print daily ROI
#             # print(f"Day: {day}, Daily ROI: {daily_roi}")

#             # Update total ROI
#             total_spend_with_gst_total = ad_spend_data[ad.ad_id]['total_spend'] * 1.18
#             ad_spend_data[ad.ad_id]['total_roi'] = ad_spend_data[ad.ad_id]['total_revenue'] / total_spend_with_gst_total if total_spend_with_gst_total > 0 else 0

#             # Calculate daily profit and loss (Revenue - Spend_with_GST)
#             daily_profit_loss = daily_revenue - total_spend_with_gst
#             ad_spend_data[ad.ad_id]['daily_profit_loss'][day] = daily_profit_loss

#             # Debug: Print daily profit and loss
#             # print(f"Day: {day}, Daily Profit/Loss: {daily_profit_loss}")

#             # Update total profit and loss
#             ad_spend_data[ad.ad_id]['total_profit_loss'] = ad_spend_data[ad.ad_id]['total_revenue'] - total_spend_with_gst_total

#         # After processing all days, calculate the average cost per result for this ad
#         avg_cost_per_result = total_cost_per_result_for_ad / 7 if 7 > 0 else 0
#         ad_spend_data[ad.ad_id]['avg_cost_per_result'] = avg_cost_per_result

#         # Debug: Print average cost per result for the ad
#         # print(f"Ad ID: {ad.ad_id}, Average Cost per Result: {avg_cost_per_result}")

#     # Convert to list for easier processing in template
#     ad_spend_data_list = [
#         {   
#             'ad_id': ad_id,
#             'ad_name': data['name'],
#             'daily_spends': data['daily_spends'],
#             'total_spend': data['total_spend'],
#             'daily_cpc': data['daily_cpc'],
#             'total_cpc': data['total_cpc'],
#             'daily_revenue': data['daily_revenue'],
#             'total_revenue': data['total_revenue'],
#             'daily_roi': data['daily_roi'],
#             'total_roi': data['total_roi'],
#             'daily_profit_loss': data['daily_profit_loss'],
#             'total_profit_loss': data['total_profit_loss'],
#             'daily_cost_per_result': data['daily_cost_per_result'],  # Include daily cost per result
#             'total_cost_per_result': data['total_cost_per_result'],  # Include total cost per result
#             'avg_cost_per_result': data['avg_cost_per_result'],  # Include average cost per result
#         }
#         for ad_id, data in ad_spend_data.items()
#     ]


#     context = {
#         'ad_accounts': ad_accounts,
#         'ad_delivery_statuses': ad_delivery_statuses,
#         'ads': sorted_aggregated_ads,
#         'selected_ad_account_id': selected_ad_account_id,
#         'selected_status': selected_status,
#         'start_date': start_date,
#         'end_date': end_date,
#         'ads_found': bool(sorted_aggregated_ads),
#         'ad_spend_data': ad_spend_data_list,
#         'last_7_days': last_7_days,
#     }

#     return render(request, 'fb_insights/analytics.html', context)




from collections import defaultdict



@login_required
def analytics_view(request):    
    ad_accounts = AdAccount.objects.filter(user=request.user)
    ads = Ad.objects.none()

    # Get parameters from the request
    selected_ad_account_id = request.GET.get('ad_account', 'ALL')
    selected_status = request.GET.get('status', 'ALL')
    start_date = request.GET.get('start_date')
    end_date = request.GET.get('end_date')

    # Reset filters if requested
    if request.GET.get('reset'):
        request.session.pop('selected_ad_account_id', None)
        request.session.pop('selected_status', None)
        request.session.pop('start_date', None)
        request.session.pop('end_date', None)

    yesterday = (datetime.now() - timedelta(days=1)).date()
    if not start_date:
        start_date = yesterday.strftime('%Y-%m-%d')
    if not end_date:
        end_date = yesterday.strftime('%Y-%m-%d')

    request.session['selected_ad_account_id'] = selected_ad_account_id
    request.session['selected_status'] = selected_status
    request.session['start_date'] = start_date
    request.session['end_date'] = end_date

    if selected_ad_account_id == 'ALL':
        ads = Ad.objects.filter(adset__campaign__ad_account__user=request.user)
    else:
        ads = Ad.objects.filter(adset__campaign__ad_account__ad_account_id=selected_ad_account_id)

    if selected_status != "ALL":
        ads = ads.filter(ad_delivery=selected_status)

    start_date_parsed = parse_date(start_date)
    end_date_parsed = parse_date(end_date)

    if start_date_parsed and end_date_parsed:
        ads = ads.filter(start_date__gte=start_date_parsed, end_date__lte=end_date_parsed)

    # Check if there are no ads within the filtered range
    if not ads.exists():
        context = {
            'ad_accounts': ad_accounts,
            'ad_delivery_statuses': ['ALL'] + list(Ad.objects.values_list('ad_delivery', flat=True).distinct()),
            'ads': [],
            'selected_ad_account_id': selected_ad_account_id,
            'selected_status': selected_status,
            'start_date': start_date,
            'end_date': end_date,
            'ads_found': False,
            'no_data_message': 'No data available for the selected date range.',
        }
        return render(request, 'fb_insights/analytics.html', context)

    # Subquery to get the last added budget based on the latest end_date
    latest_delivery_status_subquery = Ad.objects.filter(
        adset=OuterRef('adset')
    ).order_by('-end_date')

    # Logic for latest budget value (always fetch the last added budget globally)
    latest_budget_value = Subquery(
        Ad.objects.filter(
            adset=OuterRef('adset')
        ).order_by('-end_date').values('ad_set_budget')[:1]
    )

    ads = ads.annotate(
        latest_delivery_status=Subquery(
            latest_delivery_status_subquery.values('ad_delivery')[:1]
        ),
        latest_budget_value=latest_budget_value,

        latest_cost_per_result=Subquery(
            latest_delivery_status_subquery.values('cost_per_result')[:1]
        )
    )


    # Aggregated ads with necessary fields and calculations
    aggregated_ads = ads.select_related('adset', 'adset__campaign', 'adset__campaign__ad_account').values(
        'adset__campaign__name',
        'adset__name',
        'name',
        'latest_delivery_status',
        'latest_budget_value',
        'latest_cost_per_result',
        'ad_id',
        'adset__campaign__ad_account__account_name'
    ).annotate(
        total_spend=Sum('spend'),
        total_results=Sum('results')
    )

    # Traffic sources query
    traffic_sources = TrafficSourceMedium.objects.filter(
        account__user=request.user
    )

    if start_date and end_date:
        traffic_sources = traffic_sources.filter(
            Q(start_date__gte=start_date_parsed) & Q(end_date__lte=end_date_parsed)
        )

    revenue_sources = traffic_sources.values(
        'medium',
    ).annotate(
        total_revenue=Sum('total_revenue')
    )

    revenue_by_medium = {ts['medium'].lower(): ts['total_revenue'] for ts in revenue_sources}
    # print("=====",revenue_by_medium)
    for ad in aggregated_ads:
        total_spend = ad['total_spend']
        total_results = ad['total_results']
        ad['total_with_gst'] = total_spend * 1.18 if total_spend else 0
        ad['cpc'] = total_spend / total_results if total_results > 0 else 0
        ad_set_name = ad['adset__name'].lower()
        ad['total_revenue'] = revenue_by_medium.get(ad_set_name, 0)
        ad['roi'] = ad['total_revenue'] / ad['total_with_gst'] if ad['total_with_gst'] > 0 else 0
        ad['profit_and_loss'] = ad['total_revenue'] - ad['total_with_gst']

    sorted_aggregated_ads = sorted(aggregated_ads, key=lambda ad: ad.get('total_revenue', 0), reverse=True)

    ad_delivery_statuses = ['ALL'] + list(Ad.objects.values_list('ad_delivery', flat=True).distinct())

    yesterday = (datetime.now() - timedelta(days=1)).date()
    
    # Default date range
    if not start_date:
        start_date = yesterday.strftime('%Y-%m-%d')
    if not end_date:
        end_date = yesterday.strftime('%Y-%m-%d')

    #======= last_7_days data=========
    
    
    

    context = {
        'ad_accounts': ad_accounts,
        'ad_delivery_statuses': ad_delivery_statuses,
        'ads': sorted_aggregated_ads,
        'selected_ad_account_id': selected_ad_account_id,
        'selected_status': selected_status,
        'start_date': start_date,
        'end_date': end_date,
        'ads_found': bool(sorted_aggregated_ads),
        
    }

    return render(request, 'fb_insights/analytics.html', context)





def update_facebook_ad(ad):
    # Retrieve the AdAccount associated with this ad
    try:
        ad_account = ad.ad_account  # Accessing the AdAccount through the ForeignKey
    except AdAccount.DoesNotExist:
        logger.error(f"AdAccount does not exist for ad ID {ad.ad_id}.")
        return {'success': False, 'error': 'AdAccount not found.'}

    url = f"https://graph.facebook.com/v12.0/{ad.ad_id}"
    access_token = ad_account.access_token  # Get the access token from AdAccount
    payload = {
        'status': ad.ad_delivery,
        'access_token': access_token,
    }
    
    response = requests.post(url, data=payload)
    
    if response.status_code == 200:
        return {'success': True, 'data': response.json()}
    else:
        logger.error(f"Failed to update Facebook Ad: {response.json()}")
        return {'success': False, 'error': response.json()}

@require_POST
def update_ad_status(request, ad_id):
    try:
        data = json.loads(request.body)
        new_status = data.get('status')
        
        ads = Ad.objects.filter(ad_id=ad_id).order_by('-created_at')

        if ads.exists():
            last_ad = ads.first()
            last_ad.ad_delivery = new_status
            last_ad.save()

            # Update Facebook ad status
            fb_response = update_facebook_ad(last_ad)

            if fb_response.get('success'):
                return JsonResponse({'success': True, 'status': last_ad.ad_delivery})
            else:
                logger.error(f"Failed to update Facebook Ad: {fb_response.get('error')}")
                return JsonResponse({'success': False, 'error': 'Failed to update Facebook Ad.'}, status=500)

        return JsonResponse({'success': False, 'error': 'Ad not found.'}, status=404)

    except Exception as e:
        logger.exception("Error updating ad status")
        return JsonResponse({'success': False, 'error': str(e)}, status=400)





#=====  try new both our db and fb db ===



# Define logger
logger = logging.getLogger(__name__)

def update_facebook_ad_budget(ad, new_budget):
    # Retrieve the AdAccount associated with this ad
    try:
        ad_account = ad.ad_account  # Accessing the AdAccount through the ForeignKey
        print(f"AdAccount found: {ad_account}")  # Print AdAccount details
    except AdAccount.DoesNotExist:
        logger.error(f"AdAccount does not exist for ad ID {ad.ad_id}.")
        return {'success': False, 'error': 'AdAccount not found.'}

    url = f"https://graph.facebook.com/v12.0/{ad.adset.adset_id}"  # Use AdSet ID to update budget
    access_token = ad_account.access_token  # Get the access token from AdAccount
    print(f"Facebook API URL: {url}")  # Print the Facebook API URL
    print(f"Access Token: {access_token}")  # Print the access token

    payload = {
        'daily_budget': int(float(new_budget) * 100),  # Budget is in cents
        'access_token': access_token,
    }

    response = requests.post(url, data=payload)
    print(f"Facebook API Response: {response.status_code}")  # Print response status

    if response.status_code == 200:
        print(f"Response JSON: {response.json()}")  # Print the response content
        return {'success': True, 'data': response.json()}
    else:
        logger.error(f"Failed to update Facebook AdSet budget: {response.json()}")
        return {'success': False, 'error': response.json()}




def update_ad_budget(request, ad_id):
    if request.method == 'POST':
        current_date = timezone.now().date()  # Get today's date without time
        print(f"Current date: {current_date}")  # Print current date for debugging

        try:
            # Filter for ads with the given ad_id and today's date
            ads = Ad.objects.filter(ad_id=ad_id, start_date=current_date, end_date=current_date)
            print(f"Found ads: {ads}")  # Print ads retrieved from the database

            if ads.exists():
                # Get the most recent ad (the latest one added today)
                ad = ads.order_by('-created_at').first()  # Assuming `created_at` is a timestamp of when the ad was created
                print(f"Selected ad: {ad}")  # Print the selected ad details

                # Get the new budget from the form data
                new_budget = request.POST.get('ad_set_budget')
                print(f"New budget received: {new_budget}")  # Print the new budget

                if not new_budget:
                    messages.error(request, 'Please enter a valid budget.')
                    return redirect(request.META.get('HTTP_REFERER', 'analytics'))

                # Update the ad's budget locally in the database
                ad.ad_set_budget = new_budget  # Assuming you store the latest budget in the field `ad_set_budget`
                ad.save()
                print(f"Updated ad budget: {ad.ad_set_budget}")  # Print the updated ad's budget

                # Call the function to update the budget in Facebook Ad Manager
                fb_response = update_facebook_ad_budget(ad, new_budget)
                print(f"Facebook response: {fb_response}")  # Print Facebook API response

                if fb_response.get('success'):
                    messages.success(request, 'Budget updated successfully for Facebook Ad.')
                    return redirect(request.META.get('HTTP_REFERER', 'analytics'))
                else:
                    messages.error(request, f"Failed to update Facebook Ad budget: {fb_response.get('error')}")
                    return redirect(request.META.get('HTTP_REFERER', 'analytics'))
            else:
                messages.error(request, 'No Ad found with the given dates and ID.')
                return redirect(request.META.get('HTTP_REFERER', 'analytics'))

        except Ad.DoesNotExist:
            messages.error(request, 'Ad not found.')
            return redirect(request.META.get('HTTP_REFERER', 'analytics'))

    # Handle GET request (optional)
    return redirect('analytics')



#============ Trends view ====================
from django.shortcuts import render
from django.utils import timezone
from datetime import timedelta
from .models import Ad, TrafficSourceMedium

def trends_view(request):
   # Fetch the selected filter values from the request
    selected_ad_account = request.GET.get('ad_account', 'all')
    selected_ad_status = request.GET.get('ad_status', 'all')

    # Fetch dynamic Ad Accounts based on the authenticated user
    active_ad_accounts = Ad.objects.filter(ad_account__user=request.user).values('ad_account__account_name', 'ad_account__ad_account_id').distinct()
    ad_statuses = Ad.objects.values_list('ad_delivery', flat=True).distinct()
    # Print to check the active ad accounts
    # print(active_ad_accounts)

    # Get today's date and calculate the date range for the last 7 days
    today = timezone.now().date()
    start_date = today - timedelta(days=7)
    dates = [(start_date + timedelta(days=i)).strftime('%d %b') for i in range(7)]
    
    # Convert dates to actual date objects for easier comparison later
    date_objects = [start_date + timedelta(days=i) for i in range(7)]
    
    # Table 1: Amount Spent Data
    ads_spend_data = {}
    
    # Fetch only ads associated with the authenticated user's accounts
    ads_data_for_spend = Ad.objects.filter(
        start_date__lte=today, 
        end_date__gte=start_date,
        ad_account__user=request.user  # Filter by the authenticated user's ad accounts
    ).order_by('-created_at')

    for ad in ads_data_for_spend:
        ad_account = ad.ad_account.account_name
        ad_id = ad.ad_id
        ad_name = ad.name
        ad_spend = ad.spend
        ad_set_budget = ad.ad_set_budget
        ad_delivery_status = ad.ad_delivery

        if ad_name not in ads_spend_data:
            ads_spend_data[ad_name] = {
                'ad_id': ad_id,
                'ad_account': ad_account,
                'ad_name': ad_name,
                'spend_data': {date: 0 for date in dates},
                'spend_with_gst': {date: 0 for date in dates},  # Initialize GST data for each date
                'total_spend': 0,
                'budget': ad_set_budget,
                'status': ad_delivery_status,
            }

        for i, date in enumerate(date_objects):
            if ad.start_date <= date <= ad.end_date:
                ads_spend_data[ad_name]['spend_data'][dates[i]] += ad_spend
                ads_spend_data[ad_name]['total_spend'] += ad_spend

                # Calculate GST-inclusive amount for the current date
                ads_spend_data[ad_name]['spend_with_gst'][dates[i]] = round(
                    ads_spend_data[ad_name]['spend_data'][dates[i]] * 1.18, 2
                )

    # Table 2: Revenue Data
    revenue_data = {}
    traffic_data = TrafficSourceMedium.objects.filter(start_date__gte=start_date, end_date__lte=today)

    for traffic in traffic_data:
        # Match TrafficSourceMedium.medium with Ad.name
        matching_ad = ads_data_for_spend.filter(name=traffic.medium).first()

        if matching_ad:
            ad_account = matching_ad.ad_account.account_name
            ad_name = matching_ad.name
            total_revenue = traffic.total_revenue

            if ad_name not in revenue_data:
                revenue_data[ad_name] = {
                    'ad_id': ad_id,
                    'ad_account': ad_account,
                    'ad_name': ad_name,
                    'revenue_data': {date: 0 for date in dates},
                    'total_revenue': 0,
                    'budget': matching_ad.ad_set_budget,
                    'status': matching_ad.ad_delivery,
                }

            for i, date in enumerate(date_objects):
                if traffic.start_date <= date <= traffic.end_date:
                    revenue_data[ad_name]['revenue_data'][dates[i]] += total_revenue
                    revenue_data[ad_name]['total_revenue'] += total_revenue
            
            sorted_revenue_data = sorted(revenue_data.items(), key=lambda x: x[1]['total_revenue'], reverse=True)

    # Table 3: Cost per Result Data
    cost_per_result_data = {}
    for ad in ads_data_for_spend:
        ad_account = ad.ad_account.account_name
        ad_name = ad.name
        cost_per_result = ad.cost_per_result
        ad_delivery_status = ad.ad_delivery
        ad_set_budget = ad.ad_set_budget

        if ad_name not in cost_per_result_data:
            cost_per_result_data[ad_name] = {
                'ad_id': ad_id,
                'ad_account': ad_account,
                'ad_name': ad_name,
                'status': ad_delivery_status,
                'budget': ad_set_budget,
                'cost_per_result_data': {date: 0 for date in dates},
            }

        for i, date in enumerate(date_objects):
            if ad.start_date <= date <= ad.end_date:
                cost_per_result_data[ad_name]['cost_per_result_data'][dates[i]] = cost_per_result

    # Table 4: ROI Data
    roi_data = {}

    for ad_name, ad_spend in ads_spend_data.items():
        if ad_name not in roi_data:
            roi_data[ad_name] = {
                'ad_id': ad_id,
                'ad_account': ad_spend['ad_account'],
                'ad_name': ad_spend['ad_name'],
                'roi_data': {date: 0 for date in dates},
                'total_roi': 0,
                'budget': ad_spend['budget'],
                'status': ad_spend['status'],
            }

        for i, date in enumerate(date_objects):
            revenue = revenue_data.get(ad_name, {}).get('revenue_data', {}).get(dates[i], 0)
            spend_with_gst = ad_spend['spend_with_gst'].get(dates[i], 0)

            if spend_with_gst > 0:
                roi = revenue / spend_with_gst
            else:
                roi = 0

            roi_data[ad_name]['roi_data'][dates[i]] = roi
            roi_data[ad_name]['total_roi'] += roi

    # Table 5: Profit and Loss (P&L) Data
    profit_loss_data = {}

    for ad_name, ad_spend in ads_spend_data.items():
        if ad_name not in profit_loss_data:
            profit_loss_data[ad_name] = {
                'ad_id': ad_id,
                'ad_account': ad_spend['ad_account'],
                'ad_name': ad_spend['ad_name'],
                'profit_loss_data': {date: 0 for date in dates},
                'total_profit_loss': 0,
                'budget': ad_spend['budget'],
                'status': ad_spend['status'],
            }

        for i, date in enumerate(date_objects):
            revenue = revenue_data.get(ad_name, {}).get('revenue_data', {}).get(dates[i], 0)
            spend_with_gst = ad_spend['spend_with_gst'].get(dates[i], 0)

            profit_loss = revenue - spend_with_gst
            profit_loss_data[ad_name]['profit_loss_data'][dates[i]] = profit_loss
            profit_loss_data[ad_name]['total_profit_loss'] += profit_loss

    # Prepare context for rendering
    context = {
        'dates': dates,
        'ads_spend_data': list(ads_spend_data.values()),  # Convert dict to list
        'revenue_data': [value for key, value in sorted_revenue_data], 
        'cost_per_result_data': list(cost_per_result_data.values()),
        'roi_data': list(roi_data.values()),
        'profit_loss_data': list(profit_loss_data.values()),
        'start_date': start_date,
        'end_date': today - timedelta(days=1),
        'active_ad_accounts': active_ad_accounts,
        'ad_statuses': ad_statuses,
        'selected_ad_account': selected_ad_account,
        'selected_ad_status': selected_ad_status,
    }

    return render(request, 'fb_insights/trends.html', context)

import logging
import json
from django.http import JsonResponse
from .models import Ad

# Set up logging
logger = logging.getLogger(__name__)

import json
import logging
import requests
from django.http import JsonResponse
from .models import Ad
from .models import AdAccount  # Ensure AdAccount is imported for FB integration

# Initialize logger
logger = logging.getLogger(__name__)

def update_trends_ad_status(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)  # Parse the incoming JSON data
            ad_id = data.get('ad_id')  # Get the ad ID from the request
            new_status = data.get('status')  # Get the new status

            logger.debug(f"Received request to update ad with ID: {ad_id} and status: {new_status}")  # Log received data

            # Filter ads by ad_id and get the latest one based on created_at or updated_at
            ads = Ad.objects.filter(ad_id=ad_id).order_by('-updated_at')  # Use '-created_at' if you prefer

            if ads.exists():
                ad = ads.first()  # Get the latest ad (most recent)
                ad.ad_delivery = new_status  # Update the status
                ad.save()  # Save the changes

                # Now update the status on Facebook Ad Manager
                fb_update_response = update_facebook_ad(ad)

                if fb_update_response['success']:
                    return JsonResponse({'success': True})  # Return success response
                else:
                    logger.error(f"Failed to update Facebook Ad: {fb_update_response['error']}")
                    return JsonResponse({'success': False, 'error': fb_update_response['error']})

            else:
                logger.error(f"Ad with ID {ad_id} not found.")  # Log error to terminal
                return JsonResponse({'success': False, 'error': 'Ad not found'})

        except Exception as e:
            logger.error(f"Error occurred while updating ad status: {str(e)}")  # Log error to terminal
            return JsonResponse({'success': False, 'error': str(e)})
    else:
        logger.error("Invalid request method received.")  # Log error to terminal
        return JsonResponse({'success': False, 'error': 'Invalid request method'})



import json
import logging
import requests
from django.http import JsonResponse
from .models import Ad, AdAccount  # Ensure you have Ad and AdAccount models imported

# Initialize logger
logger = logging.getLogger(__name__)

@csrf_exempt
def update_trends_budget(request):
    if request.method == "POST":
        try:
            # Parse the JSON data from the request body
            data = json.loads(request.body)
            ad_id = data.get("ad_id")
            new_budget = data.get("new_budget")

            # Log incoming data for debugging
            logger.debug(f"Received ad_id: {ad_id}, new_budget: {new_budget}")

            if not ad_id or not new_budget:
                return JsonResponse({"success": False, "message": "ad_id and new_budget are required."})

            # Find the latest Ad with the given ad_id
            ad = Ad.objects.filter(ad_id=ad_id).order_by('-created_at').first()

            if not ad:
                return JsonResponse({"success": False, "message": f"Ad with id {ad_id} not found."})

            # Update the ad's budget in the database
            ad.ad_set_budget = new_budget
            ad.save()

            # Now update the budget on Facebook Ad Manager
            fb_update_response = update_facebook_ad_budget(ad, new_budget)

            if fb_update_response['success']:
                return JsonResponse({"success": True, "message": "Budget updated successfully."})
            else:
                logger.error(f"Failed to update Facebook AdSet budget: {fb_update_response['error']}")
                return JsonResponse({"success": False, "message": fb_update_response['error']})

        except json.JSONDecodeError as e:
            logger.error(f"JSONDecodeError: {str(e)}")
            return JsonResponse({"success": False, "message": "Invalid JSON format."})

        except Exception as e:
            logger.error(f"Error: {str(e)}")
            return JsonResponse({"success": False, "message": str(e)})

    return JsonResponse({"success": False, "message": "Invalid request method."})



# from django.http import HttpResponse
# from django.utils import timezone
# from datetime import timedelta
# from .models import Ad, TrafficSourceMedium
# from django.shortcuts import render

# def ad_report_last_7_days(request):
#     # Set today's date (29th Nov 2024)
#     today = timezone.now().date()

#     # Get the previous month's last day (29th Nov 2024 -> 28th Nov 2024)
#     end_date = today - timedelta(days=1)
#     start_date = end_date - timedelta(days=6)  # 7 days range (28th Nov 2024 to 22nd Nov 2024)

#     # Generate the list of dates for the last 7 days (28th Nov to 22nd Nov)
#     dates = [(end_date - timedelta(days=i)).strftime('%Y-%m-%d') for i in range(7)]

#     # Fetch Ad data for the last 7 days
#     ads_data = Ad.objects.filter(start_date__gte=start_date, end_date__lte=end_date)

#     # Initialize a dictionary to store spend, cost_per_result, and revenue data for each ad and date
#     ad_spend_data = {ad.name: {date: {'spend': 0, 'cost_per_result': 0, 'revenue': 0} for date in dates} for ad in ads_data}

#     # Populate ad_spend_data with the spend, cost_per_result, and revenue for each ad and date
#     for ad in ads_data:
#         for i, date in enumerate(dates):
#             if ad.start_date.strftime('%Y-%m-%d') == date:
#                 ad_spend_data[ad.name][date]['spend'] += ad.spend
#                 ad_spend_data[ad.name][date]['cost_per_result'] += ad.cost_per_result

#     # Fetch TrafficSourceMedium data for the last 7 days and match medium with ad_name
#     traffic_data = TrafficSourceMedium.objects.filter(start_date__gte=start_date, end_date__lte=end_date)

#     # Populate ad_spend_data with revenue data by matching medium (lowercased) with ad_name (lowercased)
#     for traffic in traffic_data:
#         for ad_name, spend_data in ad_spend_data.items():
#             if traffic.medium.lower() == ad_name.lower():  # Convert both to lowercase before comparison
#                 for date in dates:
#                     if traffic.start_date.strftime('%Y-%m-%d') == date:
#                         ad_spend_data[ad_name][date]['revenue'] += traffic.total_revenue

#     # Create the HTML table to display the report
#     table_html = """
#     <html>
#         <head>
#             <style>
#                 table {
#                     width: 100%;
#                     border-collapse: collapse;
#                 }
#                 table, th, td {
#                     border: 1px solid black;
#                 }
#                 th, td {
#                     padding: 8px;
#                     text-align: left;
#                 }
#                 th {
#                     background-color: #f2f2f2;
#                 }
#             </style>
#         </head>
#         <body>
#             <h2>Ad Spend, Cost Per Result, and Revenue Report for Last 7 Days</h2>
#             <table>
#                 <tr>
#                     <th>Ad Name</th>
#                     <th>Total Spend</th>
#                     <th>Total Cost Per Result</th>
#                     <th>Total Revenue</th>
#                     """ + "".join([f"<th>{date}</th>" for date in dates]) + """
#                 </tr>
#     """

#     # Populate the table rows with the spend, cost_per_result, and revenue data for each ad
#     for ad_name, spend_data in ad_spend_data.items():
#         total_spend = sum([data['spend'] for data in spend_data.values()])
#         total_cost_per_result = sum([data['cost_per_result'] for data in spend_data.values()])
#         total_revenue = sum([data['revenue'] for data in spend_data.values()])
#         table_html += f"""
#         <tr>
#             <td>{ad_name}</td>
#             <td>{total_spend}</td>
#             <td>{total_cost_per_result}</td>
#             <td>{total_revenue}</td>
#         """
#         # Add daily spend, cost_per_result, and revenue for each date
#         for date in dates:
#             table_html += f"<td>Spend: {spend_data[date]['spend']}<br>Cost per Result: {spend_data[date]['cost_per_result']}<br>Revenue: {spend_data[date]['revenue']}</td>"
#         table_html += "</tr>"

#     # Close the table and HTML tags
#     table_html += """
#             </table>
#         </body>
#     </html>
#     """

#     # Return the generated HTML as an HttpResponse
#     return HttpResponse(table_html)



# from django.http import JsonResponse
# from django.utils import timezone
# from datetime import timedelta
# from .models import Ad, TrafficSourceMedium
# from django.shortcuts import render

# def ad_report_last_7_days(request):
#     # Set today's date (29th Nov 2024)
#     today = timezone.now().date()

#     # Get the previous month's last day (29th Nov 2024 -> 28th Nov 2024)
#     end_date = today - timedelta(days=1)
#     start_date = end_date - timedelta(days=6)  # 7 days range (28th Nov 2024 to 22nd Nov 2024)

#     # Generate the list of dates for the last 7 days (28th Nov to 22nd Nov)
#     dates = [(end_date - timedelta(days=i)).strftime('%Y-%m-%d') for i in range(7)]

#     # Fetch Ad data for the last 7 days
#     ads_data = Ad.objects.filter(start_date__gte=start_date, end_date__lte=end_date)

#     # Initialize a dictionary to store spend, cost_per_result, and revenue data for each ad and date
#     ad_spend_data = {ad.name: {date: {'spend': 0, 'cost_per_result': 0, 'revenue': 0} for date in dates} for ad in ads_data}

#     # Populate ad_spend_data with the spend, cost_per_result, and revenue for each ad and date
#     for ad in ads_data:
#         for i, date in enumerate(dates):
#             if ad.start_date.strftime('%Y-%m-%d') == date:
#                 ad_spend_data[ad.name][date]['spend'] += ad.spend
#                 ad_spend_data[ad.name][date]['cost_per_result'] += ad.cost_per_result

#     # Fetch TrafficSourceMedium data for the last 7 days and match medium with ad_name
#     traffic_data = TrafficSourceMedium.objects.filter(start_date__gte=start_date, end_date__lte=end_date)

#     # Populate ad_spend_data with revenue data by matching medium (lowercased) with ad_name (lowercased)
#     for traffic in traffic_data:
#         for ad_name, spend_data in ad_spend_data.items():
#             if traffic.medium.lower() == ad_name.lower():  # Convert both to lowercase before comparison
#                 for date in dates:
#                     if traffic.start_date.strftime('%Y-%m-%d') == date:
#                         ad_spend_data[ad_name][date]['revenue'] += traffic.total_revenue

#     # Prepare the JSON response data
#     ad_spend_json = {}

#     for ad_name, spend_data in ad_spend_data.items():
#         total_spend = sum([data['spend'] for data in spend_data.values()])
#         total_cost_per_result = sum([data['cost_per_result'] for data in spend_data.values()])
#         total_revenue = sum([data['revenue'] for data in spend_data.values()])

#         daily_data = {date: {
#             'spend': spend_data[date]['spend'],
#             'cost_per_result': spend_data[date]['cost_per_result'],
#             'revenue': spend_data[date]['revenue'],
#         } for date in dates}

#         ad_spend_json[ad_name] = {
#             'total_spend': total_spend,
#             'total_cost_per_result': total_cost_per_result,
#             'total_revenue': total_revenue,
#             'daily_data': daily_data
#         }

#     # Print the JSON data to the terminal
#     # print(ad_spend_json)

#     # Return the JSON data as an HttpResponse (optional, can remove if only printing is needed)
#     return JsonResponse(ad_spend_json)


# def ad_report_last_7_days(request):
#     ad_id = request.GET.get('ad_id')
#     if not ad_id:
#         return JsonResponse({'error': 'ad_id is required'}, status=400)

#     today = timezone.now().date()
#     end_date = today - timedelta(days=1)
#     start_date = end_date - timedelta(days=6)

#     dates = [(end_date - timedelta(days=i)).strftime('%Y-%m-%d') for i in range(7)]
#     ad_data = Ad.objects.filter(id=ad_id, start_date__gte=start_date, end_date__lte=end_date).first()

#     if not ad_data:
#         return JsonResponse({'error': 'Ad not found'}, status=404)

#     spend_data = {
#         date: {
#             'spend': ad_data.spend if ad_data.start_date.strftime('%Y-%m-%d') == date else 0.0,
#             'cpc': ad_data.cost_per_result if ad_data.start_date.strftime('%Y-%m-%d') == date else 0.0,
#             'revenue': 0.0  # You can include revenue data here if needed
#         } for date in dates
#     }

#     # Populate the revenue data by checking the traffic sources for each date
#     traffic_data = TrafficSourceMedium.objects.filter(start_date__gte=start_date, end_date__lte=end_date)
#     for traffic in traffic_data:
#         for date in dates:
#             if traffic.start_date.strftime('%Y-%m-%d') == date:
#                 spend_data[date]['revenue'] += traffic.total_revenue

#     ad_report = {
#         'ad_id': ad_data.id,
#         'ad_name': ad_data.name,
#         'data': spend_data
#     }

#     return JsonResponse(ad_report)


# from django.http import JsonResponse
# from django.utils import timezone
# from datetime import timedelta
# from .models import Ad, TrafficSourceMedium

# def ad_report_last_7_days(request):
#     # Get the 'ad_id' parameter from the GET request
#     ad_id = request.GET.get('ad_id')
    
#     # If 'ad_id' is not provided, return an error response
#     if not ad_id:
#         return JsonResponse({'error': 'ad_id is required'}, status=400)
    
#     # Get today's date
#     today = timezone.now().date()
    
#     # Calculate the start and end date for the last 7 days
#     end_date = today - timedelta(days=1)
#     start_date = end_date - timedelta(days=6)

#     # Debugging: Print out the Ad ID, Start Date, and End Date
#     print(f"Ad ID: {ad_id}, Start Date: {start_date}, End Date: {end_date}")

#     # Generate a list of the last 7 dates
#     dates = [(end_date - timedelta(days=i)).strftime('%Y-%m-%d') for i in range(7)]
#     print(f"Dates: {dates}")  # Debug print

#     # Query the Ad model for the specified ad_id within the date range
#     ad_data = Ad.objects.filter(id=ad_id, start_date__gte=start_date, end_date__lte=end_date).first()

#     # If the ad is not found, return an error
#     if not ad_data:
#         print("Ad not found")  # Debug print
#         return JsonResponse({'error': 'Ad not found'}, status=404)

#     # Debugging: Print out the Ad data retrieved
#     print(f"Ad Data: {ad_data}")

#     # Initialize the spend_data dictionary with default values
#     spend_data = {
#         date: {
#             'spend': ad_data.spend if ad_data.start_date.strftime('%Y-%m-%d') == date else 0.0,
#             'cpc': ad_data.cost_per_result if ad_data.start_date.strftime('%Y-%m-%d') == date else 0.0,
#             'revenue': 0.0
#         } for date in dates
#     }
#     print(f"Spend Data: {spend_data}")  # Debug print

#     # Query the TrafficSourceMedium model for traffic data in the date range
#     traffic_data = TrafficSourceMedium.objects.filter(start_date__gte=start_date, end_date__lte=end_date)

#     # Populate the revenue data for each date
#     for traffic in traffic_data:
#         for date in dates:
#             if traffic.start_date.strftime('%Y-%m-%d') == date:
#                 spend_data[date]['revenue'] += traffic.total_revenue

#     # Get the ad account name (if available) and print it for debugging
#     ad_account_name = ad_data.ad_account.account_name if ad_data.ad_account else 'N/A'
#     print(f"Ad Account Name: {ad_account_name}")

#     # Prepare the ad report to return as JSON
#     ad_report = {
#         'ad_account_name': ad_account_name,
#         'ad_name': ad_data.name,
#         'data': spend_data
#     }

#     # Print out the final ad report for debugging
#     print(f"Ad Report: {ad_report}")

#     # Return the ad report as a JSON response
#     return JsonResponse(ad_report)
    


def ad_report_last_7_days(request, ad_id=None):  
    # Set today's date (29th Nov 2024)
    today = timezone.now().date()

    # Get the previous month's last day (29th Nov 2024 -> 28th Nov 2024)
    end_date = today - timedelta(days=1)
    start_date = end_date - timedelta(days=6)  # 7 days range (28th Nov 2024 to 22nd Nov 2024)

    # Generate the list of dates for the last 7 days (28th Nov to 22nd Nov)
    dates = [(end_date - timedelta(days=i)).strftime('%Y-%m-%d') for i in range(7)]

    # Fetch Ad data for the last 7 days
    if ad_id:  # If ad_id is provided, filter by it
        ads_data = Ad.objects.filter(ad_id=ad_id, start_date__gte=start_date, end_date__lte=end_date)
    else:
        ads_data = Ad.objects.filter(start_date__gte=start_date, end_date__lte=end_date)

    # Initialize a dictionary to store spend, cost_per_result, and revenue data for each ad and date
    ad_spend_data = {ad.name: {date: {'spend': 0, 'cost_per_result': 0, 'revenue': 0} for date in dates} for ad in ads_data}

    # Populate ad_spend_data with the spend, cost_per_result, and revenue for each ad and date
    for ad in ads_data:
        for i, date in enumerate(dates):
            if ad.start_date.strftime('%Y-%m-%d') == date:
                ad_spend_data[ad.name][date]['spend'] += ad.spend
                ad_spend_data[ad.name][date]['cost_per_result'] += ad.cost_per_result

    # Fetch TrafficSourceMedium data for the last 7 days and match medium with ad_name
    traffic_data = TrafficSourceMedium.objects.filter(start_date__gte=start_date, end_date__lte=end_date)

    # Populate ad_spend_data with revenue data by matching medium (lowercased) with ad_name (lowercased)
    for traffic in traffic_data:
        for ad_name, spend_data in ad_spend_data.items():
            if traffic.medium.lower() == ad_name.lower():  # Convert both to lowercase before comparison
                for date in dates:
                    if traffic.start_date.strftime('%Y-%m-%d') == date:
                        ad_spend_data[ad_name][date]['revenue'] += traffic.total_revenue

    # Prepare the JSON response data for the specific ad_id
    ads = {}

    for ad in ads_data:
        ad_name = ad.name
        ad_id = ad.ad_id  # Get the ad_id
        spend_data = ad_spend_data.get(ad_name, {})

        total_spend = sum([data['spend'] for data in spend_data.values()])
        total_cost_per_result = sum([data['cost_per_result'] for data in spend_data.values()])
        total_revenue = sum([data['revenue'] for data in spend_data.values()])

        daily_data = {date: {
            'spend': spend_data[date]['spend'],
            'cost_per_result': spend_data[date]['cost_per_result'],
            'revenue': spend_data[date]['revenue'],
        } for date in dates}

        ads[ad_name] = {
            'ad_id': ad_id,  # Include ad_id in the response
            'total_spend': total_spend,
            'total_cost_per_result': total_cost_per_result,
            'total_revenue': total_revenue,
            'daily_data': daily_data,
            'ad_account_name': ad.ad_account.account_name,  # Add the ad account name
            'cpc': ad.cost_per_result,  # Add CPC value
            'budget': ad.ad_set_budget  # Add budget
        }

    # Render the 'fb_insights/analytics.html' template and pass the data
    return render(request, 'fb_insights/ad_data.html', {'ads': ads, 'dates': dates})
