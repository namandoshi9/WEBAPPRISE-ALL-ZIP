

$(document).ready(function(){



    
	//back-top-top
   // jQuery('.back-to-top').click(function () {
   //      jQuery('html, body').animate({scrollTop: 0}, 800);
   //      return false;
   //  });

    
    //menu active class
    $(".sidebar-link").click(function() {
      $(".submenu").slideToggle("main");
    });
    jQuery(function(jQuery) {
      var path = window.location.href; // because the 'href' property of the DOM element is the absolute path
      jQuery('#sidebarnav a').each(function() {
        if (this.href === path) {
          jQuery(this).addClass('active');
          jQuery('.sidebar-link.active').parents('li').parent('.submenu').addClass('active');
          jQuery('.submenu.active').parents('.sidebar-item').children('.sidebar-link').addClass('active');
        }
      });
    });

    // //datepicker
    //     $(function() {

    //         var start = moment().subtract(29, 'days');
    //         var end = moment();

    //         function cb(start, end) {
    //             $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
    //         }

    //         $('#reportrange').daterangepicker({
    //             startDate: start,
    //             endDate: end,
    //             ranges: {
    //                'Today': [moment(), moment()],
    //                'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
    //                'Last 7 Days': [moment().subtract(6, 'days'), moment()],
    //                'Last 30 Days': [moment().subtract(29, 'days'), moment()],
    //                'This Month': [moment().startOf('month'), moment().endOf('month')],
    //                'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
    //             }
    //         }, cb);

    //         cb(start, end);
            
    //     });

    

    //sidetoggle
    $('.toggle_bar').on('click', function() {
        $('.logout_bt').slideToggle();
      });

     $(".profile_detiles .dropdown-toggle").click(function(){
        $(".user_name_detiles").slideToggle();
     });
    //  $(".edit_p, .close_p").click(function(){
    //     $(".edit_upload").toggleClass('main');
    //     $(".file_preview").toggleClass('main');
    //  });
    new VenoBox({
        selector: '.my-image-links',
        numeration: true,
        infinigall: true,
        share: true,
        spinner: 'rotating-plane'
    });

    new VenoBox({
        selector: '.my-video-links',
    });

    new VenoBox({
        selector: '.my-pdf-links',
    });

   //datatable
    $('.data-table-dr').DataTable({
        scrollX: true,  
        pageLength: 100,
       lengthMenu: [ [100, 200, 300, 400], [100, 200, 300, 400] ]
        // fixedHeader: true      
        // fixedColumns:   {
        //     left: 2
        // },
        // language: {
        //     searchPlaceholder: "Search"
        // },
        // columnDefs: [
        //     { "width": "50px", "targets": [0] },       
        //     { "width": "130px", "targets": [1] },       
        //     { "width": "50px", "targets": [2] },
        //     { "width": "70px", "targets": [3,4,5,6,7,8,9,10,11,12,13,14] },
        //     { "width": "63px", "targets": [15] },
        //     { "width": "130px", "targets": [16] },
        //     { "width": "80px", "targets": [17] }
        //   ]
           
    });

  

    //select2
    $('.js-example-basic-single').select2({
        
    });
  
    $(".js-example-basic-multiple").select2({
            //placeholder: "Select MR"
    });
   
    jQuery(function($) {
        new VenoBox({
            selector: '.my-image-links',
            numeration: true,
            infinigall: true,
            share: true,
            spinner: 'rotating-plane'
        });
    });

}); // end ready

$(window).on('load', function(){


    
    

        //loader-script

        

        //$('#myModal').modal('show');



     

}); // end load

$(window).bind('load', function() {
    $('.loader').fadeOut();
});

$(window).on('resize', function(){

    //equalheight('.main_article');

}); // end resize

$(window).on('scroll', function(){

    // ** STICKY OR FIXED JS
    // if ($(this).scrollTop() > 50){  
    //     $('.header').addClass("sticky");
    // }
    // else{
    //     $('.header').removeClass("sticky");
    // }

}); // end scroll