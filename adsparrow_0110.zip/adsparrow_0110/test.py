
# Set up your access token, app ID, and app secret
ACCESS_TOKEN = 'EAAPBBfYwfZBEBO9klWSsK4yGNtfmvcd5ukZCiOYTOYeIA9bZB1SslJjwHwxbXSFlwWqO3YaJaiJe94aZCIydIWBIl12ZAo1dRvPtrYXk2bxYhMXT3AqWhSdb5TbXpUnZBHBBxmyNdSygyp4RDbIupzBjJ1Xl1Qa8qHUIDeTFuMiHCeRuVpS0OAmIhkONQNark8'
AD_ACCOUNT_ID = 'act_265286608472987'  # Example: 'act_1234567890'
APP_ID = '1056656279502817'
APP_SECRET = '2262d17143d0195c0384c347f63f6434'

#================= Token Extender =====================

# import requests

# def extend_fb_token(short_lived_token, app_id, app_secret):
#     url = 'https://graph.facebook.com/v15.0/oauth/access_token'
#     params = {
#         'grant_type': 'fb_exchange_token',
#         'client_id': app_id,            # Your Facebook App ID
#         'client_secret': app_secret,    # Your Facebook App Secret
#         'fb_exchange_token': short_lived_token  # The short-lived token entered by the user
#     }

#     response = requests.get(url, params=params)
#     data = response.json()

#     # Check for errors
#     if 'error' in data:
#         print(f"Error: {data['error']['message']}")
#         return None

#     # Return the long-lived token
#     return data.get('access_token')

# if __name__ == "__main__":
#     # Get user input
#     short_lived_token = input("Enter your short-lived Facebook access token: ")
#     app_id = input("Enter your Facebook App ID: ")
#     app_secret = input("Enter your Facebook App Secret: ")

#     # Extend the token
#     extended_token = extend_fb_token(short_lived_token, app_id, app_secret)

#     if extended_token:
#         print(f"Extended Access Token: {extended_token}")
#     else:
#         print("Failed to extend the access token.")






# #==================== Fetch live budget=================================
import os
from facebook_business.api import FacebookAdsApi
from facebook_business.adobjects.adaccount import AdAccount
from facebook_business.adobjects.ad import Ad
from facebook_business.adobjects.adset import AdSet

# Initialize the Facebook API
FacebookAdsApi.init(app_id=APP_ID, app_secret=APP_SECRET, access_token=ACCESS_TOKEN)

def format_budget(cents):
    """Convert budget from cents to dollars."""
    if cents is None or cents == 'Not Set':
        return 0.0
    try:
        return int(cents) / 100.0  # Ensure we convert to integer before dividing
    except ValueError:
        return 0.0  # In case of conversion failure

def fetch_adset_budget(ad_account_id):
    try:
        # Get the ad account object
        ad_account = AdAccount(ad_account_id)

        # Initialize a variable to keep track of pagination
        adsets = ad_account.get_ad_sets(fields=[
            AdSet.Field.name,
            AdSet.Field.daily_budget,
            AdSet.Field.lifetime_budget,
            AdSet.Field.status
        ])

        # Loop through the pages of ad sets
        while True:
            # Print the details for the current page of ad sets
            for adset in adsets:
                name = adset[AdSet.Field.name]
                daily_budget_cents = adset.get(AdSet.Field.daily_budget, 'Not Set')
                lifetime_budget_cents = adset.get(AdSet.Field.lifetime_budget, 'Not Set')
                status = adset[AdSet.Field.status]

                # Format the budgets in dollars
                daily_budget = format_budget(daily_budget_cents)
                lifetime_budget = format_budget(lifetime_budget_cents)

                # Display individual ad set budget without totaling
                print(f"Ad Set Name: {name}")
                print(f"Status: {status}")
                print(f"Daily Budget: ${daily_budget:.2f}")  # Format as dollar
                print(f"Lifetime Budget: ${lifetime_budget:.2f}")  # Format as dollar
                print("-" * 50)

            # Check if there is a next page
            if 'paging' in adsets and 'next' in adsets['paging']:
                # Get the next page of ad sets
                adsets = adsets['paging']['next']
            else:
                break

    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == '__main__':
    fetch_adset_budget(AD_ACCOUNT_ID)



