# from django.contrib import admin
# from import_export import resources
# from import_export.admin import ImportExportModelAdmin
# from .models import Profile, FacebookAdAccount, FacebookCampaign, FacebookAdSet, FacebookAd, FacebookAdInsight

# # Define the resource for import/export
# class FacebookAdAccountResource(resources.ModelResource):
#     class Meta:
#         model = FacebookAdAccount
#         fields = ('id', 'user', 'fb_ad_account_id', 'fb_ad_account_name', 
#                   'fb_ad_account_status', 'is_visible', 'is_active', 'created_at')

# # Extend the admin class for FacebookAdAccount
# @admin.register(FacebookAdAccount)
# class FacebookAdAccountAdmin(ImportExportModelAdmin):
#     resource_class = FacebookAdAccountResource
#     list_display = (
#         'id', 'user', 'fb_ad_account_id', 'fb_ad_account_name',
#         'fb_ad_account_status', 'is_visible', 'is_active', 'created_at'
#     )
#     list_filter = ('fb_ad_account_status', 'is_visible', 'is_active')
#     search_fields = ('fb_ad_account_id', 'fb_ad_account_name', 'user__username')
#     readonly_fields = ('created_at', 'updated_at')
#     ordering = ('-created_at',)

# @admin.register(FacebookCampaign)
# class FacebookCampaignAdmin(admin.ModelAdmin):
#     list_display = ('campaign_name', 'campaign_id', 'fb_ad_account','created_at', 'updated_at')
#     search_fields = ('campaign_name', 'campaign_id', 'fb_ad_account__fb_ad_account_name')
#     list_filter =  ('fb_ad_account',)
#     ordering = ('-created_at',)

# @admin.register(FacebookAdSet)
# class FacebookAdSetAdmin(admin.ModelAdmin):
#     list_display = ('adset_name', 'adset_id', 'fb_campaign', 'daily_budget', 'created_at', 'updated_at')
#     search_fields = ('adset_name', 'adset_id', 'fb_campaign__campaign_name', 'fb_ad_account__fb_ad_account_name')
#     list_filter = ('fb_campaign',)
#     ordering = ('-created_at',)


# @admin.register(FacebookAd)
# class FacebookAdAdmin(admin.ModelAdmin):
#     list_display = ('ad_name', 'ad_id', 'fb_ad_set',  'status', 'created_at', 'updated_at')
#     search_fields = ('ad_name', 'ad_id', 'fb_campaign__campaign_name', 'fb_ad_account__fb_ad_account_name')
#     list_filter = ('status',)
#     ordering = ('-created_at',)




# @admin.register(FacebookAdInsight)
# class FacebookAdInsightAdmin(admin.ModelAdmin):
#     list_display = (
#         'fb_ad', 'impressions', 'clicks', 'reach', 'spend', 'created_at', 'updated_at'
#     )
#     search_fields = ('fb_ad__ad_name', 'fb_ad__ad_id')
#     list_filter = ('fb_ad',)
#     readonly_fields = ('created_at', 'updated_at')


# @admin.register(Profile)
# class ProfileAdmin(admin.ModelAdmin):
#     list_display = ('user', 'is_premium')



from django.contrib import admin
from import_export import resources
from import_export.admin import ImportExportModelAdmin
from .models import TrafficSourceMedium,Profile, FacebookAdAccount, FacebookCampaign, FacebookAdSet, FacebookAd, FacebookAdInsight, CronJobLog, GoogleAnalyticsAccount

# Define the resource for import/export
class FacebookAdAccountResource(resources.ModelResource):
    class Meta:
        model = FacebookAdAccount
        fields = ('id', 'user', 'fb_ad_account_id', 'fb_ad_account_name', 
                  'fb_ad_account_status', 'is_visible', 'is_active', 'created_at')

# Extend the admin class for FacebookAdAccount
@admin.register(FacebookAdAccount)
class FacebookAdAccountAdmin(ImportExportModelAdmin):
    resource_class = FacebookAdAccountResource
    list_display = (
        'id', 'user', 'fb_ad_account_id', 'fb_ad_account_name',
        'fb_ad_account_status', 'is_visible', 'is_active', 'created_at'
    )
    list_filter = ('fb_ad_account_status', 'is_visible', 'is_active')
    search_fields = ('fb_ad_account_id', 'fb_ad_account_name', 'user__username')
    readonly_fields = ('created_at', 'updated_at')
    ordering = ('-created_at',)

@admin.register(FacebookCampaign)
class FacebookCampaignAdmin(admin.ModelAdmin):
    list_display = ('campaign_name', 'campaign_id', 'fb_ad_account', 'created_at', 'updated_at')
    search_fields = ('campaign_name', 'campaign_id', 'fb_ad_account__fb_ad_account_name')
    list_filter = ('fb_ad_account',)
    ordering = ('-created_at',)

@admin.register(FacebookAdSet)
class FacebookAdSetAdmin(admin.ModelAdmin):
    list_display = ('adset_name', 'adset_id', 'fb_campaign', 'daily_budget', 'created_at', 'updated_at')
    search_fields = ('adset_name', 'adset_id')
    list_filter = ('fb_campaign',)
    ordering = ('-created_at',)

    def daily_budget(self, obj):
        if obj.daily_budget:
            return f"${obj.daily_budget:,.2f}"
        return "N/A"
    daily_budget.admin_order_field = 'daily_budget'  # Enables sorting by this field

@admin.register(FacebookAd)
class FacebookAdAdmin(admin.ModelAdmin):
    list_display = ('ad_name', 'ad_id', 'fb_ad_set', 'status', 'created_at', 'updated_at')
    search_fields = ('ad_name', 'ad_id', 'fb_ad_set__adset_name', 'fb_ad_set__fb_campaign__campaign_name', 'fb_ad_set__fb_campaign__fb_ad_account__fb_ad_account_name')
    list_filter = ('status',)
    ordering = ('-created_at',)

@admin.register(FacebookAdInsight)
class FacebookAdInsightAdmin(admin.ModelAdmin):
    list_display = (
        'fb_ad', 'impressions', 'clicks', 'reach', 'spend', 'link_clicks', 'cost_per_link_click', 'date', 'created_at', 'updated_at'
    )
    search_fields = ('fb_ad__ad_name', 'fb_ad__ad_id', 'date')
    list_filter = ('fb_ad', 'date')
    readonly_fields = ('created_at', 'updated_at')
    ordering = ('-date',)

@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'is_premium')
    search_fields = ('user__username',)
    ordering = ('user__username',)


@admin.register(CronJobLog)
class CronJobLogAdmin(admin.ModelAdmin):
    list_display = ('user', 'fb_ad_account', 'google_account', 'status', 'message', 'created_at', 'updated_at')  # Displaying related fields
    list_filter = ('status',)  # Allow filtering by status
    search_fields = ('user__username', 'fb_ad_account__fb_ad_account_name', 'google_account__property_id', 'message')  # Corrected field names
    ordering = ('-created_at',)  # Order by creation date, descending



@admin.register(GoogleAnalyticsAccount)
class GoogleAnalyticsAccountAdmin(admin.ModelAdmin):
    # Fields to display in the list view
    list_display = ('id','property_id','Google_account_name','user','is_visible','is_active','google_account_status','created_at','updated_at')

    # Fields to search in the admin interface
    search_fields = ('property_id', 'Google_account_name', 'user__username')

    # Filters for the list view
    list_filter = ('is_visible', 'is_active', 'google_account_status', 'created_at')



@admin.register(TrafficSourceMedium)
# ModelAdmin class to customize the display of TrafficSourceMedium
class TrafficSourceMediumAdmin(admin.ModelAdmin):
    list_display = ('Google_account', 'source', 'medium', 'date', 'daily_revenue', 'sessions', 'active_users','created_at', 'updated_at')
    search_fields = ('source', 'medium')  # Allow searching by these fields
    list_filter = ('Google_account', 'date')  # Filters by Google_account and date
    ordering = ('date',)  # Default ordering by date
