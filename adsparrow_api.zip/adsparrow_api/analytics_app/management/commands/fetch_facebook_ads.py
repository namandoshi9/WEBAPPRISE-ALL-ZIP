import traceback
from django.core.management.base import BaseCommand
from django.utils.timezone import now
from analytics_app.models import FacebookAdAccount
from analytics_app.views import FacebookAdDataView

class Command(BaseCommand):
    help = 'Fetch Facebook Ad Insights for all users and their accounts'

    def handle(self, *args, **kwargs):
        # Initialize the view to reuse the fetch_facebook_insights method
        ad_data_view = FacebookAdDataView()

        # Start the cron task
        print(f"Starting cron task at {now()}")

        # Get all users who have FacebookAdAccount records
        users = FacebookAdAccount.objects.values_list('user', flat=True).distinct()

        for user_id in users:
            try:
                # Fetch ad accounts for the current user
                ad_accounts = FacebookAdAccount.objects.filter(user_id=user_id, is_active=True)

                for account in ad_accounts:
                    try:
                        # Call the fetch_facebook_insights method from the view
                        ad_data_view.fetch_facebook_insights(
                            ad_account_id=account.fb_ad_account_id,
                            access_token=account.fb_ad_access_token,
                            app_id=account.fb_ad_app_id,
                            app_secret=account.fb_ad_app_secret_key,
                            user=account.user
                        )

                        print(f"Data fetched for account {account.fb_ad_account_id}")

                    except Exception as account_error:
                        # Log errors for this ad account
                        print(f"Error fetching data for account {account.fb_ad_account_id}: {account_error}")
                        traceback.print_exc()

            except Exception as user_error:
                # Log errors for this user
                print(f"Error processing user {user_id}: {user_error}")
                traceback.print_exc()

        print(f"Cron task completed at {now()}")
