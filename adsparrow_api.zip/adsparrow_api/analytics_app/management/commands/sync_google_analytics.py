from django.core.management.base import BaseCommand
from django.utils.timezone import now
from analytics_app.models import GoogleAnalyticsAccount, CronJobLog, TrafficSourceMedium
from google.auth.exceptions import GoogleAuthError
from google.api_core.exceptions import PermissionDenied
from analytics_app.utils import standard_response  # Import standard_response if needed
from datetime import datetime, timedelta
from google.oauth2 import service_account
from google.analytics.data_v1beta import BetaAnalyticsDataClient
from google.analytics.data_v1beta.types import RunReportRequest, DateRange, Metric, Dimension


class Command(BaseCommand):
    help = 'Syncs Google Analytics data and logs the cron job status.'

    def handle(self, *args, **kwargs):
        # Get all Google Analytics accounts
        google_accounts = GoogleAnalyticsAccount.objects.all()

        for google_account in google_accounts:
            # Initialize cron_log as pending before any action
            cron_log = CronJobLog.objects.create(
                user=google_account.user,  # or assign user if required
                fb_ad_account=None,  # or assign fb ad account if required
                status='pending',
                message=f"Sync started for Google Analytics account: {google_account.Google_account_name}",
                google_account=google_account  # Assuming you have a foreign key to GoogleAnalyticsAccount
            )

            try:
                json_key_path = google_account.json_key.path
                property_id = google_account.property_id
                today = datetime.now().date()

                # Fetch data for the last 3 full days and today
                for i in range(4):
                    day = today - timedelta(days=i)
                    start_date = day.strftime('%Y-%m-%d')
                    end_date = day.strftime('%Y-%m-%d')

                    # Fetch GA4 report for each day
                    response = self.get_ga4_report(json_key_path, property_id, start_date, end_date)

                    for row in response.rows:
                        source = row.dimension_values[0].value
                        medium = row.dimension_values[1].value
                        sessions = int(row.metric_values[0].value)
                        active_users = int(row.metric_values[1].value)
                        total_revenue = float(row.metric_values[2].value)

                        # Check if data exists for the same source, medium, and date
                        traffic_source, created = TrafficSourceMedium.objects.get_or_create(
                            Google_account=google_account,
                            source=source,
                            medium=medium,
                            date=start_date,
                            defaults={
                                'total_revenue': total_revenue,
                                'sessions': sessions,
                                'active_users': active_users
                            }
                        )

                        if not created:
                            traffic_source.sessions = sessions
                            traffic_source.active_users = active_users
                            traffic_source.total_revenue = total_revenue
                            traffic_source.save()

                # Update Google account status
                google_account.google_account_status = 'success'
                google_account.save()

                # Update cron job log to success
                cron_log.status = 'success'
                cron_log.message = f"Sync completed successfully for Google Analytics account: {google_account.Google_account_name}"
                cron_log.save()

            except PermissionDenied as e:
                # Handle Google Analytics API error: insufficient permissions
                cron_log.status = 'failed'
                cron_log.message = f"Permission denied for Google Analytics account: {google_account.Google_account_name}"
                cron_log.save()

            except GoogleAuthError as e:
                # Handle Google Authentication error
                cron_log.status = 'failed'
                cron_log.message = f"Google authentication error for account: {google_account.Google_account_name}."
                cron_log.save()

            except Exception as e:
                # Handle other exceptions
                cron_log.status = 'failed'
                cron_log.message = f"Error syncing Google Analytics account {google_account.Google_account_name}: {str(e)}"
                cron_log.save()

    def get_ga4_report(self, json_key_path, property_id, start_date, end_date):
        # Authenticate using service account credentials
        credentials = service_account.Credentials.from_service_account_file(json_key_path)
        client = BetaAnalyticsDataClient(credentials=credentials)

        # Create the request to retrieve traffic data
        request = RunReportRequest(
            property=f"properties/{property_id}",
            date_ranges=[DateRange(start_date=start_date, end_date=end_date)],
            metrics=[
                Metric(name="sessions"),
                Metric(name="activeUsers"),
                Metric(name="totalRevenue")
            ],
            dimensions=[
                Dimension(name="sessionSource"),
                Dimension(name="sessionMedium")
            ]
        )

        # Run the report and return the response
        response = client.run_report(request=request)
        return response
