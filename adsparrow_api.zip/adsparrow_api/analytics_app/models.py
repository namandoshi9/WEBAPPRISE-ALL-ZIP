from django.db import models
from django.contrib.auth.models import User

class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    is_premium = models.BooleanField(default=False)

    def __str__(self):
        return f'{self.user.username} Profile'


class FacebookAdAccount(models.Model):
    REVIEW_PENDING = 'review_pending'
    SUCCESS = 'success'
    FAILED = 'failed'

    ACCOUNT_STATUS_CHOICES = [
        (REVIEW_PENDING, 'Review Pending'),
        (SUCCESS, 'Success'),
        (FAILED, 'Failed'), 
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='fb_ad_accounts')
    fb_ad_account_id = models.CharField(max_length=255, unique=True)
    fb_ad_account_name = models.CharField(max_length=255)
    fb_ad_access_token = models.TextField()
    fb_ad_app_id = models.CharField(max_length=255)
    fb_ad_app_secret_key = models.CharField(max_length=255)
    fb_ad_account_status = models.CharField(
        max_length=20,
        choices=ACCOUNT_STATUS_CHOICES,
        default=REVIEW_PENDING
    )
    is_visible = models.BooleanField(default=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.fb_ad_account_name



class FacebookCampaign(models.Model):
    fb_ad_account = models.ForeignKey(FacebookAdAccount, on_delete=models.CASCADE, related_name='campaigns')
    campaign_id = models.CharField(max_length=255)
    campaign_name = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.campaign_name


class FacebookAdSet(models.Model):
    fb_campaign = models.ForeignKey(FacebookCampaign, on_delete=models.CASCADE, related_name='adsets')
    adset_id = models.CharField(max_length=255)
    adset_name = models.CharField(max_length=255)
    daily_budget = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)  # Replaced field
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.adset_name


class FacebookAd(models.Model):
    fb_ad_set = models.ForeignKey(FacebookAdSet, on_delete=models.CASCADE, related_name='ads')
    ad_id = models.CharField(max_length=255)
    ad_name = models.CharField(max_length=255)
    status = models.CharField(max_length=50)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.ad_name



class FacebookAdInsight(models.Model):
    fb_ad = models.ForeignKey('FacebookAd', on_delete=models.CASCADE, related_name='insights')
    impressions = models.PositiveIntegerField(default=0)  # Total impressions
    clicks = models.PositiveIntegerField(default=0)       # Total clicks
    reach = models.PositiveIntegerField(default=0)        # Total reach
    spend = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)  # Total spend
    link_clicks = models.IntegerField(null=True, blank=True)
    cost_per_link_click = models.DecimalField(max_digits=10, decimal_places=2)
    cost_per_result = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)  # New field for cost per result
    date = models.DateField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Insights for Ad: {self.fb_ad.ad_name} ({self.date}"



class GoogleAnalyticsAccount(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='ga_accounts')  # New field
    property_id = models.CharField(max_length=255)
    Google_account_name = models.CharField(max_length=255, default='Google Analytics')
    json_key = models.FileField(upload_to='google_keys/')
    is_visible = models.BooleanField(default=True)  # Default to True
    is_active = models.BooleanField(default=True)  # Default to True
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    ACCOUNT_STATUS_CHOICES = [
        ('success', 'Success'),
        ('failed', 'Failed'),
        ('review_pending', 'Review Pending'),
    ]
    google_account_status = models.CharField(max_length=20, choices=ACCOUNT_STATUS_CHOICES, default='review_pending')

    def __str__(self):
        return self.property_id


class TrafficSourceMedium(models.Model):
    Google_account = models.ForeignKey(GoogleAnalyticsAccount, on_delete=models.CASCADE)
    fb_ad_account = models.ForeignKey(FacebookAdAccount, on_delete=models.CASCADE,null=True, blank=True)
    source = models.CharField(max_length=255)
    medium = models.CharField(max_length=255)
    daily_revenue = models.FloatField()
    sessions = models.IntegerField(default=0)
    active_users = models.IntegerField(default=0)
    date = models.DateField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.source} - {self.medium}"


class CronJobLog(models.Model):
    STATUS_CHOICES = [
        ('success', 'Success'),
        ('failed', 'Failed'),
        ('Review_pending', 'Review_pending'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='cron_logs', blank=True, null=True)
    fb_ad_account = models.ForeignKey(FacebookAdAccount, on_delete=models.CASCADE, related_name='cron_logs', blank=True, null=True)
    google_account = models.ForeignKey(GoogleAnalyticsAccount, on_delete=models.CASCADE, related_name='cron_logs', blank=True, null=True)  # Add this line
    status = models.CharField(max_length=100, choices=STATUS_CHOICES, default='Review_pending')
    message = models.TextField(blank=True, null=True)  # To store error messages or status messages
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        # return f"{self.user} - {self.fb_ad_account} - {self.ga_ad_account} - {self.status} - {self.created_at}"
        return f"{self.user} - {self.fb_ad_account} -  {self.status} - {self.created_at}"



