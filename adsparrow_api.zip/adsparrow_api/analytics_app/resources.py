# resources.py
from import_export import resources
from .models import FacebookAdAccount

class FacebookAdAccountResource(resources.ModelResource):
    class Meta:
        model = FacebookAdAccount
        fields = ('id', 'fb_ad_account_id', 'account_name', 'user')  # Specify the fields to import/export
