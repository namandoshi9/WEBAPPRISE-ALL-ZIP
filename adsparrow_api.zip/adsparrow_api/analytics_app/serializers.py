from django.contrib.auth.models import User
from rest_framework import serializers
from rest_framework.authtoken.models import Token  # Import Token model
from django.contrib.auth import authenticate
from .models import FacebookAdAccount,Profile,FacebookAdInsight,FacebookAdSet,FacebookAd,FacebookCampaign, TrafficSourceMedium,GoogleAnalyticsAccount
from decimal import Decimal
from datetime import timedelta

#================ Authenticat user serializer ================

class RegisterUserSerializer(serializers.ModelSerializer):
    email = serializers.EmailField(
        required=True, 
        error_messages={'required': 'Email is required', 'unique': 'Email must be unique.'}
    )
    name = serializers.CharField(required=True, error_messages={'required': 'Name is required'})
    password = serializers.CharField(
        write_only=True, 
        required=True, 
        style={'input_type': 'password'}, 
        error_messages={'required': 'Password is required'}
    )
    is_premium = serializers.BooleanField(required=False, default=False)

    class Meta:
        model = User
        fields = ['email', 'name', 'password', 'is_premium']

    def create(self, validated_data):
        # Check if email already exists
        if User.objects.filter(email=validated_data['email']).exists():
            raise serializers.ValidationError("A user with this email already exists.")

        # Create the user
        user = User.objects.create_user(
            username=validated_data['email'],
            email=validated_data['email'],
            first_name=validated_data['name'],
            password=validated_data['password']
        )

        # Set the premium status (if provided)
        is_premium = validated_data.get('is_premium', False)
        
        # Create the profile with is_premium
        Profile.objects.create(user=user, is_premium=is_premium)

        # Set the user as staff (optional)
        user.is_staff = True
        user.save()

        # Generate a token for the user
        token, created = Token.objects.get_or_create(user=user)

        return user, token.key

    def update(self, instance, validated_data):
        # Update the name
        if 'name' in validated_data:
            instance.first_name = validated_data['name']

        # Update the password
        if 'password' in validated_data:
            instance.set_password(validated_data['password'])

        # Update the profile if 'is_premium' is provided
        if 'is_premium' in validated_data:
            profile = instance.profile
            profile.is_premium = validated_data['is_premium']
            profile.save()

        instance.save()
        return instance


class LoginUserSerializer(serializers.Serializer):
    email = serializers.EmailField(
        required=True, 
        error_messages={
            'required': 'Email is required.',
            'invalid': 'Invalid email format.'
        }
    )
    password = serializers.CharField(
        write_only=True, 
        required=True, 
        style={'input_type': 'password'},
        error_messages={'required': 'Password is required.'}
    )

    def validate(self, data):
        email = data.get("email")
        password = data.get("password")

        # Validate email and password are not blank
        if not email or not password:
            raise serializers.ValidationError("Both email and password are required and cannot be blank.")
        
        # Authenticate user
        user = authenticate(username=email, password=password)
        if user and user.is_active:
            data['user'] = user
        else:
            raise serializers.ValidationError("Invalid email or password.")
        
        return data



#================ Fb ad account serializer ================

class FacebookAdAccountSerializer(serializers.ModelSerializer):
    class Meta:
        model = FacebookAdAccount
        fields = [
            'id','user','fb_ad_account_id','fb_ad_account_name','fb_ad_access_token','fb_ad_app_id','fb_ad_app_secret_key','fb_ad_account_status',
            'is_visible','is_active','created_at','updated_at'
        ]
        read_only_fields = ['created_at', 'updated_at', 'fb_ad_account_status']
        

class AdInsightSerializer(serializers.ModelSerializer):
    class Meta:
        model = FacebookAdInsight
        fields = ['impressions', 'clicks', 'spend', 'reach', 'link_clicks', 'cost_per_link_click', 'date']


class AdSerializer(serializers.ModelSerializer):
    insights = AdInsightSerializer(many=True, read_only=True)

    class Meta:
        model = FacebookAd
        fields = ['ad_id', 'name', 'status', 'creative_id', 'insights']


class AdSetSerializer(serializers.ModelSerializer):
    ads = AdSerializer(many=True, read_only=True)

    class Meta:
        model = FacebookAdSet
        fields = ['ad_set_id', 'name', 'status', 'daily_budget', 'ads']


class CampaignSerializer(serializers.ModelSerializer):
    ad_sets = AdSetSerializer(many=True, read_only=True)

    class Meta:
        model = FacebookCampaign
        fields = ['campaign_id', 'name', 'status', 'ad_sets']


#================ Google analytics account serializer ================

class GoogleAnalyticsAccountSerializer(serializers.ModelSerializer):
    class Meta:
        model = GoogleAnalyticsAccount
        fields = ['id', 'user', 'property_id', 'Google_account_name', 'json_key', 'is_visible', 'is_active', 'created_at', 'updated_at', 'google_account_status']


    def validate_json_key(self, value):
        """
        Validate that the JSON file is in .json format.
        """
        if not value.name.endswith('.json'):
            raise serializers.ValidationError("The uploaded file must be in .json format.")
        return value

    def validate(self, data):
        """
        Additional validation can be added here, such as checking for other constraints.
        """
        # Check if both property_id and json_key are provided
        if not data.get('property_id'):
            raise serializers.ValidationError({'property_id': 'Property ID is required.'})
        if not data.get('json_key'):
            raise serializers.ValidationError({'json_key': 'JSON key is required.'})

        return data



class TrafficSourceMediumSerializer(serializers.ModelSerializer):
    class Meta:
        model = TrafficSourceMedium
        fields = ['source', 'medium', 'daily_revenue', 'date', 'Google_account', 'fb_ad_account']



#================ Analytics Analysis serializer ================

class AnalyticsAnalysisSerializer(serializers.ModelSerializer):
    ad_name = serializers.CharField(source='fb_ad.ad_name')
    impression = serializers.IntegerField(source='impressions')
    spend = serializers.DecimalField(max_digits=10, decimal_places=2)
    cost_per_link_click = serializers.DecimalField(max_digits=10, decimal_places=2)
    date = serializers.DateField()
    ad_status = serializers.CharField(source='fb_ad.status')
    daily_budget = serializers.DecimalField(source='fb_ad.fb_ad_set.daily_budget', max_digits=10, decimal_places=2)

    class Meta:
        model = FacebookAdInsight
        fields = ['ad_name', 'impression', 'spend', 'cost_per_link_click', 'date', 'ad_status', 'daily_budget']




#================ Last 7 days trend serializer ================

class AdLast7DaysSerializer(serializers.ModelSerializer):
    spend_data = serializers.SerializerMethodField()
    spend_with_gst_data = serializers.SerializerMethodField()
    cost_per_link_click_data = serializers.SerializerMethodField()
    profit_loss_data = serializers.SerializerMethodField()
    roi_data = serializers.SerializerMethodField()
    daily_revenue_data = serializers.SerializerMethodField()
    total_spend = serializers.SerializerMethodField()
    total_spend_with_gst = serializers.SerializerMethodField()
    avg_cost_per_link_click = serializers.SerializerMethodField()
    sum_profit_loss = serializers.SerializerMethodField()  
    avg_roi = serializers.SerializerMethodField()  
    sum_daily_revenue = serializers.SerializerMethodField()  # New field for sum of daily revenue
    status = serializers.SerializerMethodField()  # New field for status
    daily_budget = serializers.SerializerMethodField()  # New field for daily_budget
    ad_account_name = serializers.SerializerMethodField()  # New field for ad account name

    class Meta:
        model = FacebookAd
        fields = ['ad_account_name', 'ad_id', 'ad_name', 'status', 'daily_budget', 'spend_data', 'spend_with_gst_data', 'cost_per_link_click_data', 'profit_loss_data', 'roi_data', 'daily_revenue_data', 'total_spend', 'total_spend_with_gst', 'avg_cost_per_link_click', 'sum_profit_loss', 'avg_roi', 'sum_daily_revenue']
    
    
    def get_spend_data(self, obj):
        today = self.context.get('today')
        spend_data = {}
        for i in range(7):
            date = today - timedelta(days=i)
            insight = obj.insights.filter(date=date).first()
            if insight:
                spend = insight.spend
                spend_data[str(date)] = spend
            else:
                spend_data[str(date)] = "-"
        return [spend_data]

    def get_spend_with_gst_data(self, obj):
        today = self.context.get('today')
        spend_with_gst_data = {}
        for i in range(7):
            date = today - timedelta(days=i)
            insight = obj.insights.filter(date=date).first()
            if insight:
                spend = insight.spend
                spend_with_gst = spend * Decimal('1.18')
                spend_with_gst_data[str(date)] = spend_with_gst
            else:
                spend_with_gst_data[str(date)] = "-"
        return [spend_with_gst_data]

    def get_cost_per_link_click_data(self, obj):
        today = self.context.get('today')
        cost_per_link_click_data = {}
        for i in range(7):
            date = today - timedelta(days=i)
            insight = obj.insights.filter(date=date).first()
            if insight:
                cost_per_link_click = insight.cost_per_link_click
                cost_per_link_click_data[str(date)] = cost_per_link_click
            else:
                cost_per_link_click_data[str(date)] = "-"
        return [cost_per_link_click_data]

    def get_profit_loss_data(self, obj):
        today = self.context.get('today')
        profit_loss_data = {}
        for i in range(7):
            date = today - timedelta(days=i)
            insight = obj.insights.filter(date=date).first()
            daily_revenue = self.get_daily_revenue_for_date(obj, date)
            if insight:
                spend = insight.spend
                spend_with_gst = spend * Decimal('1.18')
                profit_loss = daily_revenue - spend_with_gst
                profit_loss_data[str(date)] = profit_loss
            else:
                profit_loss_data[str(date)] = "-"
        return [profit_loss_data]

    def get_roi_data(self, obj):
        today = self.context.get('today')
        roi_data = {}
        for i in range(7):
            date = today - timedelta(days=i)
            insight = obj.insights.filter(date=date).first()
            daily_revenue = self.get_daily_revenue_for_date(obj, date)
            if insight:
                spend = insight.spend
                spend_with_gst = spend * Decimal('1.18')
                roi = daily_revenue / spend_with_gst if spend_with_gst > Decimal('0.00') else Decimal('0.00')
                roi_data[str(date)] = roi
            else:
                roi_data[str(date)] = "-"
        return [roi_data]

    def get_daily_revenue_data(self, obj):
        today = self.context.get('today')
        daily_revenue_data = {}
        for i in range(7):
            date = today - timedelta(days=i)
            traffic_data = TrafficSourceMedium.objects.filter(
                fb_ad_account=obj.fb_ad_set.fb_campaign.fb_ad_account,
                medium=obj.ad_name,  # Matching ad_name with medium
                date=date
            ).first()

            if traffic_data:
                daily_revenue = traffic_data.daily_revenue
                daily_revenue_data[str(date)] = daily_revenue
            else:
                daily_revenue_data[str(date)] = "-"
        return [daily_revenue_data]

    def get_daily_revenue_for_date(self, obj, date):
        """
        Helper method to fetch daily revenue for a specific date.
        """
        traffic_data = TrafficSourceMedium.objects.filter(
            fb_ad_account=obj.fb_ad_set.fb_campaign.fb_ad_account,
            medium=obj.ad_name,  # Matching ad_name with medium
            date=date
        ).first()

        if traffic_data:
            return traffic_data.daily_revenue
        return Decimal('0.00')  # Return 0 if no data exists

    def get_total_spend(self, obj):
        today = self.context.get('today')
        total_spend = Decimal('0.00')
        for i in range(7):
            date = today - timedelta(days=i)
            insight = obj.insights.filter(date=date).first()
            if insight:
                total_spend += insight.spend
        return total_spend

    def get_total_spend_with_gst(self, obj):
        today = self.context.get('today')
        total_spend_with_gst = Decimal('0.00')
        for i in range(7):
            date = today - timedelta(days=i)
            insight = obj.insights.filter(date=date).first()
            if insight:
                spend = insight.spend
                spend_with_gst = spend * Decimal('1.18')
                total_spend_with_gst += spend_with_gst
        return total_spend_with_gst

    def get_avg_cost_per_link_click(self, obj):
        today = self.context.get('today')
        total_cost_per_link_click = Decimal('0.00')
        count = 0
        for i in range(7):
            date = today - timedelta(days=i)
            insight = obj.insights.filter(date=date).first()
            if insight and insight.cost_per_link_click:
                total_cost_per_link_click += insight.cost_per_link_click
                count += 1
        # Avoid division by zero, return 0 if no valid cost data exists
        return total_cost_per_link_click / count if count > 0 else Decimal('0.00')

    def get_sum_profit_loss(self, obj):
        today = self.context.get('today')
        total_profit_loss = Decimal('0.00')
        for i in range(7):
            date = today - timedelta(days=i)
            insight = obj.insights.filter(date=date).first()
            daily_revenue = self.get_daily_revenue_for_date(obj, date)
            if insight:
                spend = insight.spend
                spend_with_gst = spend * Decimal('1.18')
                profit_loss = daily_revenue - spend_with_gst
                total_profit_loss += profit_loss
        return total_profit_loss

    def get_avg_roi(self, obj):
        today = self.context.get('today')
        total_roi = Decimal('0.00')
        count = 0
        for i in range(7):
            date = today - timedelta(days=i)
            insight = obj.insights.filter(date=date).first()
            daily_revenue = self.get_daily_revenue_for_date(obj, date)
            if insight and daily_revenue > Decimal('0.00'):
                spend = insight.spend
                spend_with_gst = spend * Decimal('1.18')
                roi = daily_revenue / spend_with_gst if spend_with_gst > Decimal('0.00') else Decimal('0.00')
                total_roi += roi
                count += 1
        # Avoid division by zero, return 0 if no valid ROI data exists
        return total_roi / count if count > 0 else Decimal('0.00')

    def get_sum_daily_revenue(self, obj):
        today = self.context.get('today')
        total_daily_revenue = Decimal('0.00')
        for i in range(7):
            date = today - timedelta(days=i)
            daily_revenue = self.get_daily_revenue_for_date(obj, date)
            total_daily_revenue += daily_revenue
        return total_daily_revenue

    def get_status(self, obj):
        """
        Helper method to fetch the status of the Facebook Ad.
        """
        return obj.status  # Assuming `status` is a field in the `FacebookAd` model

    def get_daily_budget(self, obj):
        """
        Helper method to fetch the daily budget from the associated AdSet.
        """
        return obj.fb_ad_set.daily_budget  # Assuming `fb_ad_set` is the related field

    def get_ad_account_name(self, obj):
        """
        Helper method to fetch the ad account name from the associated AdAccount.
        """
        return obj.fb_ad_set.fb_campaign.fb_ad_account.fb_ad_account_name  # Assuming `fb_ad_set.fb_campaign.fb_ad_account.name`


    