from django.urls import path
from .views import Last7DaysTrendsView,GetOrUpdateDailyBudget,AnalyticsAnalysis, GoogleAnalyticsSyncView, ManageUserView, LoginUserView, LogoutUserView, DashboardView, FacebookAdAccountView, FacebookAdDataView, GoogleAnalyticsAccountView

urlpatterns = [

    #================ Authenticat user view ================
    
    path('manageuser/', ManageUserView.as_view(), name='manageuser'),
    path('login/', LoginUserView.as_view(), name='login'),  # Add login URL
    path('logout/', LogoutUserView.as_view(), name='logout'),  # Add logout URL

    #================ Dashboard view ================

    path('dashboard/', DashboardView.as_view(), name='dashboard'),

    #================ Fb ad acccount view =================

    path('facebook-ad-account/', FacebookAdAccountView.as_view(), name='add_facebook_ad_account'),
    path('facebook-ad-account/<int:pk>/', FacebookAdAccountView.as_view(), name='update_facebook_ad_account'),

    # path('fetch-facebook-ads-data/', FetchFacebookAdsData.as_view(), name='fetch_facebook_ads_data'),
    path('facebook/ad-data/<str:ad_account_id>/', FacebookAdDataView.as_view(), name='facebook_ad_data'),

    #=============== Google Analytics ================
    path('google-accounts/', GoogleAnalyticsAccountView.as_view(), name='add_google_account'),
    path('google-accounts/<int:pk>/', GoogleAnalyticsAccountView.as_view(), name='add_google_account'),
    path('google-analytics/sync/<int:account_id>/', GoogleAnalyticsSyncView.as_view(), name='google-analytics-sync'),   


    #================ Analytics Analysis ===============
    path('analytics/', AnalyticsAnalysis.as_view(), name='analytics_analysis'), 

    #================ Get or update daily budget & status ===============
    path('get-daily-budget/', GetOrUpdateDailyBudget.as_view(), name='get-daily-budget'),


    #=============== last 7 days trends data ===============
    path('last-7-days-spend/', Last7DaysTrendsView.as_view(), name='last-7-days-spend'),
]
