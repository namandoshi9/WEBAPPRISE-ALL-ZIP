from rest_framework.views import exception_handler
from rest_framework.exceptions import MethodNotAllowed
from rest_framework.response import Response


def standard_response(status_code, message, data=None):
    """
    Create a standard JSON response format.
    """
    response = {
        "status": status_code,
        "message": message
    }
    # Return an empty array instead of an empty dictionary when no data is provided
    if data is None:
        response["data"] = []
    else:
        response["data"] = data
    return response





def custom_exception_handler(exc, context):
    """
    Custom exception handler for Django REST Framework.
    Handles method not allowed errors dynamically and formats them in a custom response.
    """
    response = exception_handler(exc, context)

    if response is not None:
        # If the exception is a MethodNotAllowed, handle dynamic method errors
        if isinstance(exc, MethodNotAllowed):
            method = context['request'].method
            allowed_methods = context['view'].allowed_methods  # Get allowed methods for the view
            
            # Create the dynamic message
            response.data = {
                "status": 405,
                "message": "Invalid API call",
                "data": []  # Keep data as an empty array
            }
        # Handle other errors (like ValidationError) as usual
        else:
            response.data = {
                "status": response.status_code,
                "message": "Error occurred",  # Generic error message
                "data": []  # Keep data as an empty array
            }

    return response
