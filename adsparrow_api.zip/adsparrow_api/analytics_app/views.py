from django.shortcuts import render,redirect
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import FacebookAdAccount, FacebookCampaign, FacebookAdSet, FacebookAd, FacebookAdInsight ,CronJobLog, GoogleAnalyticsAccount, TrafficSourceMedium
from .serializers import AdLast7DaysSerializer, RegisterUserSerializer, LoginUserSerializer, FacebookAdAccountSerializer, GoogleAnalyticsAccountSerializer, TrafficSourceMediumSerializer, AnalyticsAnalysisSerializer
from .utils import standard_response, custom_exception_handler
from rest_framework.authtoken.models import Token  # Import Token model
from django.contrib.auth import logout
from django.urls import reverse
from rest_framework.permissions import IsAuthenticated
from rest_framework.permissions import AllowAny
from django.contrib.auth.models import User
from rest_framework.pagination import PageNumberPagination
from django.db.models import Q
from facebook_business.api import FacebookAdsApi
from facebook_business.adobjects.adaccount import AdAccount
from facebook_business.adobjects.adset import AdSet
from facebook_business.adobjects.ad import Ad
from facebook_business.adobjects.adsinsights import AdsInsights
from facebook_business.exceptions import FacebookRequestError
from django.db import IntegrityError
from rest_framework.authentication import TokenAuthentication
from datetime import datetime, timedelta
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required
from google.oauth2 import service_account
from google.analytics.data_v1beta import BetaAnalyticsDataClient
from google.analytics.data_v1beta.types import RunReportRequest, DateRange, Metric, Dimension
from google.auth.exceptions import GoogleAuthError
from google.api_core.exceptions import PermissionDenied
from django.db.models import F, Subquery, Q, OuterRef 
from django.shortcuts import get_object_or_404
from django.http import JsonResponse
from django.utils import timezone
import requests
import json

#============ comman code ==============
#paginator
class StandardPagination(PageNumberPagination):
    page_size = 100  # Default page size
    page_size_query_param = 'page_size'  # Allow page_size to be passed as a query parameter
    max_page_size = 400  # Maximum allowed page size


#================ Authentiction user view ================

class ManageUserView(APIView):
    authentication_classes = [TokenAuthentication]
    permission_classes = [AllowAny]

    def post(self, request):
        # Authenticate and validate permissions
        user = request.user
        if not user.is_authenticated:
            return Response(
                standard_response(status_code=403, message="Authentication required", data=[]),
                status=status.HTTP_403_FORBIDDEN
            )

        if not (user.is_superuser and user.is_staff and user.is_active):
            return Response(
                standard_response(status_code=403, message="You do not have permission to add or update users.", data=[]),
                status=status.HTTP_403_FORBIDDEN
            )
        
         # Retrieve user_id from request data
        user_id = request.data.get('user_id', None)
        if user_id:
            # Retrieve the user by ID
            user_instance = get_object_or_404(User, id=user_id)

            # Update `is_active` and `is_premium` statuses if provided
            is_active = request.data.get('is_active')
            is_premium = request.data.get('is_premium')

            if is_active is not None:
                user_instance.is_active = bool(is_active)

            if is_premium is not None:
                profile = user_instance.profile
                profile.is_premium = bool(is_premium)
                profile.save()

            user_instance.save()

            return Response(
                standard_response(status_code=200, message="User status updated successfully!", data={
                    "user_id": user_instance.id,
                    "is_active": user_instance.is_active,
                    "is_premium": user_instance.profile.is_premium
                }),
                status=status.HTTP_200_OK
            )

         # Manually check if the email already exists
        email = request.data.get('email', None)
        if email and User.objects.filter(email=email).exists():
            return Response(
                standard_response(status_code=400, message="A user with this email already exists.", data=[]),
                status=status.HTTP_400_BAD_REQUEST
            )

        # Check if the request is for updating an existing user
        user_id = request.data.get('user_id', None)
        if user_id:
            try:
                # Retrieve the user by ID
                user_instance = User.objects.get(id=user_id)
            except User.DoesNotExist:
                return Response(
                    standard_response(status_code=404, message="User not found.", data=[]),
                    status=status.HTTP_404_NOT_FOUND
                )

            # Ensure password is provided for updates
            if 'password' not in request.data or not request.data['password']:
                return Response(
                    standard_response(status_code=400, message="Password is required when updating a user.", data=[]),
                    status=status.HTTP_400_BAD_REQUEST
                )

            # Proceed with updating the user
            serializer = RegisterUserSerializer(instance=user_instance, data=request.data, partial=True)
            if serializer.is_valid():
                serializer.save()
                return Response(
                    standard_response(status_code=200, message="User updated successfully!", data=[]),
                    status=status.HTTP_200_OK
                )

            # Extract and customize error messages
            error_key = list(serializer.errors.keys())[0]  # Get the first field with an error
            error_message = serializer.errors[error_key][0]  # Get the first error message for that field
            return Response(
                standard_response(status_code=400, message=f"{error_message}", data=[]),
                status=status.HTTP_400_BAD_REQUEST
            )

        # Handle user creation if `user_id` is not provided
        serializer = RegisterUserSerializer(data=request.data)
        if serializer.is_valid():
            user, token = serializer.save()
            return Response(
                standard_response(status_code=201, message="User added successfully!", data={"user_id": user.id}),
                status=status.HTTP_201_CREATED
            )

        # Extract and customize error messages
        error_key = list(serializer.errors.keys())[0]  # Get the first field with an error
        error_message = serializer.errors[error_key][0]  # Get the first error message for that field
        return Response(
            standard_response(status_code=400, message=f"{error_message}", data=[]),
            status=status.HTTP_400_BAD_REQUEST
        )
    

    def get(self, request):
        # Authenticate and validate permissions
        user = request.user
        if not user.is_authenticated:
            return Response(
                standard_response(status_code=403, message="Authentication required", data=[]),
                status=status.HTTP_403_FORBIDDEN
            )

        # Ensure only superuser can access this API
        if not user.is_superuser:
            return Response(
                standard_response(status_code=403, message="You do not have permission to view users.", data=[]),
                status=status.HTTP_403_FORBIDDEN
            )

        # Get the search term from query parameters (if provided)
        search_term = request.query_params.get('search', '').strip()

        # Ensure the search term is at least 3 characters long
        if search_term and len(search_term) >= 3:
            # Apply search filters using Q objects to search in 'username' and 'email' fields
            users = User.objects.filter(
                Q(username__icontains=search_term) | Q(email__icontains=search_term),
                is_superuser=False,  # Exclude superusers
                is_staff=True,        # Only staff users
                is_active=True        # Only active users
            )
        else:
            # No search term provided or it's too short, return all active and staff users
            users = User.objects.filter(is_superuser=False, is_staff=True, is_active=True)

        # Set pagination
        paginator = StandardPagination()
        paginated_users = paginator.paginate_queryset(users, request)

        # Prepare user data for response
        user_data = []
        for u in paginated_users:
            profile = getattr(u, 'profile', None)  # Safely get the related profile
            user_data.append({
                "user_id": u.id,
                "username": u.username,
                "email": u.email,
                "first_name": u.first_name,
                "is_active": u.is_active,
                "is_premium": profile.is_premium if profile else False,
                "created_at": u.date_joined.strftime('%Y-%m-%d %H:%M:%S') if u.date_joined else None
            })

        # Return paginated response
        return paginator.get_paginated_response(
            standard_response(status_code=200, message="Users fetched successfully.", data=user_data)
        )


class LoginUserView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = LoginUserSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.validated_data['user']

            if not user.is_active:
                return Response(
                    standard_response(
                        status_code=403,
                        message="User is inactive"
                    ),
                    status=status.HTTP_403_FORBIDDEN
                )

            # Generate or get the token
            token = Token.objects.get_or_create(user=user)[0].key

            # Prepare the response data with user_type and token
            user_type = "User"
            if user.is_superuser and user.is_staff:
                user_type = "Master Admin"
            elif user.is_staff:
                user_type = "Admin"

            return Response(
                standard_response(
                    status_code=200,
                    message=f"Welcome to {user_type} Dashboard!",
                    data={
                        "user_type": user_type,  # Add user_type to the response
                        "token": token           # Include token in the response
                    }
                ),
                status=status.HTTP_200_OK
            )

        # Flatten error messages into a single message string
        error_messages = list(serializer.errors.values())
        error_message = " ".join([item[0] for item in error_messages])

        return Response(
            standard_response(
                status_code=400,
                message=error_message,
            ),
            status=status.HTTP_400_BAD_REQUEST
        )


class LogoutUserView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        # Clear the session (if using session-based authentication for other purposes)
        request.session.flush()

        # Return standard response with a success message
        return Response(
            standard_response(
                status_code=status.HTTP_200_OK,
                message="Logout successful, please discard your token"
            ),
            status=status.HTTP_200_OK
        )



#================ Dashboard view ================


class DashboardView(APIView):
    permission_classes = [IsAuthenticated]  # Only authenticated users can access this view

    def get(self, request):
        user = request.user  # Get the authenticated user
        first_name = user.first_name

        # Get search parameters from query string
        fb_search_query = request.GET.get('fb_search', '')
        google_search_query = request.GET.get('google_search', '')
        
        # Minimum length condition for the search query (3 characters)
        if len(fb_search_query) < 3:
            fb_search_query = ''
        if len(google_search_query) < 3:
            google_search_query = ''

        # Handle pagination
        fb_page_size = request.GET.get('fb_page_size', 10)  # Default 10 for Facebook accounts
        google_page_size = request.GET.get('google_page_size', 10)  # Default 10 for Google accounts

        # Check if the user is a Master Admin (Superuser, Staff, Active)
        # Check if the user is a Master Admin (Superuser, Staff, Active)
        if user.is_superuser and user.is_staff and user.is_active:
            user_type = "Master Admin"
            message = f"Welcome {user_type} {first_name}!"

            # Count total number of staff users who are active, default to 0 if no users
            total_staff_active_users = User.objects.filter(is_staff=True, is_active=True).count() or 0

            # Count total number of Facebook Ad Accounts (all users), default to 0 if no accounts
            total_fb_ad_accounts = FacebookAdAccount.objects.all().count() or 0

            # Count total number of Google Accounts (all users), default to 0 if no accounts
            total_google_accounts = GoogleAnalyticsAccount.objects.all().count() or 0

            # Handle search for Facebook Ad Accounts (if query length >= 3)
            if fb_search_query:
                total_fb_ad_accounts = FacebookAdAccount.objects.filter(
                    fb_ad_account_name__icontains=fb_search_query
                ).count() or 0

            # Handle search for Google Accounts (if query length >= 3)
            if google_search_query:
                total_google_accounts = GoogleAnalyticsAccount.objects.filter(
                    Google_account_name__icontains=google_search_query
                ).count() or 0

            data = {
                "total_users": total_staff_active_users,
                "total_fb_ad_accounts": total_fb_ad_accounts,
                "total_google_accounts": total_google_accounts,
            }


            return Response({"status": 200, "message": message, "data": data})

        # For regular staff users (Active)
        elif user.is_staff and user.is_active:
            user_type = "Admin"
            message = f"Welcome {user_type} {first_name}!"

            # Count total number of Facebook Ad Accounts associated with this user
            total_fb_ad_accounts = FacebookAdAccount.objects.filter(user=user).count() or 0

            # Count total number of Google Accounts associated with this user
            total_google_accounts = GoogleAnalyticsAccount.objects.filter(user=user).count() or 0

            # Handle separate search for Facebook Ad Accounts (if query length >= 3)
            if fb_search_query:
                total_fb_ad_accounts = FacebookAdAccount.objects.filter(
                    user=user,
                    fb_ad_account_name__icontains=fb_search_query
                ).count() or 0

            # Handle separate search for Google Accounts (if query length >= 3)
            if google_search_query:
                total_google_accounts = GoogleAnalyticsAccount.objects.filter(
                    user=user,
                    Google_account_name__icontains=google_search_query
                ).count() or 0

            # Fetch detailed Facebook Ad Account data for this user
            fb_ad_accounts_data = FacebookAdAccount.objects.filter(user=user).values(
                'fb_ad_account_name',
                'fb_ad_account_status'
            ).annotate(
                cron_updated_at=Subquery(
                    CronJobLog.objects.filter(fb_ad_account=OuterRef('id'))
                    .order_by('-updated_at')
                    .values('updated_at')[:1]
                )
            )

            # Fetch detailed Google Analytics Account data for this user
            google_accounts_data = GoogleAnalyticsAccount.objects.filter(user=user).values(
                'property_id', 
                'Google_account_name', 
                'google_account_status'
            ).annotate(
                cron_updated_at=Subquery(
                    CronJobLog.objects.filter(google_account=OuterRef('id'))
                    .order_by('-updated_at')
                    .values('updated_at')[:1]
                )
            )

            # Apply search filter to account data (only if the query is >= 3 characters)
            if fb_search_query:
                fb_ad_accounts_data = fb_ad_accounts_data.filter(
                    fb_ad_account_name__icontains=fb_search_query
                )
            if google_search_query:
                google_accounts_data = google_accounts_data.filter(
                    Google_account_name__icontains=google_search_query
                )

            # Apply pagination
            fb_paginator = StandardPagination()
            paginated_fb_accounts_data = fb_paginator.paginate_queryset(fb_ad_accounts_data, request)

            google_paginator = StandardPagination()
            paginated_google_accounts_data = google_paginator.paginate_queryset(google_accounts_data, request)

            data = {
                "total_fb_ad_accounts": total_fb_ad_accounts,
                "total_google_accounts": total_google_accounts,
                "fb_ad_accounts_data": fb_paginator.get_paginated_response(paginated_fb_accounts_data).data,
                "google_accounts_data": google_paginator.get_paginated_response(paginated_google_accounts_data).data,
            }

            return Response({"status": 200, "message": message, "data": data})

        else:
            return Response(
                {"status": 403, "message": "You do not have access to this dashboard."},
                status=403
            )


#============================= Fb ad acccount view ==========================

#============= Add,Update, display ===========
class FacebookAdAccountView(APIView):
    permission_classes = [IsAuthenticated]  # Ensure only authenticated users can access

    def post(self, request, pk=None):
        """
        Handles both creating a new Facebook Ad Account and updating an existing one.
        Provides validation for blank fields and appropriate error messages.
        """
        data = request.data.copy()
        data['user'] = request.user.id  # Add the user's ID to the data

        # Modify fb_ad_account_id by prepending 'act_' to the user-provided value
        fb_ad_account_id = data.get('fb_ad_account_id')
        if fb_ad_account_id:
            # data['fb_ad_account_id'] = f"act_{fb_ad_account_id}"  # Prepend 'act_' to fb_ad_account_id
            data['fb_ad_account_id'] = f"{fb_ad_account_id}"  # Prepend 'act_' to fb_ad_account_id

            # Check if the `fb_ad_account_id` already exists for another user
            existing_account = FacebookAdAccount.objects.filter(fb_ad_account_id=data['fb_ad_account_id']).exclude(user=request.user).first()
            if existing_account:
                return Response(
                    standard_response(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        message="Account already exists with this Facebook Ad Account ID for another user.",
                        data=[]
                    ),
                    status=status.HTTP_400_BAD_REQUEST
                )

        # Check if this is an update operation
        if pk:
            try:
                # Ensure the authenticated user is updating their own ad account
                fb_ad_account = FacebookAdAccount.objects.get(pk=pk, user=request.user)
            except FacebookAdAccount.DoesNotExist:
                return Response(
                    standard_response(
                        status_code=status.HTTP_404_NOT_FOUND,
                        message="Facebook Ad Account not found or does not belong to you.",
                        data=[]
                    ),
                    status=status.HTTP_404_NOT_FOUND
                )

            # Include is_active and is_visible for updates
            is_active = data.get('is_active', fb_ad_account.is_active)  # Default to current value if not provided
            is_visible = data.get('is_visible', fb_ad_account.is_visible)  # Default to current value if not provided

            # Add these fields to the data being updated
            data['is_active'] = is_active
            data['is_visible'] = is_visible

            # Partial update (allows updating specific fields)
            serializer = FacebookAdAccountSerializer(fb_ad_account, data=data, partial=True)
        else:
            # Create a new record
            serializer = FacebookAdAccountSerializer(data=data)

        # Validate the serializer
        if serializer.is_valid():
            serializer.save(user=request.user)
            message = (
                "Facebook Ad Account updated successfully!" if pk 
                else "Facebook Ad Account added successfully!"
            )
            return Response(
                standard_response(
                    status_code=status.HTTP_200_OK if pk else status.HTTP_201_CREATED,
                    message=message,
                    data=[]
                ),
                status=status.HTTP_200_OK if pk else status.HTTP_201_CREATED
            )

        # Handle validation errors
        errors = serializer.errors

        # Handle the case where fb_ad_account_id already exists
        if 'fb_ad_account_id' in errors:
            # Check if the error is related to the duplicate Facebook Ad Account ID
            if any("already exists" in error for error in errors['fb_ad_account_id']):
                return Response(
                    standard_response(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        message=errors['fb_ad_account_id'][0],  # Use the exact error message
                        data=[]
                    ),
                    status=status.HTTP_400_BAD_REQUEST
                )

        # Custom error handling for blank fields
        blank_fields = [field for field in errors if any("This field may not be blank." in error for error in errors[field])]
        missing_fields = [field for field in errors if any("This field is required." in error for error in errors[field])]

        if blank_fields:
            # If one or more fields are blank, provide a specific error message
            if len(blank_fields) > 1:
                message = "Too many fields cannot be blank."
            else:
                message = f"{', '.join([field.replace('_', ' ').capitalize() + ' cannot be blank' for field in blank_fields])}."
            return Response(
                standard_response(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    message=message,
                    data=[]
                ),
                status=status.HTTP_400_BAD_REQUEST
            )

        # If no fields are blank, check for required fields missing
        if missing_fields:
            if len(missing_fields) > 1:
                message = "Too many fields are required."
            else:
                message = f"{', '.join([field.replace('_', ' ').capitalize() + ' is required' for field in missing_fields])}."
            return Response(
                standard_response(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    message=message,
                    data=[]
                ),
                status=status.HTTP_400_BAD_REQUEST
            )

        return Response(
            standard_response(
                status_code=status.HTTP_400_BAD_REQUEST,
                message="Validation error occurred.",
                data=errors
            ),
            status=status.HTTP_400_BAD_REQUEST
        )

    def get(self, request, *args, **kwargs):
        """
        Fetches the list of Facebook Ad Accounts for the authenticated user, with pagination and search functionality.
        """
        # Get the search query from the request, default to an empty string if not provided
        search_query = request.query_params.get('search', '').strip()

        # Fetch the Facebook Ad Accounts for the authenticated user
        fb_ad_accounts = FacebookAdAccount.objects.filter(user=request.user)

        # If search query has 3 or more characters, filter the Facebook Ad Accounts based on the query
        if len(search_query) >= 3:
            fb_ad_accounts = fb_ad_accounts.filter(
                Q(fb_ad_account_id__icontains=search_query) |  # Search by `fb_ad_account_id`
                Q(fb_ad_account_name__icontains=search_query) |  # Replace `some_other_field` with any other field you want to search
                Q(fb_ad_app_id__icontains=search_query) |  # Replace `some_other_field` with any other field you want to search
                Q(fb_ad_account_status__icontains=search_query)   # Replace `some_other_field` with any other field you want to search
            )

        # If no records found after filtering, return a message indicating no matches
        if not fb_ad_accounts.exists():
            return Response(
                standard_response(
                    status_code=status.HTTP_404_NOT_FOUND,
                    message="No Recored Found.",
                    data=[]
                ),
                status=status.HTTP_404_NOT_FOUND
            )

        # Apply pagination
        paginator = StandardPagination()
        paginated_result = paginator.paginate_queryset(fb_ad_accounts, request)

        # Serialize the data
        serializer = FacebookAdAccountSerializer(paginated_result, many=True)

        # Return the paginated response
        return paginator.get_paginated_response(serializer.data)

#========fetch last 2 days data=========

class FacebookAdDataView(APIView):
    """
    API view to handle fetching Facebook ad data and updating FacebookAdAccount status.
    """
    permission_classes = [IsAuthenticated]

    def fetch_facebook_insights(self, ad_account_id, access_token, app_id, app_secret, user=None):
        # Initialize the Facebook API
        FacebookAdsApi.init(app_id, app_secret, access_token)

        # Get today's date
        end_date = datetime.now().date()

        # Prepare an empty list to hold all insights data
        insights_data = []

        # Define the fields you want to fetch
        insights_fields = [
            AdsInsights.Field.ad_id,
            AdsInsights.Field.ad_name,
            AdsInsights.Field.adset_id,
            AdsInsights.Field.adset_name,
            AdsInsights.Field.campaign_id,
            AdsInsights.Field.campaign_name,
            AdsInsights.Field.impressions,
            AdsInsights.Field.clicks,
            AdsInsights.Field.spend,
            AdsInsights.Field.reach,
            AdsInsights.Field.cpc,
            AdsInsights.Field.date_start,
            AdsInsights.Field.date_stop,
            AdsInsights.Field.actions,
            AdsInsights.Field.cost_per_action_type,
        ]

        # Initialize the cron log status
        cron_log = CronJobLog.objects.create(
            user=user,
            fb_ad_account=FacebookAdAccount.objects.get(fb_ad_account_id=ad_account_id),
            status='Review_pending',  # Initial status is 'Review_pending'
            message='Fetching Facebook insights',
        )

        # Update FacebookAdAccount status to 'Review_pending' while fetching insights
        fb_account = FacebookAdAccount.objects.get(fb_ad_account_id=ad_account_id)
        fb_account.fb_ad_account_status = FacebookAdAccount.REVIEW_PENDING  # Assuming 'REVIEW_PENDING' is a constant in your model
        fb_account.save()

        # Update cron log status to 'Fetching insights'
        cron_log.status = 'Fetching insights'
        cron_log.save()

        # Loop over the last 3 days and fetch insights for each day
        for day_offset in range(1, 3):  # 1 for yesterday
            start_date = end_date - timedelta(days=day_offset)  # Calculate the start date for each day
            current_start_date_str = start_date.strftime('%Y-%m-%d')
            current_end_date_str = current_start_date_str  # Same date for each day

            params = {
                'time_range': {'since': current_start_date_str, 'until': current_end_date_str},
                'level': 'ad',
                'time_increment': 1,
            }

            try:
                # Ensure that the FacebookAdAccount exists
                fb_account = FacebookAdAccount.objects.get(fb_ad_account_id=ad_account_id)

                # Get the ad insights for the current day
                account = AdAccount(f'act_{ad_account_id}')
                insights = account.get_insights(fields=insights_fields, params=params)

                # Loop over each insight and store the details in a dictionary
                for insight in insights:
                    ad_id = insight.get('ad_id', 'N/A')
                    ad_name = insight.get('ad_name', 'N/A')
                    adset_id = insight.get('adset_id', 'N/A')
                    adset_name = insight.get('adset_name', 'N/A')
                    campaign_id = insight.get('campaign_id', 'N/A')
                    campaign_name = insight.get('campaign_name', 'N/A')
                    impressions = int(insight.get('impressions', '0'))
                    clicks = int(insight.get('clicks', '0'))
                    spend = float(insight.get('spend', '0'))
                    reach = int(insight.get('reach', '0'))
                    cpc = float(insight.get('cpc', '0'))
                    date_start = insight.get('date_start', 'N/A')
                    date_stop = insight.get('date_stop', 'N/A')

                    # Get the daily budget for the ad set and format it as a float (e.g., 100.00 instead of 10000)
                    daily_budget = 'N/A'
                    if adset_id != 'N/A':
                        adset = AdSet(adset_id)
                        adset_details = adset.api_get(fields=['daily_budget'])
                        daily_budget = adset_details.get('daily_budget', 'N/A')
                        if daily_budget != 'N/A':
                            daily_budget = float(daily_budget) / 100  # Convert from cents to dollars

                    # Get the ad status
                    ad_status = 'N/A'
                    if ad_id != 'N/A':
                        ad = Ad(ad_id)
                        ad_details = ad.api_get(fields=['status'])
                        ad_status = ad_details.get('status', 'N/A')

                    actions = insight.get('actions', [])
                    cost_per_link_click = 0
                    for action in actions:
                        if action.get('action_type') == 'link_click':
                            cost_per_link_click = float(action.get('value', 0))

                    cost_per_action_type = insight.get('cost_per_action_type', [])
                    cost_per_result = 0
                    for action_cost in cost_per_action_type:
                        if action_cost.get('action_type') == 'link_click':
                            cost_per_result = float(action_cost.get('value', 0))

                    # Create a dictionary with the current insight data (including daily_budget and ad_status)
                    ad_insight = {
                        "ad_id": ad_id,
                        "ad_name": ad_name,
                        "adset_id": adset_id,
                        "adset_name": adset_name,
                        "campaign_id": campaign_id,
                        "campaign_name": campaign_name,
                        "daily_budget": f"{daily_budget:.2f}",  # Format daily budget with 2 decimal places
                        "ad_status": ad_status,
                        "impressions": impressions,
                        "clicks": clicks,
                        "spend": spend,
                        "reach": reach,
                        "cpc": cpc,
                        "cost_per_link_click": cost_per_link_click,
                        "cost_per_result": cost_per_result,
                        "date_start": date_start,
                        "date_stop": date_stop
                    }

                    # Create or update records in the database
                    campaign, created = FacebookCampaign.objects.update_or_create(
                        fb_ad_account=fb_account,
                        campaign_id=campaign_id,
                        defaults={'campaign_name': campaign_name}
                    )

                    adset, created = FacebookAdSet.objects.update_or_create(
                        fb_campaign=campaign,
                        adset_id=adset_id,
                        defaults={'adset_name': adset_name, 'daily_budget': daily_budget}
                    )

                    ad, created = FacebookAd.objects.update_or_create(
                        fb_ad_set=adset,
                        ad_id=ad_id,
                        defaults={'ad_name': ad_name, 'status': ad_status}
                    )

                    # Store the insights data in the database
                    ad_insight, created = FacebookAdInsight.objects.update_or_create(
                        fb_ad=ad,
                        date=date_start,
                        defaults={
                            'impressions': impressions,
                            'clicks': clicks,
                            'spend': spend,
                            'reach': reach,
                            'cost_per_link_click': cost_per_link_click,
                            'cost_per_result': cost_per_result,
                        }
                    )

                # Update the cron log status after successfully fetching the insights for a day
                cron_log.status = f"Insights fetched for {current_start_date_str}"
                cron_log.save()

            except FacebookRequestError as e:
                # Update the cron job log in case of failure
                cron_log.status = 'failed'
                cron_log.message = f"Error fetching insights for {current_start_date_str}: {e}"
                cron_log.save()

                # Update the FacebookAdAccount status to 'Failed'
                fb_account.fb_ad_account_status = FacebookAdAccount.FAILED  # Assuming 'FAILED' is a constant in your model
                fb_account.save()

                print(f"Error fetching insights for {current_start_date_str}: {e}")
                continue

        # Update the cron job log with success status
        cron_log.status = 'success'
        cron_log.message = 'Successfully fetched Facebook insights'
        cron_log.save()

        # Update the FacebookAdAccount status to 'Success'
        fb_account.fb_ad_account_status = FacebookAdAccount.SUCCESS  # Assuming 'SUCCESS' is a constant in your model
        fb_account.save()

        return {"status": 200, "message": "Successfully fetched Facebook insights", "data": insights_data}

    def get(self, request, ad_account_id):
        # Fetch the Facebook Ad account based on the ad_account_id
        try:
            fb_account = FacebookAdAccount.objects.get(fb_ad_account_id=ad_account_id)

            # Check if the FacebookAdAccount belongs to the authenticated user
            if fb_account.user != request.user:
                return Response(
                    {"status": 403, "message": "You do not have permission to access this ad account"},
                    status=status.HTTP_403_FORBIDDEN
                )

            access_token = fb_account.fb_ad_access_token
            app_id = fb_account.fb_ad_app_id
            app_secret = fb_account.fb_ad_app_secret_key

            # Print the fb_ad_account_id and account_name
            print(f"Facebook Ad Account ID: {fb_account.fb_ad_account_id}")
            print(f"Account Name: {fb_account.fb_ad_account_name}")
            
            # Print the authenticated user's username
            if request.user.is_authenticated:
                print(f"Authenticated User: {request.user.username}")
            else:
                print("User not authenticated")

        except FacebookAdAccount.DoesNotExist:
            return Response(
                {"status": 404, "message": 'Ad account not found'},
                status=status.HTTP_404_NOT_FOUND
            )

        # Fetch the user for the cron job log
        user = request.user if request.user.is_authenticated else None

        # Fetch the ad insights using the helper function and save logs
        insights_data = self.fetch_facebook_insights(ad_account_id, access_token, app_id, app_secret, user=user)

        # Return the data as JSON with the formatted response
        return Response(insights_data, status=status.HTTP_200_OK)


#====================== Google Analytics Views ============================

#==== Google Analytics Accounts Add,update,view =======

class GoogleAnalyticsAccountView(APIView):
    permission_classes = [IsAuthenticated]  # Ensure only authenticated users can access

    def post(self, request, pk=None):
        """
        Handles both creating a new Google Analytics Account and updating an existing one.
        Provides validation for blank fields and appropriate error messages.
        """
        data = request.data.copy()
        data['user'] = request.user.id  # Add the user's ID to the data

         # Set default values for is_visible and is_active if not provided
        if 'is_visible' not in data:
            data['is_visible'] = True
        if 'is_active' not in data:
            data['is_active'] = True

        # Check if `property_id` and `json_key` are present and not blank
        property_id = data.get('property_id')
        json_key = data.get('json_key')

        # Ensure property_id is present and is a number
        if not property_id:
            return Response(
                standard_response(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    message="Property ID cannot be blank.",
                    data=[]
                ),
                status=status.HTTP_400_BAD_REQUEST
            )

        if not property_id.isdigit():
            return Response(
                standard_response(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    message="Property ID must be a number.",
                    data=[]
                ),
                status=status.HTTP_400_BAD_REQUEST
            )

        # Ensure `json_key` is present and not blank
        if not json_key:
            return Response(
                standard_response(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    message="JSON key cannot be blank.",
                    data=[]
                ),
                status=status.HTTP_400_BAD_REQUEST
            )

        # Ensure the uploaded file is in JSON format
        if json_key and not json_key.name.endswith('.json'):
            return Response(
                standard_response(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    message="The uploaded file must be in .json format.",
                    data=[]
                ),
                status=status.HTTP_400_BAD_REQUEST
            )

        # Check if this is an update operation
        if pk:
            try:
                # Ensure the authenticated user is updating their own account
                google_analytics_account = GoogleAnalyticsAccount.objects.get(pk=pk, user=request.user)
            except GoogleAnalyticsAccount.DoesNotExist:
                return Response(
                    standard_response(
                        status_code=status.HTTP_404_NOT_FOUND,
                        message="Google Analytics Account not found or does not belong to you.",
                        data=[]
                    ),
                    status=status.HTTP_404_NOT_FOUND
                )

             # Update the is_active and is_visible fields
            data['is_active'] = data.get('is_active', google_analytics_account.is_active)
            data['is_visible'] = data.get('is_visible', google_analytics_account.is_visible)


            # Partial update (allows updating specific fields)
            serializer = GoogleAnalyticsAccountSerializer(google_analytics_account, data=data, partial=True)
        else:
            # Check if the property_id already exists in the database for the user
            if GoogleAnalyticsAccount.objects.filter(property_id=property_id, user=request.user).exists():
                return Response(
                    standard_response(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        message="Google Analytics account with this property ID already exists.",
                        data=[]
                    ),
                    status=status.HTTP_400_BAD_REQUEST
                )

            # Create a new record
            serializer = GoogleAnalyticsAccountSerializer(data=data)

        # Validate the serializer
        if serializer.is_valid():
            try:
                serializer.save(user=request.user)
                message = (
                    "Google Analytics Account updated successfully!" if pk 
                    else "Google Analytics Account added successfully!"
                )
                return Response(
                    standard_response(
                        status_code=status.HTTP_200_OK if pk else status.HTTP_201_CREATED,
                        message=message,
                        data=[]
                    ),
                    status=status.HTTP_200_OK if pk else status.HTTP_201_CREATED
                )
            except IntegrityError as e:
                return Response(
                    standard_response(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        message="An integrity error occurred. Please check your input.",
                        data=[str(e)]
                    ),
                    status=status.HTTP_400_BAD_REQUEST
                )

        # Handle validation errors
        errors = serializer.errors

        # Custom error handling for blank fields
        blank_fields = [field for field in errors if any("This field may not be blank." in error for error in errors[field])]
        missing_fields = [field for field in errors if any("This field is required." in error for error in errors[field])]

        if blank_fields:
            # If one or more fields are blank, provide a specific error message
            if len(blank_fields) > 1:
                message = "Too many fields cannot be blank."
            else:
                message = f"{', '.join([field.replace('_', ' ').capitalize() + ' cannot be blank' for field in blank_fields])}."
            return Response(
                standard_response(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    message=message,
                    data=[]
                ),
                status=status.HTTP_400_BAD_REQUEST
            )

        # If no fields are blank, check for required fields missing
        if missing_fields:
            if len(missing_fields) > 1:
                message = "Too many fields are required."
            else:
                message = f"{', '.join([field.replace('_', ' ').capitalize() + ' is required' for field in missing_fields])}."
            return Response(
                standard_response(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    message=message,
                    data=[]
                ),
                status=status.HTTP_400_BAD_REQUEST
            )

        return Response(
            standard_response(
                status_code=status.HTTP_400_BAD_REQUEST,
                message="Validation error occurred.",
                data=errors
            ),
            status=status.HTTP_400_BAD_REQUEST
        )  
    

    def get(self, request, *args, **kwargs):
        """
        Fetches the list of Google Analytics accounts for the authenticated user, with pagination and search.
        """
        search_query = request.query_params.get('search', '').strip()

        # Fetch Google Analytics accounts for the authenticated user
        ga_accounts = GoogleAnalyticsAccount.objects.filter(user=request.user)

        # Apply search filter
        if len(search_query) >= 3:
            ga_accounts = ga_accounts.filter(
                Q(property_id__icontains=search_query) |
                Q(Google_account_name__icontains=search_query) |
                Q(google_account_status__icontains=search_query)
            )

        # Handle no records found
        if not ga_accounts.exists():
            return Response(
                standard_response(
                    status_code=status.HTTP_404_NOT_FOUND,
                    message="No records found.",
                    data=[]
                ),
                status=status.HTTP_404_NOT_FOUND
            )

        # Paginate results
        paginator = StandardPagination()
        paginated_result = paginator.paginate_queryset(ga_accounts, request)

        # Serialize data
        serializer = GoogleAnalyticsAccountSerializer(paginated_result, many=True)

        return paginator.get_paginated_response(serializer.data)


#========= Fetch Google Analytics Data =======

# Function to get GA4 report data
def get_ga4_report(json_key_path, property_id, start_date, end_date):
    # Authenticate using service account credentials
    credentials = service_account.Credentials.from_service_account_file(json_key_path)
    client = BetaAnalyticsDataClient(credentials=credentials)

    # Create the request to retrieve traffic data
    request = RunReportRequest(
        property=f"properties/{property_id}",
        date_ranges=[DateRange(start_date=start_date, end_date=end_date)],
        metrics=[
            Metric(name="sessions"),
            Metric(name="activeUsers"),
            Metric(name="totalRevenue")
        ],
        dimensions=[
            Dimension(name="sessionSource"),
            Dimension(name="sessionMedium")
        ]
    )

    # Run the report and return the response
    response = client.run_report(request=request)
    return response


class GoogleAnalyticsSyncView(APIView):
    permission_classes = [IsAuthenticated]

    @method_decorator(login_required)
    def post(self, request, account_id):
        # Fetch the Google Analytics Account using the account_id from the URL
        try:
            google_account = GoogleAnalyticsAccount.objects.get(id=account_id, user=request.user)
            json_key_path = google_account.json_key.path
            property_id = google_account.property_id
            today = datetime.now().date()

            # Fetch data for the last 3 full days and today
            for i in range(4):
                day = today - timedelta(days=i)
                start_date = day.strftime('%Y-%m-%d')
                end_date = day.strftime('%Y-%m-%d')

                # Fetch GA4 report for each day
                response = get_ga4_report(json_key_path, property_id, start_date, end_date)

                for row in response.rows:
                    source = row.dimension_values[0].value
                    medium = row.dimension_values[1].value
                    sessions = int(row.metric_values[0].value)
                    active_users = int(row.metric_values[1].value)
                    daily_revenue = float(row.metric_values[2].value)

                    # Check if data exists for the same source, medium, and date
                    traffic_source, created = TrafficSourceMedium.objects.get_or_create(
                        Google_account=google_account,
                        source=source,
                        medium=medium,
                        date=start_date,
                        defaults={
                            'daily_revenue': daily_revenue,
                            'sessions': sessions,
                            'active_users': active_users
                        }
                    )

                    if not created:
                        traffic_source.sessions = sessions
                        traffic_source.active_users = active_users
                        traffic_source.daily_revenue = daily_revenue
                        traffic_source.save()

            google_account.google_account_status = 'success'
            google_account.save()

            # Use the standard response format
            return Response(standard_response(status_code=200, message="Google Analytics account updated and traffic data synced successfully!"))

        except GoogleAnalyticsAccount.DoesNotExist:
            return Response(standard_response(status_code=404, message="Google Analytics account not found!"))

        except PermissionDenied as e:
            # Handle Google Analytics API error: insufficient permissions
            error_message = "Insufficient permissions for this property."
            return Response(standard_response(status_code=403, message=error_message))

        except GoogleAuthError as e:
            # Handle Google Authentication error
            error_message = "Google authentication error: Invalid credentials or service account."
            return Response(standard_response(status_code=400, message=error_message))

        except Exception as e:
            if google_account:
                google_account.google_account_status = 'failed'
                google_account.save()
            return Response(standard_response(status_code=400, message="An error occurred: " + str(e)))




#=================== Analytics Analysis ===============

#======= 13-12-24 compate formate1 ====
# from rest_framework.views import APIView
# from rest_framework.response import Response
# from rest_framework import status
# from .models import FacebookAdInsight, TrafficSourceMedium
# from .serializers import AnalyticsAnalysisSerializer

# class AnalyticsAnalysis(APIView):
#     def get(self, request, *args, **kwargs):
#         # Retrieve the ad insights and traffic source mediums
#         ad_insights = FacebookAdInsight.objects.all()
#         traffic_sources = TrafficSourceMedium.objects.all()

#         # Prepare the list to store the result
#         results = []

#         # Iterate over all FacebookAdInsights
#         for ad_insight in ad_insights:
#             ad_name = ad_insight.fb_ad.ad_name.lower()  # Lowercase for comparison
#             date = ad_insight.date

#             # Check for matching TrafficSourceMedium (same date and matching medium with ad_name)
#             matching_sources = traffic_sources.filter(
#                 date=date,
#                 medium__iexact=ad_name.lower()  # Case insensitive match for medium and ad_name
#             )

#             if matching_sources.exists():
#                 # If a match is found, combine both data and return
#                 for source in matching_sources:
#                     result = {
#                         "ad_name": ad_name,
#                         "status": ad_insight.fb_ad.status,
#                         "spend": str(ad_insight.spend),
#                         "cost_per_link_click": str(ad_insight.cost_per_link_click),
#                         "daily_budget": str(ad_insight.fb_ad.fb_ad_set.daily_budget),
#                         "account_name": ad_insight.fb_ad.fb_ad_set.fb_campaign.fb_ad_account.fb_ad_account_name,
#                         "daily_revenue": str(source.daily_revenue),
#                         "date": str(date)
#                     }
#                     results.append(result)
#             else:
#                 # If no matching traffic source, just return the FacebookAdInsight data
#                 result = {
#                     "ad_name": ad_name,
#                     "status": ad_insight.fb_ad.status,
#                     "spend": str(ad_insight.spend),
#                     "cost_per_link_click": str(ad_insight.cost_per_link_click),
#                     "daily_budget": str(ad_insight.fb_ad.fb_ad_set.daily_budget),
#                     "account_name": ad_insight.fb_ad.fb_ad_set.fb_campaign.fb_ad_account.fb_ad_account_name,
#                     "date": str(date)
#                 }
#                 results.append(result)

#         # Iterate over all TrafficSourceMedium data that did not match
#         for source in traffic_sources:
#             date = source.date
#             medium = source.medium.lower()  # Lowercase for comparison

#             # Check if there's no matching FacebookAdInsight for this medium and date
#             matching_ads = ad_insights.filter(
#                 date=date,
#                 fb_ad__ad_name__iexact=medium  # Case insensitive match for ad_name and medium
#             )

#             if not matching_ads.exists():
#                 # If no matching ad insight, just return the traffic source medium data
#                 result = {
#                     "medium": medium,
#                     "daily_revenue": str(source.daily_revenue),
#                     "date": str(date)
#                 }
#                 results.append(result)

#         return Response(results, status=status.HTTP_200_OK)



#============= 13-12-24 compate formate2 ==============

#====== apply filter (18-12) =====

# class AnalyticsAnalysis(APIView):
#     permission_classes = [IsAuthenticated]

#     def get(self, request, *args, **kwargs):
#         # Get date range filter from query parameters
#         date_range = request.query_params.get('date_range', 'today')  # Default to 'today'
#         custom_start_date = request.query_params.get('start_date', None)
#         custom_end_date = request.query_params.get('end_date', None)

#         # Get today's date
#         today = timezone.now().date()

#         # Filter FacebookAdInsight by date range
#         if date_range == 'today':
#             insights = FacebookAdInsight.objects.filter(date=today)
#         elif date_range == 'yesterday':
#             yesterday = today - timedelta(days=1)
#             insights = FacebookAdInsight.objects.filter(date=yesterday)
#         elif date_range == 'last7days':
#             last_7_days = today - timedelta(days=7)
#             insights = FacebookAdInsight.objects.filter(date__gte=last_7_days)
#         elif date_range == 'last30days':
#             last_30_days = today - timedelta(days=30)
#             insights = FacebookAdInsight.objects.filter(date__gte=last_30_days)
#         elif date_range == 'custom' and custom_start_date and custom_end_date:
#             insights = FacebookAdInsight.objects.filter(
#                 date__gte=custom_start_date,
#                 date__lte=custom_end_date
#             )
#         else:
#             insights = FacebookAdInsight.objects.all()

#         # Filter TrafficSourceMedium by date range
#         if date_range == 'today':
#             traffic_data = TrafficSourceMedium.objects.filter(date=today)
#         elif date_range == 'yesterday':
#             yesterday = today - timedelta(days=1)
#             traffic_data = TrafficSourceMedium.objects.filter(date=yesterday)
#         elif date_range == 'last7days':
#             last_7_days = today - timedelta(days=7)
#             traffic_data = TrafficSourceMedium.objects.filter(date__gte=last_7_days)
#         elif date_range == 'last30days':
#             last_30_days = today - timedelta(days=30)
#             traffic_data = TrafficSourceMedium.objects.filter(date__gte=last_30_days)
#         elif date_range == 'custom' and custom_start_date and custom_end_date:
#             traffic_data = TrafficSourceMedium.objects.filter(
#                 date__gte=custom_start_date,
#                 date__lte=custom_end_date
#             )
#         else:
#             traffic_data = TrafficSourceMedium.objects.all()

#         # Serialize the data
#         insights_serializer = AnalyticsAnalysisSerializer(insights, many=True)
#         traffic_serializer = TrafficSourceMediumSerializer(traffic_data, many=True)

#         # Combine insights and traffic data based on matching ad_name and medium
#         combined_data = []
#         for insight in insights_serializer.data:
#             matched = False
#             # Compare each TrafficSourceMedium data with the current FacebookAdInsight's ad_name
#             for traffic_item in traffic_serializer.data:
#                 # Convert both to lowercase for comparison
#                 if insight['ad_name'].lower() == traffic_item['medium'].lower():
#                     combined_item = insight.copy()
#                     combined_item['daily_revenue'] = traffic_item.get('daily_revenue', '-')
#                     combined_data.append(combined_item)
#                     matched = True
#                     break
#             if not matched:
#                 # If no match is found, append with "-" for daily_revenue
#                 insight['daily_revenue'] = '-'
#                 combined_data.append(insight)

#         # For any traffic data that did not match an insight, we append them with "-" for other fields
#         for traffic_item in traffic_serializer.data:
#             matched = False
#             for insight in insights_serializer.data:
#                 if insight['ad_name'].lower() == traffic_item['medium'].lower():
#                     matched = True
#                     break
#             if not matched:
#                 # Create a new entry with "-" for the unmatched fields
#                 combined_item = {
#                     'sr_no': '-',
#                     'ad_name': traffic_item['medium'],
#                     'impression': '-',
#                     'spend': '-',
#                     'cost_per_link_click': '-',
#                     'date': '-',
#                     'ad_status': '-',
#                     'daily_budget': '-',
#                     'daily_revenue': traffic_item.get('daily_revenue', '-')
#                 }
#                 combined_data.append(combined_item)

#         # Group by ad_name and merge data
#         grouped_data = {}
#         for item in combined_data:
#             ad_name = item['ad_name']
#             if ad_name not in grouped_data:
#                 grouped_data[ad_name] = {
#                     'ad_name': ad_name,
#                     'impression': 0,
#                     'spend': 0.0,
#                     'cost_per_link_click': item.get('cost_per_link_click', '-'),
#                     'ad_status': item.get('ad_status', '-'),
#                     'daily_budget': item.get('daily_budget', '-'),
#                     'daily_revenue': 0.0,
#                     'date_range': [],
#                     'sr_no': 0,
#                     'spend_with_gst': 0.0  # Adding a new field for spend with GST
#                 }

#             # Sum values
#             grouped_data[ad_name]['impression'] += item['impression'] if item['impression'] != '-' else 0
#             grouped_data[ad_name]['spend'] += float(item['spend']) if item['spend'] != '-' else 0
#             grouped_data[ad_name]['daily_revenue'] += float(item['daily_revenue']) if item['daily_revenue'] != '-' else 0

#             # Calculate spend with 18% GST
#             grouped_data[ad_name]['spend_with_gst'] = grouped_data[ad_name]['spend'] * 1.18

#             # Store date range
#             if item['date'] not in grouped_data[ad_name]['date_range']:
#                 grouped_data[ad_name]['date_range'].append(item['date'])

#         # Prepare the final output
#         final_data = []
#         for index, (ad_name, data) in enumerate(grouped_data.items(), start=1):
#             data['sr_no'] = index
#             data['date'] = ' to '.join(data['date_range']) if len(data['date_range']) > 1 else data['date_range'][0]
#             data['spend'] = f"{data['spend']:.2f}"
#             data['spend_with_gst'] = f"{data['spend_with_gst']:.2f}"  # Format spend_with_gst
#             data['daily_revenue'] = f"{data['daily_revenue']:.2f}" if data['daily_revenue'] != 0 else '-'

#             final_data.append(data)

#         # Return the combined data as response
#         return Response({
#             'data': final_data
#         })

#====== 26-12 updated =====

from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from django.utils import timezone
from datetime import timedelta
from .models import FacebookAdInsight, TrafficSourceMedium, FacebookAdAccount, GoogleAnalyticsAccount
from .serializers import AnalyticsAnalysisSerializer, TrafficSourceMediumSerializer
from rest_framework.views import APIView
from rest_framework.response import Response
from .utils import standard_response  # Import your standard_response function
from rest_framework.permissions import IsAuthenticated
from datetime import timedelta
from django.utils import timezone
from .models import FacebookAdInsight, TrafficSourceMedium, FacebookAdAccount, GoogleAnalyticsAccount
from .serializers import AnalyticsAnalysisSerializer, TrafficSourceMediumSerializer
from django.db.models.functions import Lower


class AnalyticsAnalysis(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, *args, **kwargs):
        # Get date range filter from query parameters
        date_range = request.query_params.get('date_range', 'today')  # Default to 'today'
        custom_start_date = request.query_params.get('start_date', None)
        custom_end_date = request.query_params.get('end_date', None)
        fb_ad_account_name = request.query_params.get('fb_ad_account_name', None)  # Get the fb_ad_account_name
        ad_status = request.query_params.get('ad_status', None)  # Get ad_status from query parameters
        
        # Get today's date
        today = timezone.now().date()

        # Filter FacebookAdInsight by date range
        if date_range == 'today':
            insights = FacebookAdInsight.objects.filter(date=today)
        elif date_range == 'yesterday':
            yesterday = today - timedelta(days=1)
            insights = FacebookAdInsight.objects.filter(date=yesterday)
        elif date_range == 'last7days':
            last_7_days = today - timedelta(days=7)
            insights = FacebookAdInsight.objects.filter(date__gte=last_7_days)
        elif date_range == 'last30days':
            last_30_days = today - timedelta(days=30)
            insights = FacebookAdInsight.objects.filter(date__gte=last_30_days)
        elif date_range == 'custom' and custom_start_date and custom_end_date:
            insights = FacebookAdInsight.objects.filter(
                date__gte=custom_start_date,
                date__lte=custom_end_date
            )
        else:
            insights = FacebookAdInsight.objects.all()

        # Apply ad_status filter if provided and at least 3 characters long
        if ad_status and len(ad_status) >= 3:
            filtered_insights = insights.annotate(lower_ad_status=Lower('fb_ad__status')).filter(lower_ad_status__icontains=ad_status.lower())
            
            # If no results, revert to the unfiltered insights
            if filtered_insights.exists():
                insights = filtered_insights
            else:
                # Log or notify no matching ad_status
                print("No match found for the provided ad_status. Returning unfiltered data.")

            
        # If fb_ad_account_name is provided, filter insights by the account name
        # Assuming `fb_ad_account_name` is a field in the `FacebookAdAccount` model
          # Filter data for the authenticated user
        user = request.user
        fb_ad_accounts = FacebookAdAccount.objects.filter(user=user)

        if fb_ad_account_name:
            # Check if the name is at least 3 characters long
            if len(fb_ad_account_name) < 3:
                return Response(
                    standard_response(
                        400,  # status_code
                        'Please provide at least 3 characters of the Facebook Ad Account name.',  # message
                        []  # data
                    ),
                    status=400
                )

            # Case insensitive search for the provided account name
            fb_ad_accounts = fb_ad_accounts.filter(
                Q(fb_ad_account_name__icontains=fb_ad_account_name)
            )

            if not fb_ad_accounts.exists():
                return Response(
                    standard_response(
                        404,  # status_code
                        'No data found for the provided Facebook Ad Account name.',  # message
                        []  # data
                    ),
                    status=404
                )


          # Fetch distinct ad statuses
        distinct_statuses = FacebookAdInsight.objects.values('fb_ad__status').distinct()
        ad_status_list = [status['fb_ad__status'] for status in distinct_statuses]
        
        # If there are no statuses, add "-" as the default
        if not ad_status_list:
            ad_status_list.append("-")

        # Filter TrafficSourceMedium by date range
        if date_range == 'today':
            traffic_data = TrafficSourceMedium.objects.filter(date=today)
        elif date_range == 'yesterday':
            yesterday = today - timedelta(days=1)
            traffic_data = TrafficSourceMedium.objects.filter(date=yesterday)
        elif date_range == 'last7days':
            last_7_days = today - timedelta(days=7)
            traffic_data = TrafficSourceMedium.objects.filter(date__gte=last_7_days)
        elif date_range == 'last30days':
            last_30_days = today - timedelta(days=30)
            traffic_data = TrafficSourceMedium.objects.filter(date__gte=last_30_days)
        elif date_range == 'custom' and custom_start_date and custom_end_date:
            traffic_data = TrafficSourceMedium.objects.filter(
                date__gte=custom_start_date,
                date__lte=custom_end_date
            )
        else:
            traffic_data = TrafficSourceMedium.objects.all()

        # Filter data for the authenticated user
        user = request.user
        fb_ad_accounts = FacebookAdAccount.objects.filter(user=user)
        google_analytics_accounts = GoogleAnalyticsAccount.objects.filter(user=user)

        

        # Serialize the data
        insights_serializer = AnalyticsAnalysisSerializer(insights, many=True)
        traffic_serializer = TrafficSourceMediumSerializer(traffic_data, many=True)

        # Combine insights and traffic data based on matching ad_name and medium
        combined_data = []
        for insight in insights_serializer.data:
            matched = False
            # Compare each TrafficSourceMedium data with the current FacebookAdInsight's ad_name
            for traffic_item in traffic_serializer.data:
                # Convert both to lowercase for comparison
                if insight['ad_name'].lower() == traffic_item['medium'].lower():
                    combined_item = insight.copy()
                    combined_item['daily_revenue'] = traffic_item.get('daily_revenue', '-')
                    combined_data.append(combined_item)
                    matched = True
                    break
            if not matched:
                # If no match is found, append with "-" for daily_revenue
                insight['daily_revenue'] = '-'
                combined_data.append(insight)

        # For any traffic data that did not match an insight, we append them with "-" for other fields
        for traffic_item in traffic_serializer.data:
            matched = False
            for insight in insights_serializer.data:
                if insight['ad_name'].lower() == traffic_item['medium'].lower():
                    matched = True
                    break
            if not matched:
                # Create a new entry with "-" for the unmatched fields
                combined_item = {
                    'sr_no': '-',
                    'ad_name': traffic_item['medium'],
                    'impression': '-',
                    'spend': '-',
                    'cost_per_link_click': '-',
                    'date': '-',
                    'ad_status': '-',
                    'daily_budget': '-',
                    'daily_revenue': traffic_item.get('daily_revenue', '-')
                }
                combined_data.append(combined_item)

        # Group by ad_name and merge data
        grouped_data = {}
        for item in combined_data:
            ad_name = item['ad_name']
            if ad_name not in grouped_data:
                grouped_data[ad_name] = {
                    'ad_name': ad_name,
                    'impression': 0,
                    'spend': 0.0,
                    'cost_per_link_click': item.get('cost_per_link_click', '-'),
                    'ad_status': item.get('ad_status', '-'),
                    'daily_budget': item.get('daily_budget', '-'),
                    'daily_revenue': 0.0,
                    'date_range': [],
                    'sr_no': 0,
                    'spend_with_gst': 0.0  # Adding a new field for spend with GST
                }

            # Sum values
            grouped_data[ad_name]['impression'] += item['impression'] if item['impression'] != '-' else 0
            grouped_data[ad_name]['spend'] += float(item['spend']) if item['spend'] != '-' else 0
            grouped_data[ad_name]['daily_revenue'] += float(item['daily_revenue']) if item['daily_revenue'] != '-' else 0

            # Calculate spend with 18% GST
            grouped_data[ad_name]['spend_with_gst'] = grouped_data[ad_name]['spend'] * 1.18

            # Store date range
            if item['date'] not in grouped_data[ad_name]['date_range']:
                grouped_data[ad_name]['date_range'].append(item['date'])

        # Prepare the final output
        final_data = []
        for index, (ad_name, data) in enumerate(grouped_data.items(), start=1):
            data['sr_no'] = index
            data['date'] = ' to '.join(data['date_range']) if len(data['date_range']) > 1 else data['date_range'][0]
            data['spend'] = f"{data['spend']:.2f}"
            data['spend_with_gst'] = f"{data['spend_with_gst']:.2f}"  # Format spend_with_gst
            data['daily_revenue'] = f"{data['daily_revenue']:.2f}" if data['daily_revenue'] != 0 else '-'

            final_data.append(data)

        # Use standard_response to return the response
        return Response(standard_response(
            200,  # status_code
            "Analytics data fetched successfully",  # message
            {
                'fb_ad_accounts': [account.fb_ad_account_name for account in fb_ad_accounts],
                'google_analytics_accounts': [account.property_id for account in google_analytics_accounts],
                'status': ad_status_list,  # Add distinct ad statuses
                'data': final_data
            }
        ))


#====  update budget and status using ad id in our db as well as fb ad manager ==========


class GetOrUpdateDailyBudget(APIView):
    permission_classes = [IsAuthenticated]  # Only authenticated users can access

    def get(self, request, *args, **kwargs):
        ad_id = request.GET.get('ad_id', None)

        if not ad_id:
            return Response({"error": "Ad ID is required."}, status=status.HTTP_400_BAD_REQUEST)

        try:
            facebook_ad = FacebookAd.objects.select_related('fb_ad_set').filter(ad_id=ad_id).first()
            if not facebook_ad or not facebook_ad.fb_ad_set:
                return Response({"error": "Ad with the given ID does not exist or has no associated AdSet."}, status=status.HTTP_404_NOT_FOUND)

            ad_set = facebook_ad.fb_ad_set
            ad_status = facebook_ad.status
            ad_name = facebook_ad.ad_name
            # Return current budget in rupees (convert from cents)
            serialized_data = {
                "ad_name": ad_name,
                "daily_budget": ad_set.daily_budget,   # Convert from cents to rupees
                "ad_status": ad_status,
            }

            return Response(serialized_data, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def post(self, request, *args, **kwargs):
        ad_id = request.data.get('ad_id', None)
        new_daily_budget = request.data.get('daily_budget', None)  # Optional field
        new_ad_status = request.data.get('ad_status', None)  # Optional field

        if not ad_id:
            return Response({"error": "Ad ID is required."}, status=status.HTTP_400_BAD_REQUEST)

        try:
            # Retrieve the FacebookAd object and its related AdSet
            facebook_ad = FacebookAd.objects.select_related('fb_ad_set').filter(ad_id=ad_id).first()
            if not facebook_ad or not facebook_ad.fb_ad_set:
                return Response({"error": "Ad with the given ID does not exist or has no associated AdSet."}, status=status.HTTP_404_NOT_FOUND)

            ad_set = facebook_ad.fb_ad_set
            # Update the daily budget if provided
            if new_daily_budget is not None:
                new_daily_budget_in_cents = int(new_daily_budget * 100)  # Convert to cents
                old_local_budget = ad_set.daily_budget
                ad_set.daily_budget = new_daily_budget
                ad_set.save()

                # Retrieve access token and Ad Account ID
                access_token = facebook_ad.fb_ad_set.fb_campaign.fb_ad_account.fb_ad_access_token
                url = f'https://graph.facebook.com/v15.0/{facebook_ad.fb_ad_set.adset_id}'
                params = {
                    'access_token': access_token,
                    'daily_budget': new_daily_budget_in_cents,
                }

                # Send the request to Facebook Graph API to update the budget
                response = requests.post(url, data=params)

                if response.status_code != 200:
                    return Response(
                        {"error": f"Failed to update daily budget in Facebook: {response.text}"},
                        status=status.HTTP_500_INTERNAL_SERVER_ERROR
                    )

            # Update ad status if provided
            if new_ad_status is not None:
                old_local_status = facebook_ad.status
                facebook_ad.status = new_ad_status.upper()  # Ensure status is uppercase (e.g., ACTIVE, PAUSED)
                facebook_ad.save()

                # Update status in Facebook Ad Manager
                access_token = facebook_ad.fb_ad_set.fb_campaign.fb_ad_account.fb_ad_access_token
                url = f'https://graph.facebook.com/v15.0/{facebook_ad.fb_ad_set.adset_id}'
                params = {
                    'access_token': access_token,
                    'status': new_ad_status.upper(),
                }

                # Send the request to Facebook Graph API to update the status
                response = requests.post(url, data=params)

                if response.status_code != 200:
                    return Response(
                        {"error": f"Failed to update ad status in Facebook: {response.text}"},
                        status=status.HTTP_500_INTERNAL_SERVER_ERROR
                    )

            # Return success response for either budget or status update
            serialized_data = {
                "message": "Ad details updated successfully in both database and Facebook Ad Manager.",
                "ad_id": ad_id,
            }

            if new_daily_budget is not None:
                serialized_data["daily_budget"] = round(new_daily_budget, 2)

            if new_ad_status is not None:
                serialized_data["ad_status"] = new_ad_status.upper()

            return Response(serialized_data, status=status.HTTP_200_OK)

        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)



class Last7DaysTrendsView(APIView):
    permission_classes = [IsAuthenticated] 
    
    def get(self, request, *args, **kwargs):
        trends = request.query_params.get('trends', None)
        if not trends:
            return Response({"error": "No trends parameter provided"}, status=status.HTTP_400_BAD_REQUEST)

        # Fetch the necessary Facebook Ad data
        ads = FacebookAd.objects.filter(
            fb_ad_set__fb_campaign__fb_ad_account__user=request.user
        )

        serializer_data = []
        for ad in ads:
            serializer = AdLast7DaysSerializer(ad, context={'today': timezone.now()})

            # Dynamically filter the fields based on the 'trends' query parameter
            trend_data = {}

            # Add other static fields
            trend_data.update({
                'ad_account_name': serializer.data['ad_account_name'],
                'ad_id': serializer.data['ad_id'],
                'ad_name': serializer.data['ad_name'],
                'status': serializer.data['status'],
                'daily_budget': serializer.data['daily_budget']
            })

            # Check which trend is requested and add relevant fields
            if 'spend_data' in trends:
                trend_data['spend_data'] = serializer.data['spend_data']
                trend_data['total_spend'] = serializer.data['total_spend']
            if 'daily_revenue' in trends:
                trend_data['daily_revenue_data'] = serializer.data['daily_revenue_data']
                trend_data['total_daily_revenue'] = serializer.data['sum_daily_revenue']
            if 'profit_loss_data' in trends:
                trend_data['profit_loss_data'] = serializer.data['profit_loss_data']
                trend_data['sum_profit_loss'] = serializer.data['sum_profit_loss']
            if 'cost_per_link_click_data' in trends:
                trend_data['cost_per_link_click_data'] = serializer.data['cost_per_link_click_data']
                trend_data['avg_cost_per_link_click'] = serializer.data['avg_cost_per_link_click']
            if 'spend_with_gst_data' in trends:
                trend_data['spend_with_gst_data'] = serializer.data['spend_with_gst_data']
                trend_data['total_spend_with_gst'] = serializer.data['total_spend_with_gst']
            if 'roi_data' in trends:
                trend_data['roi_data'] = serializer.data['roi_data']
                trend_data['avg_roi'] = serializer.data['avg_roi']



            serializer_data.append(trend_data)

        return Response(serializer_data, status=status.HTTP_200_OK)
