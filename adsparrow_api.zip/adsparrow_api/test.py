# from facebook_business.api import FacebookAdsApi
# from facebook_business.adobjects.adaccount import AdAccount
# from facebook_business.adobjects.adsinsights import AdsInsights
# from facebook_business.adobjects.adset import AdSet
# from facebook_business.adobjects.campaign import Campaign
# from facebook_business.exceptions import FacebookRequestError
# from datetime import datetime, timedelta

# # Set up your access token and ad account ID
# access_token = 'EAAPBBfYwfZBEBOZCRQExAWUbrwlArPCewV2nqsdD1pTogKfuXkkf8iiYFpWytovARd0ZC7SmtyRUlVsHOwqU12o6kZADcc13KSBHY05CB0b96Ti7VIQoIZBvDX0TF86w4V4stYMeE9bkNv8pqMZAPRzW4heNzdEMxOb02v6hM5cMFInLwaIGblt9YZBnzXGoUvOcOwX'
# ad_account_id = '265286608472987'
# app_id = '1056656279502817'
# app_secret = '2262d17143d0195c0384c347f63f6434'

# # Initialize the Facebook API

# # Initialize the Facebook API
# FacebookAdsApi.init(app_id, app_secret, access_token)

# # Get today's date and the date range (last 3 days)
# end_date = datetime.now().date()
# start_date = end_date - timedelta(days=3)

# # Define the fields you want to fetch
# insights_fields = [
#     AdsInsights.Field.ad_id,
#     AdsInsights.Field.ad_name,
#     AdsInsights.Field.adset_id,
#     AdsInsights.Field.adset_name,
#     AdsInsights.Field.impressions,
#     AdsInsights.Field.clicks,
#     AdsInsights.Field.spend,
#     AdsInsights.Field.reach,
#     AdsInsights.Field.cpc,
#     AdsInsights.Field.cost_per_ad_click,
#     AdsInsights.Field.date_start,
#     AdsInsights.Field.date_stop,
#     AdsInsights.Field.actions,
#     AdsInsights.Field.cost_per_action_type,
# ]

# # Fetch and print insights data for each day in the date range
# for day_offset in range(4):  # Loop over 4 days (start_date to end_date)
#     current_start_date = start_date + timedelta(days=day_offset)
#     current_start_date_str = current_start_date.strftime('%Y-%m-%d')
#     current_end_date_str = current_start_date_str  # Same date for each day

#     params = {
#         'time_range': {'since': current_start_date_str, 'until': current_end_date_str},
#         'level': 'ad',
#         'time_increment': 1,
#     }

#     try:
#         # Get the ad insights for the current day
#         account = AdAccount(f'act_{ad_account_id}')
#         insights = account.get_insights(fields=insights_fields, params=params)

#         # Loop over each insight and print the details
#         for insight in insights:
#             ad_id = insight.get('ad_id', 'N/A')
#             ad_name = insight.get('ad_name', 'N/A')
#             adset_id = insight.get('adset_id', 'N/A')
#             adset_name = insight.get('adset_name', 'N/A')
#             impressions = int(insight.get('impressions', '0'))
#             clicks = int(insight.get('clicks', '0'))
#             spend = float(insight.get('spend', '0'))
#             reach = int(insight.get('reach', '0'))
#             cpc = float(insight.get('cpc', '0'))
#             cost_per_ad_click = float(insight.get('cost_per_ad_click', '0'))
#             date_start = insight.get('date_start', 'N/A')
#             date_stop = insight.get('date_stop', 'N/A')

#             actions = insight.get('actions', [])
#             results = 0
#             for action in actions:
#                 if action.get('action_type') == 'link_click':
#                     results = float(action.get('value', 0))
#                     break

#             cost_per_action_type = insight.get('cost_per_action_type', [])
#             cost_per_result = 0
#             for action_cost in cost_per_action_type:
#                 if action_cost.get('action_type') == 'link_click':
#                     cost_per_result = float(action_cost.get('value', 0))
#                     break

#             # Print the insights for the current ad
#             print(f"Ad Name: {ad_name}, Ad ID: {ad_id}")
#             print(f"Adset Name: {adset_name}, Adset ID: {adset_id}")
#             print(f"Impressions: {impressions}, Clicks: {clicks}, Spend: {spend}")
#             print(f"Reach: {reach}, CPC: {cpc}, Cost per Ad Click: {cost_per_ad_click}")
#             print(f"Results (Link Clicks): {results}, Cost per Result: {cost_per_result}")
#             print(f"Date: {date_start} - {date_stop}\n")

#     except FacebookRequestError as e:
#         print(f"Error fetching insights for {current_start_date_str}: {e}")

#=========== final fb data fetch =========

# import json
# from facebook_business.api import FacebookAdsApi
# from facebook_business.adobjects.adaccount import AdAccount
# from facebook_business.adobjects.adsinsights import AdsInsights
# from facebook_business.adobjects.adset import AdSet
# from facebook_business.adobjects.ad import Ad
# from facebook_business.exceptions import FacebookRequestError
# from datetime import datetime, timedelta

# # Set up your access token and ad account ID
# access_token = 'EAAPBBfYwfZBEBOZCRQExAWUbrwlArPCewV2nqsdD1pTogKfuXkkf8iiYFpWytovARd0ZC7SmtyRUlVsHOwqU12o6kZADcc13KSBHY05CB0b96Ti7VIQoIZBvDX0TF86w4V4stYMeE9bkNv8pqMZAPRzW4heNzdEMxOb02v6hM5cMFInLwaIGblt9YZBnzXGoUvOcOwX'
# ad_account_id = '265286608472987'
# app_id = '1056656279502817'
# app_secret = '2262d17143d0195c0384c347f63f6434'

# # Initialize the Facebook API
# FacebookAdsApi.init(app_id, app_secret, access_token)

# # Get yesterday's date
# end_date = datetime.now().date() - timedelta(days=1)
# start_date = end_date

# # Define the fields you want to fetch, including campaign ID, campaign name, ad status, and daily budget
# insights_fields = [
#     AdsInsights.Field.ad_id,
#     AdsInsights.Field.ad_name,
#     AdsInsights.Field.adset_id,
#     AdsInsights.Field.adset_name,
#     AdsInsights.Field.campaign_id,
#     AdsInsights.Field.campaign_name,
#     AdsInsights.Field.impressions,
#     AdsInsights.Field.clicks,
#     AdsInsights.Field.spend,
#     AdsInsights.Field.reach,
#     AdsInsights.Field.cpc,
#     AdsInsights.Field.date_start,
#     AdsInsights.Field.date_stop,
#     AdsInsights.Field.actions,
#     AdsInsights.Field.cost_per_action_type,
# ]

# # Prepare an empty list to hold all insights data
# insights_data = []

# # Fetch insights data for yesterday's date
# current_start_date_str = start_date.strftime('%Y-%m-%d')
# current_end_date_str = current_start_date_str  # Same date for each day

# params = {
#     'time_range': {'since': current_start_date_str, 'until': current_end_date_str},
#     'level': 'ad',
#     'time_increment': 1,
# }

# try:
#     # Get the ad insights for the current day
#     account = AdAccount(f'act_{ad_account_id}')
#     insights = account.get_insights(fields=insights_fields, params=params)

#     # Loop over each insight and store the details in a dictionary
#     for insight in insights:
#         ad_id = insight.get('ad_id', 'N/A')
#         ad_name = insight.get('ad_name', 'N/A')
#         adset_id = insight.get('adset_id', 'N/A')
#         adset_name = insight.get('adset_name', 'N/A')
#         campaign_id = insight.get('campaign_id', 'N/A')
#         campaign_name = insight.get('campaign_name', 'N/A')
#         impressions = int(insight.get('impressions', '0'))
#         clicks = int(insight.get('clicks', '0'))
#         spend = float(insight.get('spend', '0'))
#         reach = int(insight.get('reach', '0'))
#         cpc = float(insight.get('cpc', '0'))
#         date_start = insight.get('date_start', 'N/A')
#         date_stop = insight.get('date_stop', 'N/A')

#         # Get the daily budget for the ad set and format it as a float (e.g., 100.00 instead of 10000)
#         daily_budget = 'N/A'
#         if adset_id != 'N/A':
#             adset = AdSet(adset_id)
#             adset_details = adset.api_get(fields=['daily_budget'])
#             daily_budget = adset_details.get('daily_budget', 'N/A')
#             if daily_budget != 'N/A':
#                 daily_budget = float(daily_budget) / 100  # Convert from cents to dollars

#         # Get the ad status
#         ad_status = 'N/A'
#         if ad_id != 'N/A':
#             ad = Ad(ad_id)
#             ad_details = ad.api_get(fields=['status'])
#             ad_status = ad_details.get('status', 'N/A')

#         actions = insight.get('actions', [])
#         cost_per_link_click = 0
#         for action in actions:
#             if action.get('action_type') == 'link_click':
#                 cost_per_link_click = float(action.get('value', 0))

#         cost_per_action_type = insight.get('cost_per_action_type', [])
#         cost_per_result = 0
#         for action_cost in cost_per_action_type:
#             if action_cost.get('action_type') == 'link_click':
#                 cost_per_result = float(action_cost.get('value', 0))

#         # Create a dictionary with the current insight data (including daily_budget and ad_status)
#         ad_insight = {
#             "ad_id": ad_id,
#             "ad_name": ad_name,
#             "adset_id": adset_id,
#             "adset_name": adset_name,
#             "campaign_id": campaign_id,
#             "campaign_name": campaign_name,
#             "daily_budget": f"{daily_budget:.2f}",  # Format daily budget with 2 decimal places
#             "ad_status": ad_status,
#             "impressions": impressions,
#             "clicks": clicks,
#             "spend": spend,
#             "reach": reach,
#             "cpc": cpc,
#             "cost_per_link_click": cost_per_link_click,
#             "cost_per_result": cost_per_result,
#             "date_start": date_start,
#             "date_stop": date_stop
#         }

#         # Append the dictionary to the insights data list
#         insights_data.append(ad_insight)

# except FacebookRequestError as e:
#     print(f"Error fetching insights for {current_start_date_str}: {e}")

# # Print the insights data in JSON format
# print(json.dumps(insights_data, indent=4))



# ===================================




import json
from facebook_business.api import FacebookAdsApi
from facebook_business.adobjects.adaccount import AdAccount
from facebook_business.adobjects.adsinsights import AdsInsights
from facebook_business.adobjects.adset import AdSet
from facebook_business.adobjects.ad import Ad
from facebook_business.exceptions import FacebookRequestError
from datetime import datetime, timedelta

# Set up your access token and ad account ID
access_token = 'EAAPBBfYwfZBEBOZCRQExAWUbrwlArPCewV2nqsdD1pTogKfuXkkf8iiYFpWytovARd0ZC7SmtyRUlVsHOwqU12o6kZADcc13KSBHY05CB0b96Ti7VIQoIZBvDX0TF86w4V4stYMeE9bkNv8pqMZAPRzW4heNzdEMxOb02v6hM5cMFInLwaIGblt9YZBnzXGoUvOcOwX'
ad_account_id = '265286608472987'
app_id = '1056656279502817'
app_secret = '2262d17143d0195c0384c347f63f6434'

# Initialize the Facebook API
FacebookAdsApi.init(app_id, app_secret, access_token)

# Get yesterday's date
end_date = datetime.now().date() - timedelta(days=1)
start_date = end_date

# Define the fields you want to fetch, including campaign ID, campaign name, ad status, and daily budget
insights_fields = [
    AdsInsights.Field.ad_id,
    AdsInsights.Field.ad_name,
    AdsInsights.Field.adset_id,
    AdsInsights.Field.adset_name,
    AdsInsights.Field.campaign_id,
    AdsInsights.Field.campaign_name,
    AdsInsights.Field.impressions,
    AdsInsights.Field.clicks,
    AdsInsights.Field.spend,
    AdsInsights.Field.reach,
    AdsInsights.Field.cpc,
    AdsInsights.Field.date_start,
    AdsInsights.Field.date_stop,
    AdsInsights.Field.actions,
    AdsInsights.Field.cost_per_action_type,
]

# Prepare an empty list to hold all insights data
insights_data = []

# Fetch insights data for yesterday's date
current_start_date_str = start_date.strftime('%Y-%m-%d')
current_end_date_str = current_start_date_str  # Same date for each day

params = {
    'time_range': {'since': current_start_date_str, 'until': current_end_date_str},
    'level': 'ad',
    'time_increment': 1,
}

try:
    # Get the ad insights for the current day
    account = AdAccount(f'act_{ad_account_id}')
    insights = account.get_insights(fields=insights_fields, params=params)

    # Loop over each insight and store the details in a dictionary
    for insight in insights:
        ad_id = insight.get('ad_id', 'N/A')
        ad_name = insight.get('ad_name', 'N/A')
        adset_id = insight.get('adset_id', 'N/A')
        adset_name = insight.get('adset_name', 'N/A')
        campaign_id = insight.get('campaign_id', 'N/A')
        campaign_name = insight.get('campaign_name', 'N/A')
        impressions = int(insight.get('impressions', '0'))
        clicks = int(insight.get('clicks', '0'))
        spend = float(insight.get('spend', '0'))
        reach = int(insight.get('reach', '0'))
        cpc = float(insight.get('cpc', '0'))
        date_start = insight.get('date_start', 'N/A')
        date_stop = insight.get('date_stop', 'N/A')

        # Get the daily budget for the ad set and format it as a float (e.g., 100.00 instead of 10000)
        daily_budget = 'N/A'
        if adset_id != 'N/A':
            adset = AdSet(adset_id)
            adset_details = adset.api_get(fields=['daily_budget'])
            daily_budget = adset_details.get('daily_budget', 'N/A')
            if daily_budget != 'N/A':
                daily_budget = float(daily_budget) / 100  # Convert from cents to dollars

        # Get the ad status
        ad_status = 'N/A'
        if ad_id != 'N/A':
            ad = Ad(ad_id)
            ad_details = ad.api_get(fields=['status'])
            ad_status = ad_details.get('status', 'N/A')

        actions = insight.get('actions', [])
        cost_per_link_click = 0
        for action in actions:
            if action.get('action_type') == 'link_click':
                cost_per_link_click = float(action.get('value', 0))

        cost_per_action_type = insight.get('cost_per_action_type', [])
        cost_per_result = 0
        for action_cost in cost_per_action_type:
            if action_cost.get('action_type') == 'link_click':
                cost_per_result = float(action_cost.get('value', 0))

        # Create a dictionary with the current insight data (including daily_budget and ad_status)
        ad_insight = {
            "ad_id": ad_id,
            "ad_name": ad_name,
            "adset_id": adset_id,
            "adset_name": adset_name,
            "campaign_id": campaign_id,
            "campaign_name": campaign_name,
            "daily_budget": f"{daily_budget:.2f}",  # Format daily budget with 2 decimal places
            "ad_status": ad_status,
            "impressions": impressions,
            "clicks": clicks,
            "spend": spend,
            "reach": reach,
            "cpc": cpc,
            "cost_per_link_click": cost_per_link_click,
            "cost_per_result": cost_per_result,
            "date_start": date_start,
            "date_stop": date_stop
        }

        # Append the dictionary to the insights data list
        insights_data.append(ad_insight)

except FacebookRequestError as e:
    print(f"Error fetching insights for {current_start_date_str}: {e}")

# Print the insights data in JSON format
print(json.dumps(insights_data, indent=4))